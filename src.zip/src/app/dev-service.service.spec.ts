import { TestBed, inject } from '@angular/core/testing';

import { DevServiceService } from './dev-service.service';

describe('DevServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DevServiceService]
    });
  });

  it('should be created', inject([DevServiceService], (service: DevServiceService) => {
    expect(service).toBeTruthy();
  }));
});
