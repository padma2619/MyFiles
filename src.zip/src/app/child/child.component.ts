import { Component, OnInit, Input, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() childMsg: string;
  childData = "Hey! I received your message."; //This msg for ViewChild
  childData2 = "Second message from child"; // This msg for @Output - Eventemmitter
  @Output() messageEvent = new EventEmitter(); 
  constructor() { }

  ngOnInit() {
  }

  sendMessage(){ 
    this.messageEvent.emit(this.childData2);
  }


}
