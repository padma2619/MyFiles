import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOtcComponent } from './add-otc.component';

describe('AddOtcComponent', () => {
  let component: AddOtcComponent;
  let fixture: ComponentFixture<AddOtcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOtcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
