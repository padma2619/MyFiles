import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromRoot from './../../../app.reducer';
import * as ActionTypes from './actionTypes';
import { Member, MedicationsModelInterface } from '../model/medications.interface';

export interface PillPack {
  medications: Array<MedicationsModelInterface>
}
  
export const initialState: PillPack = {
  medications: []
};
  
export function reducer(state: PillPack = initialState, action: any): PillPack {
  switch (action.type) {

    case ActionTypes.UPDATE_MEDICATIONS:
      return {
        ...state,
        medications: [...action.payload]
      }
    default:
      return state;
  }
}
  
export interface State extends fromRoot.State {
  'pillpack': PillPack
}
  
export const getPillpackState = createFeatureSelector<PillPack>('pillpack');

export const getMedications = createSelector(getPillpackState,
  (state: PillPack) => state.medications);