import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MedicationsComponent } from './medications/medications.component';
import { PillpackRouter } from './my-pillpack.route';
import { MatCheckboxModule, MatRadioModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { AddOtcComponent } from './add-otc/add-otc.component';
import { StoreModule } from '@ngrx/store';
import { reducer } from './store/reducer';
import { EffectsModule } from '@ngrx/effects';
import { PillpackEffects } from './store/effects';
import { ReactiveFormsModule } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import { SharedModule } from '../../shared/shared.module';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSelectModule } from '@angular/material/select';
import { MedicationDetailsComponent } from './components/medication-details/medication-details.component';
import { LandingComponent } from './landing/landing.component';
import { verifyEmail } from '../my-profile/verify-email-mobile/verifyEmail.module';
import { RxOrderSummaryComponent } from './components/rx-order-summary/rx-order-summary.component';
import {  ConfirmationComponent } from './confirmation/confirmation.component';
import { CreditCardComponent } from './components/credit-card/credit-card.component';


@NgModule({
  imports: [
    CommonModule,
    PillpackRouter,
    MatCheckboxModule,
    MatRadioModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    StoreModule.forFeature('pillpack', reducer),
    EffectsModule.forFeature([PillpackEffects]),
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    SharedModule,
    verifyEmail
    
  ],
  declarations: [MedicationsComponent, AddOtcComponent, MedicationDetailsComponent, LandingComponent,ConfirmationComponent, RxOrderSummaryComponent, CreditCardComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class MyPillpackModule { }
