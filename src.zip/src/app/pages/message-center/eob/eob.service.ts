import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import {
  EOBListResponseModelInterface,
  EOBListRequestModelInterface
} from './models/eob-data-model.interface';

@Injectable()
export class EOBService {

  constructor(private http: AuthHttp,
    private constants: ConstantsService,
    private authService: AuthService) {
  }

  getEobList(reqParams?: EOBListRequestModelInterface):
     Observable<any> {
    const request = reqParams || { useridin: this.authService.useridin
      //statementDateRange:{startDate: '03/10/2017',endDate: '03/08/2017' }
     };
     console.log(request);
    //reqParams.statementDateRange = {startDate: '03/10/2017',endDate: '03/08/2017' };
    return this.http.encryptPost(this.constants.getEobListUrl,
      request, null, null, false);
  }
  getEOBDocumentLink(reqParams): Observable<any>{
    console.log(reqParams);
   
    return this.http.encryptPost(this.constants.getEobLinkUrl, reqParams, null, null, true);
  }
}
