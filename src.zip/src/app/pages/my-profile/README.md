

Tooltip is hard code
should contact us be a tooltip on i. 
thinking to take it to near header text

Only one edit can be one in all possible scenarios.

when is the  success mesage shown?
after a success message is shown; and when edit is clicked for next time, we should go away when clicking on next edit.
change in the text for success mesasge and there is not message matric from BA
there is a non-error message global msgs - it is a google docs and will be shared - dev team follow up


always the phone number edited and the email edited should be reverified.





