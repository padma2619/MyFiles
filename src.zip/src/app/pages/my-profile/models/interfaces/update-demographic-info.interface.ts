import {
    BaseDemographicInfoModelInterface,
    MemberProfileGenericResponseModelInterface
} from './member-profile-generics.interface';

// tslint:disable-next-line:no-empty-interface
export interface UpdateDemographicInfoRequestModelInterface extends BaseDemographicInfoModelInterface {

}

// tslint:disable-next-line:no-empty-interface
export interface UpdateDemographicInfoResponseModelInterface extends MemberProfileGenericResponseModelInterface {

}
