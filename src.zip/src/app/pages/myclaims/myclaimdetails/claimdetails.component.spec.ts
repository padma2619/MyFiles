import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
    MatSelectModule, MatRadioModule, MatCardModule, MatIconModule,
    MatSidenavModule, MatDialogModule, MatTooltipModule,
    MatGridListModule, MatFormFieldModule, MatDatepickerModule,
    MatButtonModule, MatNativeDateModule, MatListModule, MatExpansionModule
} from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../shared/services/auth.service';
import { CommonModule, DatePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'

import { StorageServiceModule } from 'angular-webstorage-service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';

import {
    FakeBreadcrumbsComponent, FakeFpoLayoutComponent
} from '../../../../jasmine/fake-components';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { ClaimidPipe } from '../../../shared/pipes/claimid/claimid.pipe';
import {
    FakeCellAspectRatioDirectiveStub, FakeInfiniteScrollUpDistanceDirectiveStub,
    FakeScrollWindowDirectiveStub, FakeInfiniteScrollDirectiveStub,
    FakeInfiniteScrollContainerDirectiveStub, FakeFromRootDirectiveStub,
    FakeInfiniteScrollDistanceDirectiveStub, FakeInfiniteScrollThrottleDirectiveStub,
    FakeInfiniteScrollDisabledDirectiveStub, FakescrolledDirectiveStub,
    FakeScrolledUpDirectiveStub
} from '../../../../jasmine/fake-directives';
import { ClaimdetailsComponent } from './claimdetails.component';
import { ClaimsService } from '../claims.service';
import { ConstantsService } from '../../../shared/shared.module';
import { claimDetails_component_data } from '../../../../jasmine/data/myClaims/claimdetails.component.data';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { getclaimdetails_response } from '../../../../jasmine/data/myClaims/getclaimdetails.data';
import { of } from 'rxjs/observable/of';
import * as deepEqual from "deep-equal";
import { getClaimBenefitsLink_response } from '../../../../jasmine/data/myClaims/getClaimBenefitsLink.data';

describe('ClaimdetailsComponent', () => {

    // NOTE
    // FOR THIS TO WORK, html template error has to be resolved in claimdetails.component.html file
    // line no: 90 the code *ngIf="claimDetails.eobLinkName" has to be changed into *ngIf="claimDetails && claimDetails.eobLinkName"

    let component: ClaimdetailsComponent;
    let fixture: ComponentFixture<ClaimdetailsComponent>;

    let mockRouter;
    let mockClaimsService;
    let mockAuthService;
    let mockAlertService;
    let mockActivatedRoute;
    let mockConstantsService;

    let newAuthServiceMock;

    beforeEach(async(() => {
        mockActivatedRoute = {
            snapshot: {
                data: {

                }
            }
        };

        mockClaimsService = mocks.service.claimsService;
        mockRouter = mocks.service.router;
        mockAlertService = mocks.service.alertService;
        mockAuthService = mocks.service.authService;
        mockConstantsService = mocks.service.constantsService;

        TestBed.configureTestingModule({
            imports: [
                NoopAnimationsModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                StorageServiceModule,
                HttpClientTestingModule,

                MatDatepickerModule,
                MatNativeDateModule,
                MatFormFieldModule,
                MatRadioModule,
                MatSelectModule,
                MatCardModule,
                MatIconModule,
                MatSidenavModule,
                MatTooltipModule,
                MatGridListModule,
                MatDialogModule,
                MatExpansionModule,
                MatListModule,
                MatButtonModule,

                MaterialModule
            ],
            declarations: [
                FakeBreadcrumbsComponent,
                FakeFpoLayoutComponent,

                FakeCellAspectRatioDirectiveStub,
                FakeInfiniteScrollUpDistanceDirectiveStub,
                FakeScrollWindowDirectiveStub,
                FakeInfiniteScrollDirectiveStub,
                FakeInfiniteScrollContainerDirectiveStub,
                FakeFromRootDirectiveStub,
                FakeInfiniteScrollDistanceDirectiveStub,
                FakeInfiniteScrollThrottleDirectiveStub,
                FakeInfiniteScrollDisabledDirectiveStub,
                FakescrolledDirectiveStub,
                FakeScrolledUpDirectiveStub,

                ClaimidPipe,
                ClaimdetailsComponent
            ],
            providers: [
                { provide: ClaimsService, useValue: mockClaimsService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: AlertService, useValue: mockAlertService },
                DatePipe,
                { provide: ConstantsService, useValue: mockConstantsService }
            ]
        })
            .compileComponents();
    }));


    describe('Constructor', () => {

        it('should create', () => {
            //arrange
            fixture = TestBed.createComponent(ClaimdetailsComponent);
            //act
            component = fixture.componentInstance;
            //assert
            expect(component).toBeTruthy();
        });

        describe('While Component Creation', () => {
            it('should have called this.authService.fetchUserState to have been called once', () => {
                //arrange
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                //act
                component = fixture.componentInstance;
                //assert
                expect(mockAuthService.fetchUserState).toHaveBeenCalled();
            });

            it('should have called this.handleFinanceLinksInSideBar to have been called once', () => {
                //arrange
                let spyHandleFinanceLinksInSideBar = spyOn<any>(ClaimdetailsComponent.prototype, 'handleFinanceLinksInSideBar');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                //act
                component = fixture.componentInstance;
                //assert
                expect(spyHandleFinanceLinksInSideBar).toHaveBeenCalledTimes(1);
            });

            it('should have initialized this.expandedHeight to "48px"', () => {
                try {
                    //arrange                
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    //act
                    component = fixture.componentInstance;
                    //assert
                    expect(component.expandedHeight).toBe('48px');
                } catch (error) { }
            });

            it('should have initialized this.fpoTargetUrl to be this.constantsService.drupalClaimsrUrl', () => {
                try {
                    //arrange                
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    //act
                    component = fixture.componentInstance;
                    //assert
                    expect(component.fpoTargetUrl).toBe(mockConstantsService.drupalClaimsrUrl);
                } catch (error) { }
            });

            describe('when this.authService.fetchUserState() is Active and Inactive', () => {
                it('should have initialized this.isUserStateActive to true', () => {
                    //arrange
                    newAuthServiceMock = Object.assign({}, mockAuthService);
                    newAuthServiceMock.fetchUserState.and.returnValue('Active');

                    TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                    TestBed.compileComponents();

                    // TestBed.configureTestingModule({
                    //     providers: [
                    //         { provide: AuthService, useValue: newAuthServiceMock }
                    //     ]
                    // }).compileComponents();
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    //act
                    component = fixture.componentInstance;
                    //assert
                    expect(component.isUserStateActive).toBeTruthy();
                });

                it('should have initialized this.isUserStateActive to false', () => {
                    //arrange
                    newAuthServiceMock = Object.assign({}, mockAuthService);
                    newAuthServiceMock.fetchUserState.and.returnValue('Inactive');

                    TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                    TestBed.compileComponents();

                    // TestBed.configureTestingModule({
                    //     providers: [
                    //         { provide: AuthService, useValue: newAuthServiceMock }
                    //     ]
                    // }).compileComponents();
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    //act
                    component = fixture.componentInstance;
                    //assert                    
                    expect(component.isUserStateActive).toBeFalsy();
                });
            });

            describe('when this.authService.useridin is valid', () => {
                beforeEach(() => {
                    //arrange
                    newAuthServiceMock = Object.assign({}, mockAuthService);
                    newAuthServiceMock.useridin = 'validValue';

                    TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                    TestBed.compileComponents();

                    // TestBed.configureTestingModule({
                    //     providers: [
                    //         { provide: AuthService, useValue: newAuthServiceMock }
                    //     ]
                    // })
                    //     .compileComponents();

                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    //act
                    component = fixture.componentInstance;
                });

                it('should have initialized this.isMedexMember to false', () => {
                    //assert
                    expect(component.isMedexMember).toBeFalsy();
                });

                it('should have initialized this.isRateProvided to false', () => {
                    //assert
                    expect(component.isRateProvided).toBeFalsy();
                });
            });
        });
    });

    describe('ngOnInit', () => {

        beforeEach(() => {
            let sessionStorageResponseArray = [
                claimDetails_component_data.claimsRecord_sessionStorage,
                claimDetails_component_data.authToken_sessionStorage
            ];
            let responseCount = 0;
            let sessionStorageGetItem = function* () {
                yield sessionStorageResponseArray[responseCount++];
            }

            spyOn(sessionStorage.__proto__, 'setItem').and.returnValue(null);
            spyOn(sessionStorage.__proto__, 'getItem').and
                .returnValue(sessionStorageGetItem().next().value);
        });

        describe('should have called', () => {
            it('should have called this.getClaimDetails', () => {
                //arrange            
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                let spyGetClaimDetails = spyOn(component, 'getClaimDetails').and.returnValue(null);

                //act
                fixture.detectChanges();

                //assert
                expect(spyGetClaimDetails).toHaveBeenCalled();
            });

            it('should have called this.claimSerive.claimRecord$.subscribe', () => {
                //arrange            
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                let spyClaimRecordSubscribe = spyOn(mockClaimsService.claimRecord$, 'subscribe').and.returnValue(null);

                //act
                fixture.detectChanges();

                //assert
                expect(spyClaimRecordSubscribe).toHaveBeenCalled();
            })
        });
    });

    describe('methods', () => {
        describe('handleFinanceLinksInSideBar', () => {
            describe('this.authService.authToken.isHEQ is true or false', () => {
                it('should update this.ssoFinancialLink as "/sso/alegeus" when false', () => {
                    //arrange            
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    component = fixture.componentInstance;

                    //act
                    fixture.detectChanges();
                    //component['handleFinanceLinksInSideBar']();

                    //assert
                    expect(component.ssoFinancialLink).toBe('/sso/alegeus');
                });
                describe('should update this.ssoFinancialLink as "/sso/heathequity" when true', () => {
                    beforeEach(() => {
                        //arrange

                        newAuthServiceMock = Object.assign({}, mockAuthService);
                        newAuthServiceMock.authToken.isHEQ = 'true';

                        TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                        TestBed.compileComponents();

                        // TestBed.configureTestingModule({
                        //     providers: [
                        //         { provide: AuthService, useValue: newAuthServiceMock }
                        //     ]
                        // })
                        //     .compileComponents();
                    })
                    beforeEach(async () => {
                        fixture = TestBed.createComponent(ClaimdetailsComponent);
                        let authService = fixture.debugElement.injector.get(AuthService);
                        component = fixture.componentInstance;

                        //act
                        fixture.detectChanges();
                        //component['handleFinanceLinksInSideBar']();
                    });

                    it('should assert to true', () => {
                        //assert
                        expect(component.ssoFinancialLink).toBe('/sso/heathequity');
                    });
                });
            });

            describe('this.authService.authToken.isALG is true or false', () => {
                describe('this.authService.authToken.isALG is true', () => {
                    describe('this.authService.authToken.isHEQ is true or false', () => {
                        describe('this.authService.authToken.isHEQ is true', () => {
                            beforeEach(() => {
                                //arrange   
                                newAuthServiceMock = Object.assign({}, mockAuthService);
                                newAuthServiceMock.authToken.isALG = 'true';
                                newAuthServiceMock.authToken.isHEQ = 'true';

                                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                                TestBed.compileComponents();

                                // TestBed.configureTestingModule({
                                //     providers: [
                                //         { provide: AuthService, useValue: newAuthServiceMock }
                                //     ]
                                // })
                                //     .compileComponents();
                            });
                            beforeEach(async () => {

                                fixture = TestBed.createComponent(ClaimdetailsComponent);
                                component = fixture.componentInstance;

                                //act
                                fixture.detectChanges();
                                //component['handleFinanceLinksInSideBar']();
                            });
                            it('should update this.showHEQALGFinancialLink as true', () => {
                                //assert
                                expect(component.showHEQALGFinancialLink).toBeTruthy();
                            });
                            it('should update this.showFinancialLink as false', () => {
                                //assert
                                expect(component.showFinancialLink).toBeFalsy();
                            });
                        });
                        describe('this.authService.authToken.isHEQ is false', () => {
                            beforeEach(() => {
                                //arrange 
                                newAuthServiceMock = Object.assign({}, mockAuthService);
                                newAuthServiceMock.authToken.isALG = 'true';
                                newAuthServiceMock.authToken.isHEQ = 'false';

                                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                                TestBed.compileComponents();

                                // TestBed.configureTestingModule({
                                //     providers: [
                                //         { provide: AuthService, useValue: newAuthServiceMock }
                                //     ]
                                // })
                                //     .compileComponents();
                            });
                            beforeEach(async () => {
                                fixture = TestBed.createComponent(ClaimdetailsComponent);
                                component = fixture.componentInstance;

                                //act
                                component['handleFinanceLinksInSideBar']();
                            });
                            it('should update this.showHEQALGFinancialLink as false', () => {
                                //assert
                                expect(component.showHEQALGFinancialLink).toBeFalsy();
                            });
                            it('should update this.showFinancialLink as true', () => {
                                //assert
                                expect(component.showFinancialLink).toBeTruthy();
                            });
                        });
                    });
                });
                describe('this.authService.authToken.isALG is false', () => {
                    describe('this.authService.authToken.isHEQ is true or false', () => {
                        describe('this.authService.authToken.isHEQ is true', () => {
                            beforeEach(() => {
                                newAuthServiceMock = Object.assign({}, mockAuthService);
                                newAuthServiceMock.authToken.isALG = 'false';
                                newAuthServiceMock.authToken.isHEQ = 'true';

                                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                                TestBed.compileComponents();

                                // TestBed.configureTestingModule({
                                //     providers: [
                                //         { provide: AuthService, useValue: newAuthServiceMock }
                                //     ]
                                // })
                                //     .compileComponents();
                            })
                            beforeEach(async () => {
                                //arrange   
                                fixture = TestBed.createComponent(ClaimdetailsComponent);
                                component = fixture.componentInstance;

                                //act
                                fixture.detectChanges();
                                //component['handleFinanceLinksInSideBar']();
                            });
                            it('should update this.showHEQALGFinancialLink as false', () => {
                                //assert
                                expect(component.showHEQALGFinancialLink).toBeFalsy();
                            });
                            it('should update this.showFinancialLink as true', () => {
                                //assert
                                expect(component.showFinancialLink).toBeTruthy();
                            });
                        });
                        describe('this.authService.authToken.isHEQ is false', () => {
                            beforeEach(() => {
                                newAuthServiceMock = Object.assign({}, mockAuthService);
                                newAuthServiceMock.authToken.isALG = 'false';
                                newAuthServiceMock.authToken.isHEQ = 'false';

                                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                                TestBed.compileComponents();

                                // TestBed.configureTestingModule({
                                //     providers: [
                                //         { provide: AuthService, useValue: newAuthServiceMock }
                                //     ]
                                // })
                                //     .compileComponents();
                            })
                            beforeEach(async () => {
                                //arrange  
                                fixture = TestBed.createComponent(ClaimdetailsComponent);
                                component = fixture.componentInstance;

                                //act
                                fixture.detectChanges();
                                //component['handleFinanceLinksInSideBar']();
                            });
                            it('should update this.showHEQALGFinancialLink as false', () => {
                                //assert
                                expect(component.showHEQALGFinancialLink).toBeFalsy();
                            });
                            it('should update this.showFinancialLink as false', () => {
                                //assert
                                expect(component.showFinancialLink).toBeFalsy();
                            });
                        });
                    });
                });
            });
        });

        describe('openSSO', () => {
            it('should open this.ssoFinancialLink link in new window when called with "algOrHeq"', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //act
                component.openSSO('algOrHeq');
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith(component.ssoFinancialLink, '_blank')
            });
            it('should open "/sso/alegeus" link in new window when called with "alg"', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //act
                component.openSSO('alg');
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith('/sso/alegeus', '_blank')
            });
            it('should open "/sso/heathequity" link in new window when called with "heq"', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //act
                component.openSSO('heq');
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith('/sso/heathequity', '_blank')
            });
            it('should open "/sso/connecture" link in new window when called with "connecture"', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //act
                component.openSSO('connecture');
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith('/sso/connecture', '_blank')
            });
        });

        describe('ngOnDestroy', () => {
            it('should do something', () => {
                //arrange
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;

                //act
                component.ngOnInit();

                //assert
                expect(mockAlertService.clearError).toHaveBeenCalled();
            });
        });

        describe('getClaimDetails', () => {
            beforeEach(() => {
                let sessionStorageResponseArray = [
                    claimDetails_component_data.claimsRecord_sessionStorage,
                    claimDetails_component_data.authToken_sessionStorage
                ];
                let responseCount = 0;
                let sessionStorageGetItem = function* () {
                    yield sessionStorageResponseArray[responseCount++];
                }

                spyOn(sessionStorage.__proto__, 'setItem').and.returnValue(null);
                spyOn(sessionStorage.__proto__, 'getItem').and
                    .returnValue(sessionStorageGetItem().next().value);
            });

            it('should have called this.claimService.getClaimDetails', () => {
                //arrange            
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                fixture.detectChanges();

                //act
                //component.getClaimDetails();

                //assert
                expect(mockClaimsService.getClaimDetails).toHaveBeenCalled();
            });
            describe('Should do the following success/failure operations based on the response from  this.claimService.getClaimDetails', () => {

                describe('success response', () => {
                    beforeEach(() => {
                        //arrange     
                        fixture = TestBed.createComponent(ClaimdetailsComponent);
                        component = fixture.componentInstance;
                        fixture.detectChanges();

                        //act
                        //component.getClaimDetails();
                    });
                    it('should have set this.claimDetails to response', () => {
                        //assert
                        expect(component.claimDetails).toBeTruthy();
                    });

                    it('should have called sessionStorage.setItem', () => {
                        //assert
                        expect(sessionStorage.setItem).toHaveBeenCalled();
                    });

                    it('should have updated this.claimStatusLowerCaseDescription with this.claimDetails.claimStatus.toString().toLowerCase()', () => {
                        let asserter = component.claimDetails && component.claimDetails.claimStatus ? component.claimDetails.claimStatus.toString().toLowerCase() : '';
                        let result = component.claimStatusLowerCaseDescription ? component.claimStatusLowerCaseDescription : '';
                        //assert
                        expect(result).toBe(asserter);
                    });

                    it('should have updated this.providerAddress with this.claimDetails.providerAddress', () => {
                        //assert
                        expect(component.providerAddress).toBe(component.claimDetails.providerAddress);
                    });

                    it('should have updated this.claimTotals with this.claimDetails.claimTotals', () => {
                        //assert
                        expect(component.claimTotals).toBe(component.claimDetails.claimTotals);
                    });

                    it('should have updated this.allClaimServiceLines with this.claimDetails.claimServiceLines', () => {
                        //assert
                        expect(component.allClaimServiceLines).toBe(component.claimDetails.claimServiceLines);
                    });
                });

                describe('failure response', () => {
                    beforeEach(() => {
                        //arrange     

                        mockClaimsService.getClaimDetails.and.returnValue(of(getclaimdetails_response.failure));

                        TestBed.overrideProvider(ClaimsService, { useValue: mockClaimsService });
                        TestBed.compileComponents();

                        // TestBed.configureTestingModule({
                        //     providers: [
                        //         { provide: ClaimsService, useValue: mockClaimsService }
                        //     ]
                        // })
                        //     .compileComponents();
                    });
                    beforeEach(async () => {
                        fixture = TestBed.createComponent(ClaimdetailsComponent);
                        component = fixture.componentInstance;
                        fixture.detectChanges();

                        //act
                        //component.getClaimDetails();
                    });

                    afterAll(() => {
                        mockClaimsService.getClaimDetails.and.returnValue(of(getclaimdetails_response.success));

                        TestBed.overrideProvider(ClaimsService, { useValue: mockClaimsService });
                        TestBed.compileComponents();
                    });

                    it('should have set this.claimDetails to null', () => {
                        //assert
                        expect(component.claimDetails).toBeNull();
                    });

                    it('should have set this.alertService.setAlert to have been called', () => {
                        //assert
                        expect(mockAlertService.setAlert).toHaveBeenCalled();
                    });
                });
            });
        });

        describe('getDirections', () => {
            it('should have called window.open with geoLocation and "_self"', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                fixture.detectChanges();

                const location = component.providerAddress.address1 + ', ' +
                    component.providerAddress.city + component.providerAddress.state +
                    component.providerAddress.zipcode;
                const geoLocation = 'http://maps.google.com/?q=' + encodeURI(location);
                //act
                component.getDirections();
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith(geoLocation, '_self');
            });
        });

        describe('toggleExpansionPanel', () => {
            describe('should have set this.isExpanded to the boolean value passed in as the parameter', () => {
                beforeEach(() => {
                    //arrange                       
                    fixture = TestBed.createComponent(ClaimdetailsComponent);
                    component = fixture.componentInstance;
                });
                it("should have set this.isExpanded to true when called with true", () => {
                    //act
                    component.toggleExpansionPanel(true);

                    //assert
                    expect(component.isExpanded).toBeTruthy();
                });
                it("should have set this.isExpanded to true when called with false", () => {
                    //act
                    component.toggleExpansionPanel(false);

                    //assert
                    expect(component.isExpanded).toBeFalsy();
                });
            });
        });

        describe('navigateToDetails', () => {
            it("should have called this.router.navigate(['../', 'claimdetails', 'claimstatusdetails'], { relativeTo: this.route });", () => {
                //arrange                       
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //act
                component.navigateToDetails('', '');
                //assert
                expect(mockRouter.navigate).toHaveBeenCalledWith(['../', 'claimdetails', 'claimstatusdetails'], { relativeTo: mockActivatedRoute })
            });
        });

        describe('openUrl', () => {
            it('should have called window.open with the url passed in as the first parameter and "_self" as second param', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                let url = "mockUrlString";
                //act
                component.openUrl(url);
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith(url, '_self');
            });
        });

        describe('openContactsUs', () => {
            it('should have called window.open with component.contactus as the first parameter and "_self" as second param', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                let url = "mockUrlString";
                //act
                component.openContactsUs();
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith(component.contactus, '_self');
            });
        });

        describe('openUrlinNewWindow', () => {
            it('should have called window.open with this.constants.directPayUrl as the first parameter and "_self" as second param', () => {
                //arrange    
                let spyWindowOpen = spyOn(window, 'open');
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                let url = "mockUrlString";
                //act
                component.openUrlinNewWindow(url);
                //assert
                expect(spyWindowOpen).toHaveBeenCalledWith(mockConstantsService.directPayUrl, '_blank');
            });
        });

        describe('formattedDate', () => {
            beforeEach(() => {
                //arrange                    
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
            });

            it('should have called this.datePipe.transform when called with a valid date string as param', () => {
                //act
                let result = component.formattedDate("01Jan2019");

                //assert
                expect(result).toBe('01/01/2019');

            });

            it('should return undefined if invalid date string/ null/NaN/Undefined value is passed in as param', () => {
                //act
                let result = component.formattedDate("");

                //assert
                expect(typeof result).toBe('undefined');

            });
        });

        describe('loadBenefitsDocument', () => {
            let spyWindowOpenUrl;
            beforeEach(() => {
                spyWindowOpenUrl = spyOn(window, 'open').and.returnValue(null);
            });
            it('should have called component.loadBenefitsDocument', () => {
                //arrange                    
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;

                //act
                component.loadBenefitsDocument();

                //assert
                expect(mockClaimsService.getClaimsBenefitsLink).toHaveBeenCalled();
            });
            describe('Should do the following based on service call this.claimService.getClaimsBenefitsLink', () => {

                describe('should do the following in case of SUCCESS response', () => {
                    let spyOpenUrl;
                    beforeEach(() => {
                        //arrange                              
                        fixture = TestBed.createComponent(ClaimdetailsComponent);
                        component = fixture.componentInstance;

                        spyOpenUrl = spyOn(component, 'openUrl');

                        //act
                        component.loadBenefitsDocument();
                    });

                    it('should have updated this.benefitsDocument to api response', () => {
                        //act
                        let result = deepEqual(component.benefitsDocument, getClaimBenefitsLink_response.success);

                        //assert
                        expect(result).toBeTruthy();
                    });
                    it('should have called this.openUrl with this.benefitsDocument.eobLink', () => {
                        //assert
                        expect(spyOpenUrl).toHaveBeenCalledWith(component.benefitsDocument.eobLink);
                    })
                });

                describe('should do the following in case of failure response', () => {
                    beforeAll(() => {

                        let newMockClaimsService = Object.assign({}, mockClaimsService);
                        newMockClaimsService.getClaimsBenefitsLink.and.returnValue(of(getClaimBenefitsLink_response.failure));

                        TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
                        TestBed.compileComponents();

                    })

                    beforeEach(async () => {
                        //arrange                            
                        fixture = TestBed.createComponent(ClaimdetailsComponent);
                        component = fixture.componentInstance;

                        //act
                        component.loadBenefitsDocument();
                    })

                    it('should have called this.alertService.setAlert', () => {
                        expect(mockAlertService.setAlert).toHaveBeenCalled();
                    })
                });
            })
        });

        describe('decimalFragment', () => {
            it('should return a first two decimal places of the number is passed as parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let result = component.decimalFragment(10.87);
                //assert
                expect(result).toBe("87");

            });
            it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as string parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act                
                let result2 = component.decimalFragment("210.287");
                //assert
                expect(result2).toBe("29");
            });

            it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as  string parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act                
                let result2 = component.decimalFragment("-3310.1287");
                //assert
                expect(result2).toBe("13");
            });
            it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as nuimber parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act                
                let result2 = component.decimalFragment("-440.3449");
                //assert
                expect(result2).toBe("34");
            });

            it('should return "00" when invalid number is passed as string parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let nan_result = component.decimalFragment("invalidValue");

                //assert
                expect(nan_result).toBe("00");

            });
            it('should return "00" when invalid number is passed as object parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let object_result = component.decimalFragment({});

                //assert
                expect(object_result).toBe("00");
            });
            it('should return "00" when invalid number is passed as null parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let null_result = component.decimalFragment(null);
                //assert
                expect(null_result).toBe("00");
            });
            it('should return "00" when invalid number is passed as undefined parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act                
                let undefined_x;
                let undefined_result = component.decimalFragment(undefined_x);

                //assert                
                expect(undefined_result).toBe("00");
            });
            it('should return "00" when invalid number is passed as boolean true parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let undefined_result = component.decimalFragment(true);
                //assert
                expect(undefined_result).toBe("00");
            });
            it('should return "00" when invalid number is passed as boolean false parameter', () => {
                //arrange     
                fixture = TestBed.createComponent(ClaimdetailsComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();

                //act
                let undefined_result = component.decimalFragment(false);
                //assert
                expect(undefined_result).toBe("00");
            });
        });

    })

});
