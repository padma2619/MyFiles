import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from '../../../shared/services/auth.service';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/services/alert.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LandingService } from '../landing.service';
import { Image } from '../../../shared/models/image.model';
import { Finanical } from '../../../shared/models/finanical.model';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { HomePageInfoModel } from '../landing.model';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { RxDetailsRequestModelInterface } from '../../medications/models/interfaces/rx-details-model.interface';
import { RxDetailsRequestModel } from '../../medications/models/rx-details.model';
import { MyMedicationDetailsService } from '../../medications/myMedicationDetails/my-medication-details.service';
import { LineChartOptionsInterface } from '../../../shared/components/line-chart/line-chart.interface';
import { LineChartOptions } from '../../../shared/components/line-chart/line-chart.model';
import { MyDedCoService } from '../../myded-co/myded-co.service';
import { DeductiblesAccumsInterface } from '../../myded-co/models/interfaces/myded-co-info-model.interface';
import { AccumChartType } from '../../myded-co/models/types/myded-co.types';
import { PostLoginInfo } from '../../../shared/models/postlogininfo.model';
import { Store } from '@ngrx/store';
import { State } from '../../../app.reducer';


declare let $: any;

@Component({
  selector: 'app-authuser-landing',
  templateUrl: './authenticated-user.component.html',
  styleUrls: ['./authenticated-user.component.scss']
})
export class AuthUserLandingComponent implements OnInit, OnDestroy {
  PHARMACYURL = [
    { text: 'My Medications', display: 'My Medications', url: '', img: 'far fa-capsules  icons-class', location: '_self' },
    { text: '90-Day Supply', display: '90-Day Mail Order Pharmacy', url: '', img: 'far fa-envelope-open  icons-class', location: '_blank' },
    { text: 'Medication Lookup Tool', display: 'Medication Lookup Tool', url: '', img: 'far fa-clipboard-check  icons-class', location: '_blank' },
    { text: 'PillPack', display: 'Sign Up for PillPack', url: '', img: 'far fa-envelope-open  icons-class', location: '_self' }
  ];
  isRegisteredUser: boolean;
  hide4Feb19Release = false;
  memberInfo: HomePageInfoModel;
  carouselItemDetails: Image[] = [];
  bannerImage: any = '';
  doctorData: any;
  medicationData: any;
  ClaimsData: any;
  isdependant: boolean = false;
  ismedicaremember: boolean = false;
  isFinancialView: boolean = false;
  isSmartShopperUser: boolean = false;
  ismobile: boolean = false;
  mobileViewPort = 992;
  showDedcoSpinner = false;
  showDrupal: boolean = false;
  showDoctorDrupal: boolean = false;
  showMedicationDrupal: boolean = false;
  showClaimsDrupal: boolean = false;
  dedCoInfo: DeductiblesAccumsInterface = null;
  deductibleChartDetails: LineChartOptionsInterface[];
  financialChartCounter: number = 0;
  financialChartDetails: Finanical[] = [];
  isDisplayFinanceLoader: boolean;
  showNurseLine: boolean = false;
  hasBqi: boolean = false;
  title: string = 'Explanation of Benefits';
  hasBlueGreen: boolean = false;
  ahealthyme: boolean = false;
  hasFamily: boolean;
  dedCoName: string;
  transferLink: string;
  blueGreenUrl: string = this.constantsService.blueGreenUrl; // 'https://www.fidelity.com/fidelityhsa';
  nurseLineUrl: string = this.constantsService.nurseLineUrl; // 'https://myblue.bluecrossma.com/tools-resources/find-care/nurse-phone-line';
  cernerEEUrl: string = this.constantsService.cernerEEUrl;
  CernerMedicareUrl: string = this.constantsService.CernerMedicareUrl;
  drupalContentInactiveWithFinancials: string = this.constantsService.drupalContentInactiveWithFinancialsUrl;
  drupalContentInactiveNoFinancials: string = this.constantsService.drupalContentInactiveNoFinancialsUrl;
  postLoginInfo: PostLoginInfo;

  urlConfig = {
    mymedications: '../mymedications',
    medicationdetails: '../mymedications/medicationdetails',
    myclaims: '../myclaims',
    claimdetails: '/myclaims/claimdetails',
    mycards: '../mycards',
    myplans: '../myplans',
    myaccount: '../myaccount',
    messagecenter: '../message-center/messages',
    documents: '../myeobs',
    uploads: '../message-center/uploads',
    deductibles: '../mydedco',
    maintenance: '../pages/maintenance',
    mydoctors: '../mydoctors',
    doctordetails: '../mydoctors/details',
    myInbox: '../message-center',
    myprofile: '../myprofile',
    addpcp: '../mydoctors/add-pcp',
    updatepcp: '../mydoctors/update-pcp-homepage',
    requestwrittenestimate: '/request-estimate',
    yes: '/yes'
  };


  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }


  constructor(private authService: AuthService,
    private globalService: GlobalService,
    private router: Router,
    private http: AuthHttp,
    private titleCase: TitleCasePipe,
    private r: ActivatedRoute,
    private constantsService: ConstantsService,
    public landingService: LandingService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private myDedCoService: MyDedCoService,
    private myMedicationDetailsService: MyMedicationDetailsService,
    private store: Store<State>) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }

    var links;

    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    //const postLoginInfo = this.globalService.getPostLoginSessionObject();

    if (postLoginInfo != null) {
      var alreadyEnrolled = JSON.parse(postLoginInfo).isCPDPEnrolled;
      var isEnrolledThisSession = JSON.parse(sessionStorage.getItem("isCompleteHanddoff"));
      links = postLoginInfo ? JSON.parse(postLoginInfo).pharmacyLinks : [];
      this.PHARMACYURL.forEach(function (data) {
        links.find(function (link) {
          if (link.text == data.text) {
            data.url = link.url;
          }
        });
        if ((alreadyEnrolled || isEnrolledThisSession) && (data.text.toLocaleLowerCase().trim() == "pillpack")) {
          data.display = "Manage Your PillPack Account";
          data.url = 'https://www.pillpack.com';
        }

      });
    }

    /* -- Don't Make changes Here -- */
    if (this.r.snapshot.data.home && this.r.snapshot.data.home.ROWSET &&
      !Array.isArray(this.r.snapshot.data.home.ROWSET.ROW) &&
      typeof this.r.snapshot.data.home.ROWSET.ROW === 'object') {
      this.memberInfo = new HomePageInfoModel(titleCase).deserialize(this.r.snapshot.data.home.ROWSET
        && this.r.snapshot.data.home.ROWSET.ROW);

      // Smart Shopper Deferred to 3.1
      // const postLoginInfo = this.globalService.getPostLoginSessionObject();
      const postLoginInfo = sessionStorage.getItem('postLoginInfo');
      const postLoginInfoObj = JSON.parse(postLoginInfo);
      this.isSmartShopperUser = postLoginInfo ? (postLoginInfoObj.hasSS && postLoginInfoObj.hasSSO) : false;
      //this.isSmartShopperUser = this.memberInfo.hasSS === 'true' ? true : false;

      this.showNurseLine = ((this.memberInfo.cerner
        && (this.memberInfo.cerner.hasCerner !== 'true' &&
          this.memberInfo.cerner.hasCernerEE !== 'true' &&
          this.memberInfo.cerner.hasCernerMedicare !== 'true') &&
        (this.memberInfo.hasBlueGreen !== 'true' && this.memberInfo.hasBQi !== 'true')));
      this.hasBqi = this.memberInfo.hasBQi === 'true';
      this.hasBlueGreen = this.memberInfo.hasBlueGreen === 'true';

      this.ahealthyme = this.memberInfo.cerner &&
        (this.memberInfo.cerner.hasCerner === 'true' || this.memberInfo.cerner.hasCernerEE === 'true'
          || this.memberInfo.cerner.hasCernerMedicare === 'true');

      this.globalService.landingPageMemberInfo = this.memberInfo;
      this.authService.storeUserState(this.memberInfo.userState);
      //this.authService.setUserFullName(this.memberInfo.memFistName, this.memberInfo.memLastName)
      console.log('Homepage Data', this.memberInfo);
      if (this.memberInfo.myclaims && this.memberInfo.myclaims.clmICN) {
        sessionStorage.setItem('claimId', this.memberInfo.myclaims.clmICN);
      }
    } else if (this.r.snapshot.data.home && this.r.snapshot.data.home.result < 0) {
      console.log('Homepage API expected response is incorrect');
    }
    // else if (this.r.snapshot.data.home && this.r.snapshot.data.home.ROWSET &&
    //   Array.isArray(this.r.snapshot.data.home.ROWSET.ROW)) {
    //   this.bannerImage = 'Hero_Image_Default';
    //   this.http.hideSpinnerLoading();
    //   this.http.showServiceErrorModalPopup('requestTimeoutError');
    // }
    /* -- Don't Make changes Here -- */
    if (this.memberInfo) {
      this.showUserBanner();
      this.getFinancialData();
      this.showUserDataBlocks();
    }


    this.landingService.getCarouselItemDetails().subscribe(response => {
      this.carouselItemDetails = this.transformCarouselResponse(response);
    });

    this.landingService.loadArticle(1);
    this.landingService.loadArticle(2);
    if (authService.authToken.userType && authService.authToken.userType.toLowerCase() !== 'medicare' &&
      authService.authToken.userType.toLowerCase() !== 'medex') {
      this.landingService.loadArticle(3);
    }
  }

  showUserBanner(): void {
    try {
      if (this.authService.authToken && (this.authService.authToken.userType && (this.authService.authToken.userType.toLowerCase() === 'medicare' ||
        this.authService.authToken.userType.toLowerCase() === 'medex'))) {
        this.bannerImage = 'Hero_Image_Medicare';
        this.ismedicaremember = true;
      } else if (this.memberInfo && (this.memberInfo.hasDependents.toString() === 'false') && this.authService.authToken.userType &&
        (this.authService.authToken.userType.toLowerCase() !== 'medicare' ||
          this.authService.authToken.userType.toLowerCase() !== 'medex')) {
        this.bannerImage = 'Hero_Image_No_Dependents';
        this.isdependant = true;
      } else {
        this.bannerImage = 'Hero_Image_Default';
      }
    } catch (exception) {
      console.log(exception);
    }

  }

  navigatePharmacyUrl(url: string, location: string) {
    if (url == '/my-pillpack/landing') {
      this.router.navigate([url], { queryParams: { icid: 'PillPack Global' } })
    } else if (url.startsWith('/')) {
      this.router.navigate([url]);
    } else if (url != 'https://www.pillpack.com') {
      window.open(url, location);
    } else { this.openPillPackSite(); }
  }

  getHomePageInfo() {
    return this.landingService.getHomepageinfo();
  }

  getDedcoInfo() {
    // this.showDedcoSpinner = true;
    return this.landingService.getDedcoInfo();
  }

  getMemActiveStatus(): boolean {
    const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (scopename.toLowerCase().indexOf('inactive') >= 0) {
      return false;
    } else {
      return true;
    }
  }

  getRequestEstimateEligibilityStatus(): boolean {
    if (this.authService.authToken && this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED' &&
      (this.authService.authToken.HasActivePlan && this.authService.authToken.HasActivePlan.toLowerCase() === 'true')) {
      if (this.authService.authToken.userType === 'MEDICARE' || this.authService.authToken.userType === 'MEDEX' ||
        (this.authService.authToken.planTypes && this.authService.authToken.planTypes['medical'] !== 'true')) {
        return false;
      }
      return true;
    }
  }

  getFinancialData() {
    if (this.hasFinancialsData()) {
      this.isFinancialView = true;
      this.isDisplayFinanceLoader = true;
      this.showDedcoSpinner = true;
      this.landingService.getFinanceBalancChartData().subscribe((response) => {
        if (response && response.length) {
          // this.isFinancialView = true;
          this.financialChartDetails = response;
        } else {
          // this.isFinancialView = true;
          this.financialChartDetails = [];
        }

        this.isDisplayFinanceLoader = false;
        if (this.financialChartDetails.length === 0) {
          this.deductibleChartDetails = [];
          this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
        } else {
          this.deductibleChartDetails = [];
          this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
        }
        this.http.hideSpinnerLoading();
      }, (error) => {
        this.isDisplayFinanceLoader = false;
      });
    } else {
      this.deductibleChartDetails = [];
      this.financialChartDetails = [];
      this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
      this.http.hideSpinnerLoading();
    }
  }

  getDeductiblesAndCoinsuranceInfo(financialChartDetails) {
    this.showDedcoSpinner = true;
    this.myDedCoService.getDeductiblesAndCoinsuranceInfo().subscribe((response) => {
      this.showDedcoSpinner = false;
      if (response && response.accums && response.accums[0]) {
        this.dedCoInfo = response.accums[0];
        if (response.hasFamily === 'True') {
          this.hasFamily = true;
        } else {
          this.hasFamily = false;
          response.members.map(member => {
            this.dedCoName = member.name;
          });
        }
        this.deductibleChartDetails = this.getLineChartData(response.accums[0], financialChartDetails);
      }
    });
  }




  getLineChartOptionsList(serviceLineOptionsList, chartType: AccumChartType, lineChartOptions): LineChartOptionsInterface[] {
    if (serviceLineOptionsList && serviceLineOptionsList.length > 0) {
      for (const option of serviceLineOptionsList) {
        lineChartOptions.push(this.landingService.getLineChartOptions(option, chartType));
      }
    }
    return lineChartOptions;
  }

  getLineChartData(accum, financialChartDetails): LineChartOptionsInterface[] {
    let dedCoResponse = [];
    // if (accum.result === 0) {
    let lineChartOptions = [];
    lineChartOptions = this.getLineChartOptionsList(accum.coinsurance, AccumChartType.Coinsurance, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.overallDeductables, AccumChartType.overallDeductables, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.outOfPocket, AccumChartType.outOfPocket, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.overallBenefit, AccumChartType.overallBenefit, lineChartOptions);

    if ((financialChartDetails.length > 0 && lineChartOptions) ||
      (financialChartDetails.length === 0 && lineChartOptions &&
        this.hasFinancialsData())) {
      dedCoResponse = [lineChartOptions[0]];
    } else if (financialChartDetails.length === 0 && lineChartOptions) {
      dedCoResponse = lineChartOptions.length === 1 ? [lineChartOptions[0]] : lineChartOptions.slice(0, 2);
    }
    // }
    return dedCoResponse;
    // return financialChartDetails.length === 1 ? [...lineChartOptions[0]] : lineChartOptions;
  }


  hasFinancialsData(): boolean {
    const hasALG = this.memberInfo.hasALG.toString().toLowerCase();
    const hasHEQ = this.memberInfo.hasHEQ.toString().toLowerCase();
    const result = this.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    sessionStorage.setItem('hasALG', hasALG);
    sessionStorage.setItem('hasHEQ', hasHEQ);
    this.isFinancialView = result;
    return result;
  }

  transformCarouselResponse(response: any): Image[] {
    if (response && response.length) {
      return response.map((item) => {
        const carouselItem = new Image();
        carouselItem.src = this.constantsService.drupalTestUrl + item.RegularImages;
        carouselItem.mobilesrc = this.constantsService.drupalTestUrl + item.MobileImages;
        // item.isVideo ? '/assets/images/promo/bluebikes-myblue-promo-1002x435.png' : item.VIdeoUrl;
        carouselItem.text = item.ArticleText;
        carouselItem.isVideo = item.VideoUrl.length;
        carouselItem.VIdeoUrl = item.VideoUrl;
        carouselItem.urlLink = item.ArticleUrl;
        carouselItem.Title = item.Title;
        carouselItem.Body = item.Body;
        return carouselItem;
      });
    }
    return [];
  }

  ngOnDestroy() {

  }

  stopEventPropagation(event) {
    event.stopPropagation();
  }
  openOtherPartnerSite(link) {
    this.transferLink = link;
    $('#openOtherPartnerSite').modal('open');
  }
  closeOtherPartnerSite() {
    $('#openOtherPartnerSite').modal('close');
  }
  ngOnInit() {
    $('#openOtherPartnerSite').modal({ dismissible: true });
    this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
    this.alertService.clearError();

    if (!this.authService.tokenError) {
      this.http.showSpinnerLoading();
    } else {
      this.http.hideSpinnerLoading();
    }
    const t = sessionStorage.getItem('authToken');
    if (t) {
      const authToken = JSON.parse(t);
      if (authToken.userType === 'MEMBER' && (authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true')) {
        this.title = 'Summary of Health Plan Payments';
      }
      if ((authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true')) {

        this.title = 'Explanation of Benefits';
      }
      if ((authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false') && (authToken.planTypes['dental'] === 'false')) {
        this.title = 'Summary of Health Plan Payments';
      }
      if ((authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false')) {

        this.title = 'Explanation of Benefits';
      }
      if ((authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true') && (authToken.planTypes['dental'] === 'false')) {
        this.title = 'Summary of Health Plan Payments';
      }
      if ((authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false')) {

        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && (authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true')) {
        this.title = 'Explanation of Your Dental Benefits';
      }
      if ((authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true')) {

        this.title = 'Explanation of Your Dental Benefits';
      }
    }
    this.clearSessionItems();
  }

  showUserDataBlocks(): void {
    if (this.memberInfo && (this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName &&
      this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName
      && this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN)) {
      this.showDrupal = false;
      this.showMedicationDrupal = false;
      this.showDoctorDrupal = false;
      this.showClaimsDrupal = false;
    } else if (this.memberInfo && ((this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) ||
      (this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName)
      || (this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN))) {

      if (this.memberInfo && this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) {
        this.showDoctorDrupal = true;
        this.getDrupalContent(this.constantsService.drupalDoctorsUrl).subscribe(response => {
          this.doctorData = response[0];
        });
      }

      if (this.memberInfo && this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) {
        this.showMedicationDrupal = true;
        this.getDrupalContent(this.constantsService.drupalMedicationsUrl).subscribe(response => {
          this.medicationData = response[0];
        });
      }
      if (this.memberInfo && this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN) {
        this.showClaimsDrupal = true;
        this.getDrupalContent(this.constantsService.drupalClaimsUrl).subscribe(response => {
          this.ClaimsData = response[0];
        });
      }
    } else {
      this.showDrupal = false;
    }
  }

  formattedData(value: string) {
    // console.log('hello value = ' + value);
    if (!value) {
      return '';
    } else {
      value = value.substring(0, 11);
      return this.datePipe.transform(value, 'MM/dd/yyyy');
    }
  }

  navigate(id, routeParams?) {
    const url = this.urlConfig[id];
    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });

      }
    } else {
      return;
    }
  }

  incrementFinancialDetailsCounter() {
    if (this.financialChartCounter !== (this.financialChartDetails.length - 1)) {
      this.financialChartCounter = this.financialChartCounter === (this.financialChartDetails.length - 1) ?
        0 : (this.financialChartCounter + 1);
      $('.finanicals-details .financial-carousel').carousel('next');
    }
  }


  decrementFinancialDetailsCounter() {
    if (this.financialChartCounter > 0) {
      this.financialChartCounter = this.financialChartCounter === 0 ?
        (this.financialChartDetails.length - 1) : (this.financialChartCounter - 1);
      $('.finanicals-details .financial-carousel').carousel('prev');
    }
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }

  openUrlinNewWindow(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }
  openFadSSO() {
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    if (!postLoginInfo) {
      this.http.postlogin().then((response) => {
        if ((response && response.error !== true)) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
        }
        if (response && response.error) {
          this.http.showServiceErrorModalPopup('globalError');
        } else if (response.hasSSO || response.hasCI) {
          window.open('sso/vitals', '_blank');
        } else {
          this.router.navigate(['/fad']);
        }
      });
    } else {
      const postLoginInfoObj = JSON.parse(postLoginInfo);
      if (postLoginInfoObj.hasSSO || postLoginInfoObj.hasCI) {
        window.open('sso/vitals', '_blank');
      } else {
        this.router.navigate(['/fad']);
      }
    }
  }

  openPillPackSite() {
    sessionStorage.setItem('consentLink', "https://www.pillpack.com");
    $('#openPillPackSite').modal('open');
  }

  getDrupalContent(url): Observable<any> {
    return this.http.get(url).map((response) => {
      return this.transformCarouselResponse(response);
    });
  }

  authRestartScreen() {
    this.globalService.redirectionRoute().then((response) => {
      console.log(response);
    }).catch((route) => {
      this.router.navigate([route]);
    });
  }

  showMedicationDetails() {
    const medicationDetailReq: RxDetailsRequestModelInterface = new RxDetailsRequestModel();
    medicationDetailReq.useridin = this.authService.useridin;
    medicationDetailReq.rxIncurredDate = this.globalService.getUTCDate(this.memberInfo.mymedications.rxIncurredDate);
    medicationDetailReq.ndcCd = this.memberInfo.mymedications.rxNDCCode; // ndcCd;
    if (this.memberInfo && this.memberInfo.mymedications && this.memberInfo.mymedications.rxDependentId) {
      medicationDetailReq.dependentId = this.memberInfo.mymedications.rxDependentId;
    }
    this.myMedicationDetailsService.setMyMedicationDetailsRequest(medicationDetailReq);
    this.router.navigate(['../mymedications/medicationdetails']);
  }

  showDoctorDetails() {
    sessionStorage.setItem('providerName', this.memberInfo.mydoctors.visitPrvName);
    sessionStorage.setItem('providerNumber', this.memberInfo.mydoctors.visitPrvNum);
    if (this.memberInfo && this.memberInfo.mydoctors && this.memberInfo.mydoctors.visitDependentId) {
      sessionStorage.setItem('docDependentId', this.memberInfo.mydoctors.visitDependentId);
    }
    this.router.navigate([`/mydoctors/details`]);
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  navigateToAlegeus(): void {
    const hasALG = this.memberInfo && this.memberInfo.hasALG.toString().toLowerCase();
    const hasHEQ = this.memberInfo && this.memberInfo.hasHEQ.toString().toLowerCase();
    if (hasALG === 'true') {
      window.open('/sso/alegeus', '_blank');
      // this.router.navigate(['/sso/alegeus']);
    } else if (hasHEQ === 'true') {
      window.open('/sso/heathequity', '_blank');
    }

  }

  openAhealthyme() {
    if (this.memberInfo.cerner.hasCernerMedicare === 'true') {
      window.open(this.constantsService.CernerMedicareUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCernerEE === 'true') {
      window.open(this.constantsService.cernerEEUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCerner === 'true') {
      window.open('/sso/cerner', '_blank');
    }
  }

  openBqi() {
    window.open('sso/connecture', '_blank');
  }

  isHsaAccount(accountType) {
    return accountType === 'ABH' || accountType === 'HSA' || accountType === 'AB2';
  }


}
