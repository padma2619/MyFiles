import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Location } from '@angular/common';
import { FitnessFormComponent } from './fitness-form.component';
fdescribe('FitnessFormComponent', () => {
  let component: FitnessFormComponent;
  let fixture: ComponentFixture<FitnessFormComponent>;
  beforeEach(() => {
    const formBuilderStub = {
      group: formGroup => ({
        patchValue() { }
      }),
    };
    const locationStub = { back: () => ({}) };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [FitnessFormComponent],
      providers: [
        { provide: FormBuilder, useValue: formBuilderStub },
        { provide: Location, useValue: locationStub }
      ]
    });
    fixture = TestBed.createComponent(FitnessFormComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
  it('isFormSubmitted defaults to: false', () => {
    expect(component.isFormSubmitted).toEqual(false);
  });
  it('showForm defaults to: false', () => {
    expect(component.showForm).toEqual(false);
  });
  it('isAgreed defaults to: false', () => {
    expect(component.isAgreed).toEqual(false);
  });
  it('toolTipVisible defaults to: false', () => {
    expect(component.toolTipVisible).toEqual(false);
  });
  it('email_Addresses defaults to: []', () => {
    expect(component.email_Addresses).toEqual([]);
  });
  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'initializeFitnessForm').and.callThrough();
      component.ngOnInit();
      expect(component.initializeFitnessForm).toHaveBeenCalled();
    });
  });
  describe('initializeFitnessForm', () => {
    it('makes expected calls', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
        FormBuilder
      );
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.initializeFitnessForm();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });
  describe('onBackPressed', () => {
    it('makes expected calls', () => {
      const locationStub: Location = fixture.debugElement.injector.get(
        Location
      );
      spyOn(locationStub, 'back').and.callThrough();
      component.onBackPressed();
      expect(locationStub.back).toHaveBeenCalled();
    });
  });
  describe('onSubmit', () => {
    it('Sets isFormSubmitted to true', () => {
      component.isFormSubmitted = false;
      component.onSubmit();
      expect(component.isFormSubmitted).toBeTruthy();
    });
  });
  describe('showToolTip', () => {
    it('Sets showToolTip to true', () => {
      component.toolTipVisible = false;
      component.showToolTip();
      expect(component.toolTipVisible).toBeTruthy();
    });
  });
});
