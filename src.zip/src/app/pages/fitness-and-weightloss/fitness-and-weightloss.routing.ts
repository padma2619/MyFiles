import { FitnessFormComponent } from './fitness-form/fitness-form.component';
import { WeightlossFormComponent } from './weightloss-form/weightloss-form.component';
import { Routes, RouterModule } from '@angular/router';
import { DownloadReimbursementComponent } from './download-reimbursement/download-reimbursement.component';

const routes: Routes = [
  {
    path: 'fitness-form',
    component: FitnessFormComponent
  },
  {
    path: 'weightloss-form',
    component: WeightlossFormComponent
  },
  {
    path: 'download-reimbursement',
    component: DownloadReimbursementComponent

  },
  {
    path: '',
    component: DownloadReimbursementComponent

  }
];


export const FitnessAndWeightlossRouter = RouterModule.forChild(routes);
