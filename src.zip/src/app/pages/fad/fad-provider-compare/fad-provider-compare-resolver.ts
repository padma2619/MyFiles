import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {AuthService} from '../../../shared/shared.module';
import {FadProviderCompareService} from './fad-provider-compare.service';


@Injectable()
export class FadProviderCompareResolver implements Resolve<Observable<any[]>> {

  constructor(public authService: AuthService,
              public fadProviderCompareService: FadProviderCompareService
  ) {
  }

  resolve() {
    return null;
    //this.fadProviderCompareService.getCompareTableDetail();
  }
}
