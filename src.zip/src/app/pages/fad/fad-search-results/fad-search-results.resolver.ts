import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { FadSearchResultsService } from './fad-search-results.service';
import {
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import { FadConstants } from '../constants/fad.constants';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { GetSearchByFacilityRequestModel } from '../modals/getSearchByFacility.model';
import {
  FadLandingPageSearchControlValuesInterface,
  FadAutoCompleteComplexOptionInterface
} from '../modals/interfaces/fad-landing-page.interface';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AuthService } from '../../../shared/shared.module';
// import { FadAutoCompleteComplexOption } from '../modals/fad-landing-page.modal';
import { GetSearchBySpecialityRequestModelInterface, GetSearchBySpecialtyResponseModelInterface } from '../modals/interfaces/getSearchBySpeciality-models.interface';

import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';

@Injectable()
export class FadSearchResultsResolver<T> implements
  Resolve<Promise<GetSearchBySpecialtyResponseModelInterface |GetSearchByProfessionalResponseModelInterface | GetSearchByFacilityResponseModelInterface >> {
  constructor(private fadSearchResultsService: FadSearchResultsService,
    private errorHandler: BcbsmaerrorHandlerService, private router: Router,
    private authService: AuthService) { }

  async resolve(): Promise<GetSearchBySpecialtyResponseModelInterface |GetSearchByProfessionalResponseModelInterface | GetSearchByFacilityResponseModelInterface> {
   
    try {
      //alert("test");
      
      const authUserId = this.authService.useridin;
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      console.log("router url",this.fadSearchResultsService.getContextText());
      console.log("routes url",this.router.url);
      if (searchCriteria && searchCriteria.getSearchText()) {
        const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
        console.log("searchtextoption",searchTextOption);
        if (searchTextOption.getInfoText() === 'Specialty' || searchTextOption.getInfoText() === 'procedures' || searchTextOption.getInfoText() === 'specialities') {
           
          if (searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.speciality && this.fadSearchResultsService.getContextText()!='affiliated'
          
          ) {
            const vitalsSearchRequestbySpeciality:GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
            // vitalsSearchRequestbyProfessional
            //   .setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            //   .setLimit(FadConstants.defaults.limit)
            //   .setPage(FadConstants.defaults.page)
            //   .setRadius(FadConstants.defaults.radius)
            //   .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
            //     searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

            // // Converting with procedure or speality by using isProcedureFlag
            // if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            //   vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
            // } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            //   vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
            // } else {
            //   vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
            // }

            vitalsSearchRequestbySpeciality.setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());
    
          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
            
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort']="cost+asc";
          }else{
            
          }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          }
          else if (searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility && 
           this.fadSearchResultsService.getContextText()!='affiliated') {
            const vitalsSearchRequestbySpeciality:GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
            // vitalsSearchRequestbyProfessional
            //   .setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            //   .setLimit(FadConstants.defaults.limit)
            //   .setPage(FadConstants.defaults.page)
            //   .setRadius(FadConstants.defaults.radius)
            //   .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
            //     searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

            // // Converting with procedure or speality by using isProcedureFlag
            // if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            //   vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
            // } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            //   vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
            // } else {
            //   vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
            // }

            vitalsSearchRequestbySpeciality.setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());
    
          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
           
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort']="cost+asc";
          }else{
            
          }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          }
          else if (searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional && 
           this.fadSearchResultsService.getContextText()!='affiliated') {
            const vitalsSearchRequestbySpeciality:GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
            // vitalsSearchRequestbyProfessional
            //   .setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            //   .setLimit(FadConstants.defaults.limit)
            //   .setPage(FadConstants.defaults.page)
            //   .setRadius(FadConstants.defaults.radius)
            //   .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
            //     searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

            // // Converting with procedure or speality by using isProcedureFlag
            // if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            //   vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
            // } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            //   vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
            // } else {
            //   vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
            // }

            vitalsSearchRequestbySpeciality.setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());
    
          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
           
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort']="cost+asc";
          }else{
            
          }

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbySpeciality.setUserId(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
          }

          else if (this.fadSearchResultsService.getContextText()==='affiliated') {
            const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface
              = new GetSearchByProfessionalRequestModel();
            vitalsSearchRequestbyProfessional
              //.setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
              .setLimit(FadConstants.defaults.limit)
              .setPage(FadConstants.defaults.page)
              //.setRadius(FadConstants.defaults.radius)
              .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
                searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

            // Converting with procedure or speality by using isProcedureFlag
            // if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            //   vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
            // } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            //   vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
            // } else {
              // vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
            //}

            if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
              vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
            }
            return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
          }
        } else if (this.fadSearchResultsService.getContextText()==='affiliated') {
          const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface
            = new GetSearchByProfessionalRequestModel();
          vitalsSearchRequestbyProfessional
            //.setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            //.setRadius(FadConstants.defaults.radius)
            .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
              searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

          // Converting with procedure or speality by using isProcedureFlag
          // if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
          //   vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
          // } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
          //   vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
          // } else {
            // vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
          //}

          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
          }
          return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
        }
         else if (searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional && !searchCriteria.getSearchText().isProcedure()&&this.fadSearchResultsService.getContextText()!='affiliated') {

          const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface
            = new GetSearchByProfessionalRequestModel();
          vitalsSearchRequestbyProfessional.setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(FadConstants.defaults.radius)
            .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
              searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId);

          if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
          } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
          } else {
            vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
          }

          if (authUserId) {
            vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
          }

          return await this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
        } else if (searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility && !searchCriteria.getSearchText().isProcedure()&&this.fadSearchResultsService.getContextText()!='affiliated') {

          const vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface = new GetSearchByFacilityRequestModel();
          // alternate geolocation value format that is allowed '42.402311000000026,-71.12037000000004')
          // searchCriteria.zipCode ||
          vitalsSearchRequestbyFacility.setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FadConstants.defaults.limit)
            .setPage(FadConstants.defaults.page)
            .setRadius(FadConstants.defaults.radius)
            .setNetworkId((searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
              searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId)

          if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
            vitalsSearchRequestbyFacility.setSearchSpecialtyId(searchTextOption.getSpecialityId());
          } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
            vitalsSearchRequestbyFacility.setProcedureId(searchTextOption.getProcedureId());
          } else {
            vitalsSearchRequestbyFacility.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
          }

          if (authUserId) {
            vitalsSearchRequestbyFacility.setUserIdIn(this.authService.useridin);
          }

          return await this.fadSearchResultsService.getFadFacilitySearchResults(vitalsSearchRequestbyFacility).toPromise();
        }
      } else {
        this.router.navigate([FadConstants.urls.fadLandingPage]);
      }
    } catch (exception) {
      this.errorHandler.logError(exception, BcbsmaConstants.modules.fadModule, FadConstants.services.fadSearchResultsResolver
        , FadConstants.methods.resolve);
    }
    return null;
  }
}
