import { Injectable } from "@angular/core";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class TooltipService {

    private dismissSource = new BehaviorSubject<string>('');
    public dismissObjservable = this.dismissSource.asObservable();

    constructor() {}

    getDismiss() {
        return this.dismissObjservable;
    }

    dismissTooltip() {
        this.dismissSource.next(new Date().toDateString());
    }

}