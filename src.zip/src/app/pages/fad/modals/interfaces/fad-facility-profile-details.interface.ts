import { GeneralError } from '../../../../shared/models/generic-app.model';

export interface FadFacilityProfileRequestModelInterface {
    geoLocation: string;
    locationId?: number;
    facilityId: number;
    networkId: number;
    useridin: string;
    procedureId: string;
    radius: number;

    getGeoLocation(): string;
    setGeoLocation(geoLocation: string): FadFacilityProfileRequestModelInterface;

    getLocationId(): number;
    setLocationId(locationId: number): FadFacilityProfileRequestModelInterface;

    getfacilityId(): number;
    setfacilityId(facilityId: number): FadFacilityProfileRequestModelInterface;

    getNetworkId(): number;
    setNetworkId(networkId: number): FadFacilityProfileRequestModelInterface;

    getProcedureId(): string;
    setProcedureId(procedureId: string): FadFacilityProfileRequestModelInterface;

    getRadius():number;
    setRadius(radius: number): FadFacilityProfileRequestModelInterface;
}

export interface FadFacilityResponseModelInterface extends GeneralError,FadCostBenefitsInterface,FadFacilityCostInterface {
    facility?: any;
    facilityName: string; // This is the city/state of the location
    location: LocationListInterface[];
    disclaimers: DisclaimersInterface[];
    matchedLocation: LocationListInterface;
    onRecordDiclaimers?: DisclaimersInterface;
}

export interface DisclaimersInterface {
    text: string;
    category: string;
    priority: 0;
    id?: number;
}

export interface LocationListInterface {
    specialty: string;
    facilityId: number;
    address: string;
    phone: number;
    geoLocation: FadGeolocationDetailInterface[];
    amenities: FadAmenitiesInterface[];
    awards: FadAwardsInterface[];
    costBenefit: FadCostBenefitsInterface;
    facilityCost: FadFacilityCostInterface;
    identifiers: FadIdentifiersInterface[];
    ratings: FadRatingsListInterface[];
    quality: FadQualityListInterface[];
    additionalInformation: FadAdditionalInformationInterface[];
    reviews: FadReviewsListInterface;
    tiers: FadTiersInterface;
    locationId: number;
}

export interface FadRatingsListInterface {
    overallRating: number; //     This is the city/state of the location
    percentRecommended: number; //     This is the percentRecommended
    totalRatings: number; //     This is the totalRatings
}

export interface FadAmenitiesInterface {
    type: string;
}

export interface FadIdentifiersInterface {
    typeCode: string;
    value: string;
}

export interface FadAdditionalInformationInterface {
    typeCode: string;
    value: string;
}

export interface FadAwardsInterface {
    name: string;
    typeCode: string;
    awardDetails: AwardDetailInterface[];
}


export interface FadFacilityCostInterface  {
    copay?: number;
    coinsuranceAmount?: number;
    deductibleAmount?: number;
    employerCost?: number;
    procedureCost?: number;
    memberCost?: number;

    individualDeductibleLimit?: number;
    individualDeductibleAccumulated?: number;
    overallDeductibleLimit?: number;
    overallDeductibleAccumulated?: number;
    individualOutofPocketLimit?: number;
    individualOutofPocketAccumulated?: number;
    familyOutofPocketLimit?: number;
    familyOutofPocketAccumulated?: number;
}

export interface FadCostBenefitsInterface  {
    individualDeductibleLimit?: number;
    individualDeductibleAccumulated?: number;
    overallDeductibleLimit?: number;
    overallDeductibleAccumulated?: number;
    individualOutofPocketLimit?: number;
    individualOutofPocketAccumulated?: number;
    familyOutofPocketLimit?: number;
    familyOutofPocketAccumulated?: number;

    copay?: number;
    coinsuranceAmount?: number;
    deductibleAmount?: number;
    employerCost?: number;
    procedureCost?: number;
    memberCost?: number;
}



export interface AwardDetailInterface {
    name: string;
    url: string;
}

export interface FadQualityListInterface {
    name: string;
    score: number;
}

export interface FadGeolocationDetailInterface {
    latitude: number;
    longitude: number;
}

export interface FadReviewsListInterface {
    name: string;
    questionAnswer: FadQuestionAnswerListInterface[];
}

export interface FadQuestionAnswerListInterface {
    question: string;
    answers: FadAnswerListInterface[];
}

export interface FadAnswerListInterface {
    answer: string;
    answerPercent: string;
}
export interface FadTiersInterface {
    description: string;
}
