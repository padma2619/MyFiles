export interface SearchList{
   [index:number]:string;
}

/*export class SearchList implements ISearchList{
   

    constructor(public word:string){

    }

    searchData():void{
        const searchData = [];
        searchData.push(this)
    }
    
}*/