import { FiltersMetadata, SortMetadata } from './getSearchByProfessional.model';
import {
    FadSearchFilterComponentOutputModelInterface,
    FilterListItemInterface,
    FilterRadioItemInterface,
    FilterCheckboxItemInterface,
    GrpHospitalAffiliationFilterListItemInterface,
    FadFacilitySearchFilterComponentOutputModelInterface,
    FadSpecialtyFilterComponentOutputModelInterface
} from './interfaces/fad-search-filter.interface';
import { FacilityFiltersMetadataInterface } from './interfaces/getSearchByFacility-models.interface';
import { FacilityFiltersMetadataModel } from './getSearchByFacility.model';

export class FadSearchFilterComponentOutputModel implements FadSearchFilterComponentOutputModelInterface {
    filterOverlayFlag: boolean = false;
    filterCriteriaData: FiltersMetadata = new FiltersMetadata();
    sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FadFacilitySearchFilterComponentOutputModel implements FadFacilitySearchFilterComponentOutputModelInterface {
    filterOverlayFlag: boolean = false;
    filterCriteriaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
    sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FadSpecialtyFilterComponentOutputModel implements FadSpecialtyFilterComponentOutputModelInterface {
    filterOverlayFlag: boolean = false;
    filterCriteriaData: FiltersMetadata = new FiltersMetadata();
    sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FilterListItem implements FilterListItemInterface {
    name: string;
    value: string;
    count: string;
    default: string;
    selected: string;
}

export class FilterRadioItem implements FilterRadioItemInterface {
    name: string;
    value: string;
    checked: boolean;
}

export class FilterCheckboxItem implements FilterCheckboxItemInterface {
    value: string;
    count: string;
    default: string;
    selected: string;
}

export class GrpHospitalAffiliationFilterListItem implements GrpHospitalAffiliationFilterListItemInterface {
    name: string;
    value: string;
    count: string;
    category: string;
    default: string;
    selected: string;
}