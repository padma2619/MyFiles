import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import {
  // FadVitalsAutoCompleteSearchRequestModelInterface,
  // FadVitalsAutoCompleteSearchResponseModelInterface,
  FadZipCodeSearchResponseModelInterface,
  FadPlanSearchResponseModelInterface,
  // FadVitalsSearchHistoryResponseModelInterface,
  // FadVitalsZipCodeSearchRequestModelInterface,
  DoctorProfileSearchRequestModelInterface,
  // FadVitalsProfessionalsSearchResponseModelInterface,
  // FacilityProfileSearchRequestModelInterface,
  // FadVitalsFacilitiesSearchResponseModelInterface,
  FadPlanSearchRequestModelInterface,
  FadVitalsZipCodeSearchRequestModelInterface,
  FacilityProfileSearchRequestModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import {
  FadLandingPageSearchControlsModelInterface,
  FadLandingPageSearchControlValuesInterface,
  // FadAutoCompleteOptionForSearchTextInterface,
  LandingPageResponseCacheModelInterface,
  FadMembersInfoRequestModelInterface,
  FadMembersInfoResponseModelInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  FadLandingPageSearchControlsModel, FadLandingPageSearchControlValues, FadAutoCompleteOptionForSearchText, FadMembersInfoResponseModel, FadMembersInfoRequestModel,
  // FadAutoCompleteOptionForSearchText
} from '../modals/fad-landing-page.modal';
import { FadConstants } from '../constants/fad.constants';
import { ConstantsService, AuthService } from '../../../shared/shared.module';
import { LeafLetResponseModelInterface } from '../modals/interfaces/leaflet-model.interface';
import { AuthHttp, IRequestOptions } from '../../../shared/services/authHttp.service';
import {
  GetSearchByProfessionalResponseModelInterface,
  // GetSearchByProfessionalRequestModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { FadZipCodeSearchResponseModel, FZCSRCity, FadPlanSearchRequestModel } from '../modals/fad-vitals-collection.model';
import {
  GetSearchByProviderResponseModelInterface,
  GetSearchByProviderRequestModelInterface
} from '../modals/interfaces/getSearchByProvider-models.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import {
  GetSearchByFacilityResponseModelInterface,
  GetSearchByFacilityRequestModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { HashMapInterface } from '../../financials/models';
import { HashMap } from '../../financials/utils/all-transaction.utilities';
import { FadMedicalIndexRequestModal } from '../modals/fad-medical-index.modal';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';

@Injectable()
export class FadLandingPageService {

  public vitalsZipCodeInfo: FadZipCodeSearchResponseModelInterface = null;
  public cachedResponse: LandingPageResponseCacheModelInterface = null;
  // private httpOptions = {
  //   headers: new HttpHeaders({
  //     'Accept': 'application/json',
  //     'Content-Type': 'application/json',
  //     'Authorization': 'my-auth-token'
  //   })
  // };
  public plannetworkdata = null;
  private cachedSearchControlState: FadLandingPageSearchControlsModelInterface = null;
  private cachedSearchTextLookupOptions: HashMapInterface<FadAutoCompleteOptionForSearchText[]>
    = new HashMap<FadAutoCompleteOptionForSearchText[]>();
  private cachedZipCodeLookupOptions: HashMapInterface<FZCSRCity[]>
    = new HashMap<FZCSRCity[]>();

  public showAutoCompleteDropDownSpinner: boolean = false;

  constructor(private bcbsmaHttpService: BcbsmaHttpService, private http: AuthHttp, private authService: AuthService,
    private constants: ConstantsService, private fadSearchResultsService: FadSearchResultsService) { }

  public getCachedZipCodeLookupOptions(searchText: string): FZCSRCity[] {
    return this.cachedZipCodeLookupOptions.get(searchText);
  }
  public setCachedZipCodeLookupOptions(searchText: string, zipCodeLookupOptions: FZCSRCity[]): FadLandingPageService {
    this.cachedZipCodeLookupOptions.put(searchText, zipCodeLookupOptions);
    return this;
  }

  public getCachedSearchTextLookupOptions(key: string): FadAutoCompleteOptionForSearchText[] {
    let options: FadAutoCompleteOptionForSearchText[] = this.cachedSearchTextLookupOptions.get(key);
    if (!options) {
      const keyEntities = key.split('~');
      options = this.cachedSearchTextLookupOptions.get(`${keyEntities[0]}~`);
    }
    return options;
  }

  public setCachedSearchTextLookupOptions(searchText: string, lookupOptions: FadAutoCompleteOptionForSearchText[]): FadLandingPageService {
    this.cachedSearchTextLookupOptions.put(searchText, lookupOptions);
    return this;
  }

  getVitalsAutoCompleteSearchResponse(request: GetSearchByProviderRequestModelInterface)
    : Observable<GetSearchByProviderResponseModelInterface> {

    this.showAutoCompleteDropDownSpinner = true;
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
     }

    const url = FadConstants.urls.fadLandingPageSearchAutocompleteListUrl;
    // , this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(url, request, '', '', false).map(response => {
      return response;
    });
  }

  // a physical duplicate copy of this code is being used in FadResolcerService.ts
  // using a direct service call in the resolver requires 4+ fad specific services to be provided in app module
  // getVitalsPlanInfo(isResolverCall?: boolean): Observable<FadPlanSearchResponseModelInterface> {

  //   const request: FadPlanSearchRequestModelInterface = new FadPlanSearchRequestModel();
  //   request.useridin = this.authService.useridin && this.authService.useridin !== 'undefined' ? this.authService.useridin : '';

  //   const url = FadConstants.urls.fadLandingPagePlansAutocompleteListUrl;
  //   if (isResolverCall) {
  //     return this.http.encryptPost(url, request, null, null, false);
  //   } else {
  //     return this.http.encryptPost(url, request);
  //   }
  // }

  getVitalsZipCodeInfo(vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface):
    Observable<FadZipCodeSearchResponseModelInterface> {
    let url;
    // if (!vitalsZipCodeSearchRequest.place || vitalsZipCodeSearchRequest.place.length <= 2) {
    //   const dumZipCodeRes: FadZipCodeSearchResponseModelInterface = new FadZipCodeSearchResponseModel();
    //   return Observable.of(dumZipCodeRes);
    // }
    // tslint:disable-next-line:max-line-length
    //const url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&place=${vitalsZipCodeSearchRequest.place}`;
    if(vitalsZipCodeSearchRequest.city||vitalsZipCodeSearchRequest.zip||vitalsZipCodeSearchRequest.state)
    {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?city=${vitalsZipCodeSearchRequest.city}&state_code=${vitalsZipCodeSearchRequest.state}&zip=${vitalsZipCodeSearchRequest.zip}`;
    }
    else if(vitalsZipCodeSearchRequest.lat && vitalsZipCodeSearchRequest.lng && vitalsZipCodeSearchRequest.sort && vitalsZipCodeSearchRequest.limit)
    {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&lat=${vitalsZipCodeSearchRequest.lat}&lng=${vitalsZipCodeSearchRequest.lng}&sort=${vitalsZipCodeSearchRequest.sort}`;
    }
    else{
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&place=${vitalsZipCodeSearchRequest.place}`;
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'uitxnid': 'WEB_v3.0_' + this.http.uuid()
      })
    };
    return this.http.get(url, httpOptions, false);
  }

  getVitalsDependantList(): Observable<FadMembersInfoResponseModelInterface> {

    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.authService.useridin;
    if (this.authService.getFadHccsFlag() !== null) {
     request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    // const url = FadConstants.jsonurls.fadLandingPageDependentsListUrl;
    const url = FadConstants.urls.fadLandingPageDependentsListUrl;

    // return this.bcbsmaHttpService.get(url);

    return this.http.encryptPost(url, request);
  }

  getProcedureSummary(){
    const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
    if (this.authService.getFadHccsFlag() !== null) {
      ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
    }if (sessionStorage.getItem('fadVendorMemberNumber')) {
      ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FadConstants.urls.fadVitalsProcedureUrl;
    return this.http.encryptPost(url,ProcedureSearchReq,null,null,true);
  }
  getCachedSearchControlState(): FadLandingPageSearchControlsModelInterface {
    // if (!this.cachedSearchControlState) {
    //   this.cachedSearchControlState = new FadLandingPageSearchControlsModel();

    //   this.cachedSearchControlState.setValues(
    //     <FadLandingPageSearchControlValues>this.fadSearchResultsService.getSearchCriteria());
    // }
    return this.cachedSearchControlState;
  }

  setCachedSearchControlState(
    searchControlState: FadLandingPageSearchControlsModelInterface | FadLandingPageSearchControlValuesInterface): FadLandingPageService {
    this.cachedSearchControlState = new FadLandingPageSearchControlsModel();
    if (searchControlState instanceof FadLandingPageSearchControlsModel) {
      this.cachedSearchControlState.setControls(<FadLandingPageSearchControlsModelInterface>searchControlState,
        this.fadSearchResultsService);
    } else {
      this.cachedSearchControlState.setValues(<FadLandingPageSearchControlValues>searchControlState);
    }
    return this;
  }



  clearCachedSearchControlState(): FadLandingPageService {
    this.cachedSearchControlState = null;
    return this;
  }

  getLocationFromLatLong(position: Position):
    Observable<LeafLetResponseModelInterface> {

    let params = new HttpParams();
    params = params.append('access_token', FadConstants.text.leafLetAccessToken);
    params = params.append('types', FadConstants.text.leafLetGeoCodingQueryTypes.join(','));

    const url = this.constants.leafLetGecodingVersionUrl + '/' + position.coords.longitude + ',' + position.coords.latitude + '.json';
    return this.bcbsmaHttpService.get(url, { params: params });
  }

  getDoctorProfileDetails(request: DoctorProfileSearchRequestModelInterface): Observable<GetSearchByProfessionalResponseModelInterface> {

    request.userid = this.authService.useridin;

    const url = FadConstants.jsonurls.fadGetDoctorProfile;
    // FadConstants.api.fadUrl + FadConstants.urls.fadGetDoctorProfile :

    return this.bcbsmaHttpService.get(url);

    // return this.http.encryptPost(this.constants.getDoctorProfileUrl, request, null, null, false);
  }

  getFacilityProfileDetails(request: GetSearchByFacilityRequestModelInterface)
    : Observable<GetSearchByFacilityResponseModelInterface> {

    const url = FadConstants.urls.fadGetFacilityProfile;
    return this.bcbsmaHttpService.get(url);

    // return this.http.encryptPost(this.constants.getFacilityProfileUrl, request, null, null, false);
  }
  getToolTipInfo(){
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if(this.authService.useridin && this.authService.useridin!='undefined'){
    ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType']='All'; 
    const url = FadConstants.urls.fadVitalsToolTipsInfo;
    return this.http.encryptPost(url,ToolTipReq,null,null,false);
  }
}


