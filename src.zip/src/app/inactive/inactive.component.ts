import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inactive',
  templateUrl: './inactive.component.html',
  styleUrls: ['./inactive.component.css']
})
export class InactiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
