import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()

export class DevServiceService {
 
  constructor(private httpService : HttpClient) {}
  getCountries(){
    return this.httpService.get('../../assets/countries.json');
  }  
 
}  
