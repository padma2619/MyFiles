import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-active',
  templateUrl: './active.component.html',
  styleUrls: ['./active.component.css']
})
export class ActiveComponent implements OnInit {

  public user = {  
    id: "",   
    name: "" 
   };  

  public users = [    
    {"id" : 1001, "name" : "User1"},    
    {"id" : 1002, "name" : "User2"},    
    {"id" : 1003, "name" : "User3"},    
    {"id" : 1004, "name" : "User4"},    
    {"id" : 1005, "name" : "User5"}    
    ];    

  constructor(private activated: ActivatedRoute) { }

  ngOnInit() {  
    this.activated.paramMap.subscribe((params : ParamMap)=> {  
      this.user.id=params.get('id');  
      this.user.name=params.get('name');  
    });  
  }

}
