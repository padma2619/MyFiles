import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { DevServiceService } from './dev-service.service';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { ParentComponent } from './parent/parent.component'; 
import { ChildComponent } from './child/child.component'; 
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { UsersComponent } from './users/users.component';
import { ActiveComponent } from './active/active.component';
import { InactiveComponent } from './inactive/inactive.component';
 
@NgModule({ 
  declarations: [
    AppComponent, 
    HomeComponent,
    HeaderComponent,
    ParentComponent,   
    ChildComponent, UsersComponent, ActiveComponent, InactiveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DevServiceService, AuthService, AuthGuard], 
  bootstrap: [AppComponent]
})
export class AppModule { }
