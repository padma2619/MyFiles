import { Component, OnInit } from '@angular/core';
import { DevServiceService } from '../dev-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  sampleData = '';
  countries: any;
  users: any[] = [
    {
      "name": "User1",
      "age": 35,
      "country": 'Chennai'
    },
    {
      "name": "User2",
      "age": 32,
      "country": 'Mumbai'
    },
    {
      "name": "User3",
      "age": 21,
      "country": 'Cochin'
    },
    {
      "name": "User4",
      "age": 34,
      "country": 'Bangalore'
    },
    {
      "name": "User5",
      "age": 32,
      "country": 'Pune'
    }
  ];
  constructor(private countriesList : DevServiceService) {} 

  saveUserName(name: HTMLInputElement){
    console.log((<HTMLInputElement>name).value);
  }

  ngOnInit() {
    this.countriesList.getCountries().subscribe((res) => {
      this.countries = res;
    })
  }

}
