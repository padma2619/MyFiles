import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {

  constructor(private myRoute: Router) {}

  sendToken(token: string) {
    localStorage.setItem("LoggedInUser", token); // Store user id in local storge
  }
  getToken() {
    return localStorage.getItem("LoggedInUser"); // Fetch user id from local storage
  }
  isLoggednIn() {
    return this.getToken() !== null;
  }
  logout() {
    localStorage.removeItem("LoggedInUser");
    this.myRoute.navigate(["login"]);
  }
 
}
