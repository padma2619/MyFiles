import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AboutRoutingModule } from './about-routing.module';
import { AboutComponent } from './about.component';
import { FilterPipeModule } from 'ngx-filter-pipe'; 
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    AboutRoutingModule,
    FilterPipeModule,
    FormsModule
  ],
  declarations: [AboutComponent]
})
export class AboutModule { }
