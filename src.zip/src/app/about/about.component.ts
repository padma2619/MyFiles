import { Component, OnInit } from '@angular/core';
import { FilterPipe } from 'ngx-filter-pipe';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  countries = [

    {id: 1, cname: 'India'},
    {id: 2, cname: 'Indonesia'},
    {id: 3, cname: 'Iran'},
    {id: 4, cname: 'Australia'},
    {id: 5, cname: 'Amsterdam'},
    {id: 6, cname: 'America'},
    {id: 7, cname: 'Pakistan'},
    {id: 8, cname: 'Paris'},
    {id: 9, cname: 'Portugal'}

  ];

  countryFilter: any = { cname: '' };

  constructor(private filterPipe: FilterPipe) {
    filterPipe.transform(this.countries, { cname: ''});
  }

  ngOnInit() {
  }

}
