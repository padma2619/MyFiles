import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
}) 
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  // fontColor: string = 'blue';  

  constructor( private myRoute: Router, private auth: AuthService ) { 
    this.loginForm = new FormGroup({
      'userName': new FormControl('', [Validators.required, Validators.minLength(5) ]),
      'password': new FormControl('', [Validators.required ])
    });
  }

  login() {        
        if (this.loginForm.valid) {
            this.auth.sendToken(this.loginForm.value.userName); // Send user id to Auth Service
            this.myRoute.navigate(["home"]); 
        }
  }

  ngOnInit() {
  }

}
