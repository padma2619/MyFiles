import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ParentComponent } from './parent/parent.component'; // to comment for lazyloading
import { AuthGuard } from './auth.guard';
import { UsersComponent } from './users/users.component';
import { ActiveComponent } from './active/active.component';
import { InactiveComponent } from './inactive/inactive.component';

const routes: Routes = [
  {
    path:"",
    redirectTo: "/home",
    pathMatch: "full",
    canActivate: [AuthGuard]
  },
  {
    path:"home",
    component: HomeComponent,
    canActivate: [AuthGuard]
  },
  {
    path:"login",
     loadChildren: "app/login/login.module#LoginModule"
  },
  {
    path:"about",
     loadChildren: "app/about/about.module#AboutModule"
  },
  {
    path:"parent",
    component: ParentComponent 
  },
  {
    path:"users",
    component: UsersComponent,
    children: [
      {path:"active", component: ActiveComponent},
      {path: 'active/:id/:name', component : ActiveComponent}, 
      {path:"inactive", component: InactiveComponent}
    ] 
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
