import { Component, ViewChild, AfterContentInit  } from '@angular/core';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements AfterContentInit  {

  parentMsg = "Pass this back to me!";
  childMessage:string;

  @ViewChild(ChildComponent) child: any; // to fetch details from child component
  receivedChildData : any; 
  constructor() { } 
  ngAfterContentInit(){
    this.receivedChildData = this.child.childData;
  }
 
  receiveMessage($event: string) {
    this.childMessage = $event
  }

}
