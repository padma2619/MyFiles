import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicationsComponent } from './medications.component';
import { SharedModule } from '../../../shared/shared.module';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('MedicationsComponent', () => {
  let component: MedicationsComponent;
  let fixture: ComponentFixture<MedicationsComponent>;
  let medicationsDe: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      
      declarations: [ MedicationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicationsComponent);
    medicationsDe = fixture.debugElement;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have breadcrumbs', () => {
    const breadCrumbsDe = medicationsDe.query(By.css('app-breadcrumbs'));
    expect(breadCrumbsDe.nativeElement).toBeTruthy();
  })

});
