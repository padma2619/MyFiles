import { MyBlueGeneralAPIRequestModelInterface } from '../../../shared/models/interfaces/generic-app-models.interface';
import { UpdatePharmacyMedicationModelInterface, PharmacyModelInterface, PharmacyAddressModelInterface, PrescriberModelInterface, MaintenanceMedicationModelInterface, PartnerModelInterface } from "./pillpack-generic-models.interface";
import { MyBlueGeneralAPIRequestModel } from "../../../shared/models/generic-app.model";


export class UpdatePharmacyMedicationRequestModel extends MyBlueGeneralAPIRequestModel implements UpdatePharmacyMedicationModelInterface {
    partner:PartnerModelInterface;
    medications: MaintenanceMedicationModelInterface[];   
    key2id:string;
}
export class MaintenanceMedicationModel implements MaintenanceMedicationModelInterface{    
    ndcCd?:string;
    rxcui:string;
    description?:string;
    isSelfPrescribed?:boolean;
    shouldChase?:boolean;
    doseTimes?:string;
    genericName?:string;
    form?:string;
    daysSupply?:number;
    lastFill?:string;
    strength?:string;
    directions?:string;
    pharmacy?:PharmacyModel;
    prescriber?:PrescriberModel;
    isSelected?:boolean;
    copay?:number;
}
export class PharmacyModel implements PharmacyModelInterface{
    id:string;
    name:string;
    phoneNumber:string;
    address:PharmacyAddressModelInterface;
}
export class PharmacyAddressModel implements PharmacyAddressModelInterface{
    address1:string;
    address2:string;
    city:string;
    state:string;
    zipcode:string;
}
export class PrescriberModel implements PrescriberModelInterface{
    firstName:string;
    lastName:string;
    middleInitial:string;
    id:string;

    deaNumber:string;
    phoneNumber:string;
    address:PharmacyAddressModelInterface;     
}
export class PartnerModel implements PartnerModelInterface{
    id:string;
}