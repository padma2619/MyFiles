
export interface OTCMedications {
    genericName?: string;
    name: string;
    strength?: string;
    packageType?: string;      
    howOften?: string;
    time?: DateTimeFormat;    
    count?: string,
    price?: number,    
    quantity?: number, 
    reg?:number, 
    supply?:number, 
    isSelected?: boolean
}

