import { ProgramInformationComponent } from "./../../../shared/components/program-information/program-information.component";
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Location } from "@angular/common";
import { EmailAddress } from "../../../shared/components/email/EmailAddressInterface";
@Component({
  selector: "app-fitness-form",
  templateUrl: "./fitness-form.component.html",
  styleUrls: ["./fitness-form.component.scss"]
})
export class FitnessFormComponent implements OnInit {
  fitnessForm: FormGroup;
  isFormSubmitted = false;
  showForm = false;
  fitnessTypeOptions = [
    { label: "Monthly Membership", value: "value 1" },
    { label: "10 Fitness Classes", value: "value 2" }
  ];
  isAgreed = false;
  toolTipVisible: boolean = false;

  constructor(private location: Location, private fb: FormBuilder) {}
  email_Addresses: EmailAddress[] = [];

  ngOnInit() {
    this.initializeFitnessForm();
    this.email_Addresses = [
      {
        title: "",
        emailAddress: "J**@yopmail.com",
        formName: "",
        hide: false
      }
      // {
      //   title: "",
      //   emailAddress: "M**@yopmail.com",
      //   // emailAddress: "",
      //   formName: "",
      //   hide: false
      // }
    ];
  }
  initializeFitnessForm() {
    const totalRequestAmount = "";
    const formGroup = {
      totalrequestamount: [totalRequestAmount, Validators.required],
      programName: ["", Validators.required],
      address: ["", Validators.required],
      state: ["", Validators.required],
      zip: ["", Validators.required],
      phoneNumber: ["", Validators.required],
      termsAndConditions: ["", Validators.required],
      email: ["", Validators.required],
      additionalemail: ["", Validators.required]
    };
    this.fitnessForm = this.fb.group(formGroup);
    this.fitnessForm.patchValue({ state: "Massachusetts" });
    this.showForm = true;
  }
  removeEmail($event: { email: EmailAddress; e: any }) {
    let email_address = $event.email;
    this.email_Addresses.splice(this.email_Addresses.indexOf(email_address), 1);
  }

  onBackPressed() {
    this.location.back();
  }
  onSubmit() {
    this.isFormSubmitted = true;
  }
  showToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }
  termsAndConditionsChange() {
    this.isAgreed = !this.isFormSubmitted;
  }
}
