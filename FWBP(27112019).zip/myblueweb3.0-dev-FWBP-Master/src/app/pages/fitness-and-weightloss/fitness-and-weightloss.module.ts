import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FitnessFormComponent } from './fitness-form/fitness-form.component';
import { WeightlossFormComponent } from './weightloss-form/weightloss-form.component';
import { DownloadReimbursementComponent } from './download-reimbursement/download-reimbursement.component';
import { FitnessAndWeightlossRouter } from './fitness-and-weightloss.routing';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FitnessAndWeightlossRouter,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [FitnessFormComponent, WeightlossFormComponent, DownloadReimbursementComponent]
})
export class FitnessAndWeightlossModule { }
