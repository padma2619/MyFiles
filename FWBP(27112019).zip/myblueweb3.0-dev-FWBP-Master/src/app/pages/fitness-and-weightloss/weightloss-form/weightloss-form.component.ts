import { ProgramInformationComponent } from "./../../../shared/components/program-information/program-information.component";
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Location } from "@angular/common";
import { EmailAddress } from "../../../shared/components/email/EmailAddressInterface";

@Component({
  selector: "app-weightloss-form",
  templateUrl: "./weightloss-form.component.html",
  styleUrls: ["./weightloss-form.component.scss"]
})
export class WeightlossFormComponent implements OnInit {
  fitnessForm: FormGroup;
  isFormSubmitted = false;
  showForm = false;
  isAgreed = false;
  toolTipVisible: boolean = false;

  constructor(private location: Location, private fb: FormBuilder) {}
  email_Addresses: EmailAddress[] = [];

  ngOnInit() {
    this.initializeFitnessForm();
    this.email_Addresses = [
      {
        title: "",
        emailAddress: "J**@yopmail.com",
        formName: "",
        hide: false
      }
      // ,
      // {
      //   title:'',
      //   emailAddress:'M**@yopmail.com',
      //   formName:'',
      //    hide:false

      // }
    ];
  }
  initializeFitnessForm() {
    let totalRequestAmount = "";
    const formGroup = {
      totalrequestamount: [totalRequestAmount, [Validators.required]],
      programName: ["", Validators.required],
      address: ["", Validators.required],
      state: ["", Validators.required],
      zip: ["", Validators.required],
      phoneNumber: ["", Validators.required],
      termsAndConditions: ["", [Validators.required]],
      email: ["", Validators.required],
      additionalemail: ["", Validators.required]
    };
    this.fitnessForm = this.fb.group(formGroup);
    this.fitnessForm.patchValue({ state: "Massachusetts" });
    this.showForm = true;
  }
  onBackPressed() {
    this.location.back();
  }
  onSubmit() {
    this.isFormSubmitted = true;
  }
  termsAndConditionsChange() {
    this.isAgreed = !this.isFormSubmitted;
  }
  showToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }
}
