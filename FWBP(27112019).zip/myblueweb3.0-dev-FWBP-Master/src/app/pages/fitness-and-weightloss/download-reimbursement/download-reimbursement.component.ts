import { SelectionService } from './../../../shared/services/downloadForm/selection.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-download-reimbursement',
  templateUrl: './download-reimbursement.component.html',
  styleUrls: ['./download-reimbursement.component.scss']
})
export class DownloadReimbursementComponent implements OnInit {
  reimbursementForm: FormGroup;
  isFormSubmitted = false;
  showForm = false;
  buttonCopy: string = 'Download';
  benefitData: any;
  disableType = true;
  displayFitness = true;
  displayWeightLoss = true;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private downloadData: SelectionService
  ) { }

  ngOnInit() {
    this.initializeReimbursementsForm();
  }

  initializeReimbursementsForm() {
    this.downloadData.getYear().subscribe(response => {
      if (response) {
        this.benefitData = response.benefits;
        console.log('this.benefitData = ');
        console.log(this.benefitData);
      }
    });

    const formGroup = {
      year: ['', Validators.required],
      typeOfReimbursement: ['', [Validators.required]]
    };
    this.reimbursementForm = this.fb.group(formGroup);

    this.showForm = true;
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.checkSelectedForm();
  }

  checkSelectedForm() {
    const typeOfReimbursement: string = this.reimbursementForm.get(
      'typeOfReimbursement'
    ).value;
    const selectedYear = this.reimbursementForm.get('year').value;
    this.benefitData.forEach(benefit => {
      if (benefit.year.toString() === selectedYear && benefit.fitness && benefit.fitness.onlineSubmissionEligible) {
        this.routeToForm(typeOfReimbursement);
      }
      if (benefit.year.toString() === selectedYear && benefit.weightloss && benefit.weightloss.onlineSubmissionEligible) {
        this.routeToForm(typeOfReimbursement);
      }
      if (benefit.year.toString() === selectedYear && benefit.weightloss && !benefit.weightloss.onlineSubmissionEligible ||
        benefit.year.toString() === selectedYear && benefit.fitness && !benefit.fitness.onlineSubmissionEligible) {
        this.downLoadForm(typeOfReimbursement);
      }
    });
  }

  routeToForm(typeOfReimbursement: string) {
    if (typeOfReimbursement === 'fitness') {
      this.navigateToFitness();
    } else {
      this.navigateToWeightloss();
    }
  }

  navigateToFitness() {
    this.router.navigate(['fitness-and-weightloss/fitness-form']);
  }

  navigateToWeightloss() {
    this.router.navigate(['fitness-and-weightloss/weightloss-form']);
  }

  downLoadForm(typeOfReimbursement: string) {
    typeOfReimbursement === 'fitness'
      ? this.downloadFitness()
      : this.downloadWeightloss();
  }

  downloadFitness() {
    window.open(
      'http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0763_Fitness_Reimbursement_Form.pdf',
      '_self',
      'Fitness_Reimbursement_Form.pdf'
    );
  }

  downloadWeightloss() {
    window.open(
      'http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0764_Weight_Loss_Reimbursement_Form.pdf',
      '_self',
      'Weight_Loss_Reimbursement_Form.pdf'
    );
  }


  onChange() {
    const selectedYear = this.reimbursementForm.get('year').value;
    this.benefitData.forEach(benefit => {
      if (benefit.year.toString() === selectedYear) {
        this.setDisplayType(benefit);
        this.setCTAButton(benefit);
      }
    });
    this.disableType = !this.disableType;
  }

  setCTAButton(benefit) {
    if (
      this.displayFitness && benefit.fitness.onlineSubmissionEligible
      || this.displayWeightLoss && benefit.weightloss.onlineSubmissionEligible) {
      this.buttonCopy = 'Continue';
    }
  }

  setDisplayType(benefit) {
    this.displayFitness = benefit.fitness !== undefined;
    this.displayWeightLoss = benefit.weightloss !== undefined;

  }
}
