import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { MyAccountService } from './myaccount.service';
import { AuthService } from '../../shared/shared.module';

@Injectable()
export class MyaccountResolver implements Resolve<any> {
  isRegisteredUser: boolean;

  constructor(private myaccountService: MyAccountService,
    private authService: AuthService) {
  }

  async resolve() {
    //myaccountinfo service response caching mechanism is added to facilitate a solution for the new request https://bcbsma.atlassian.net/browse/KLO-470
    let cachedMyAccountInfo = sessionStorage.getItem('myAccountInfo');
    if (cachedMyAccountInfo) {
      return JSON.parse(cachedMyAccountInfo);
    } else {
      this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
      if (!this.isRegisteredUser) {
        const myAccountInfo = await forkJoin([
          this.fetchMyAccountInfo()
        ]).toPromise();

        sessionStorage.setItem('myAccountInfo', JSON.stringify(myAccountInfo));

        return myAccountInfo;
      }
    }
  }


  fetchMyAccountInfo() {
    this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
    if (!this.isRegisteredUser) {
      return this.myaccountService.getAccountInfo();
    }
  }

}
