import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
  MatSelectModule, MatRadioModule, MatCardModule, MatIconModule, MatSidenavModule, MatDialogModule,
  MatTooltipModule, MatGridListModule, MatFormFieldModule
} from '@angular/material';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { FormBuilder, FormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'
import { TextMaskModule } from 'angular2-text-mask';
import { StorageServiceModule } from 'angular-webstorage-service';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { of } from 'rxjs/observable/of';
import { GeneralError } from '../../../shared/models/generic-app.model';
import { FakeRouterLinkDirectiveStub, FakeParentFormFieldDirectiveStub } from '../../../../jasmine/fake-directives';
import {
  FakeControlMessagesComponent, FakeFadBreadCrumbsComponent, FakeCostBreakdownFilterComponent,
  FakeAlegeusLineChartComponent, FakeBreadcrumbsComponent,
  FakeFpoLayoutComponent, FakePasswordControlMessages
} from '../../../../jasmine/fake-components';
import { UpdatePasswordComponent } from './update-password.component';
import { ValidationService } from '../../../shared/shared.module';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { jasAVUserData } from '../../../../jasmine/data/my-profile/avUser.data';
import { updateDemographicInfo_success_response } from '../../../../jasmine/data/my-profile/updateDemographicInfo.data';
import { getDemographicInfo_response } from '../../../../jasmine/data/my-profile/getDemographicInfo.data';
import { updatePassword_success_response } from '../../../../jasmine/data/my-profile/updatePassword.data';
import { mocks } from '../../../../jasmine/constants/mocks.service';

describe('UpdatePasswordComponent', () => {
  let component: UpdatePasswordComponent;
  let fixture: ComponentFixture<UpdatePasswordComponent>;

  let mockRouter;
  let mockAlertService;
  let mockProfileService;
  let mockValidationService;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    mockRouter = jasmine.createSpyObj(['navigate']);
    mockRouter.navigate.and.returnValue({
      then: jasmine.createSpy('then')
    });

    mockAlertService = jasmine.createSpyObj(['clearError', 'setAlert']);//mock.service.AlertService;
    mockAlertService.clearError.and.returnValue(null);
    mockAlertService.setAlert.and.returnValue(null);

    mockProfileService = mocks.service.profileService;
    mockProfileService.getUserRole.and.returnValue(jasAVUserData.getMemProfileApiResponse.userState);
    mockProfileService.setProfile.and.returnValue(null);
    mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
    mockProfileService.fetchProfileInfo.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
    mockProfileService.updateProfile.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
    mockProfileService.sendcommchlaccesscode.and.returnValue(of(new GeneralError()));
    mockProfileService.getDemoGraphicInfo.and.returnValue(of(getDemographicInfo_response));
    mockProfileService.updateDemographicInfo.and.returnValue(of(updateDemographicInfo_success_response));
    mockProfileService.updatePassword.and.returnValue(of(updatePassword_success_response));

    mockValidationService = mocks.service.validationService;
    mockValidationService.invalidPasswordValidatorWrapper.and.returnValue(() => true);
    mockValidationService.samePasswordValidator.and.returnValue(() => true);
    mockValidationService.checkConfirmPasswordValidator.and.returnValue(() => true);

    mockRouter = mocks.service.router;
    mockRouter.navigate.and.returnValue(new Promise((resolve, reject) => {
      // do something asynchronous
      resolve();
    }));


    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeRouterLinkDirectiveStub,
        FakeParentFormFieldDirectiveStub,
        FakeControlMessagesComponent,
        FakeFadBreadCrumbsComponent,
        FakeCostBreakdownFilterComponent,
        FakeAlegeusLineChartComponent,
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakePasswordControlMessages,

        UpdatePasswordComponent
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: FormBuilder, useValue: formBuilder }

      ]

    })
      .compileComponents();
  }));

  describe('Constructor', () => {
    describe('While Component Creation', () => {  // assert constructor contents
      describe('should have initialized', () => {
        beforeEach(() => {
          //arrange

          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;
        })
        it('should have initialized updatePasswordForm form', () => {
          //assert
          expect(component.updatePasswordForm).toBeTruthy();
        });

        it('should have initialized this.typeCurrent to "password"', () => {
          expect(component.typeCurrent).toBe('password');
        });

        it('should have initialized this.typePlaceholderCurrent to "Show"', () => {
          expect(component.typePlaceholderCurrent).toBe('Show');
        });

        it('should have initialized this.typeNew to "password"', () => {
          expect(component.typeNew).toBe('password');
        });

        it('should have initialized this.typePlaceholderNew to "Show"', () => {
          expect(component.typePlaceholderNew).toBe('Show');
        });
      });

      describe('should have called', () => {
        xit('should have called newPassword field\'s setValidator method', () => {

          UpdatePasswordComponent.prototype.updatePasswordForm = formBuilder.group({
            currentPassword: ['', [Validators.required]],
            newPassword: ['', []],
            reEnterNewPassword: ['', []]
          });

          let target = UpdatePasswordComponent.prototype.updatePasswordForm.controls['newPassword'];

          let targetSpy = spyOn(target, 'setValidators').and.returnValue(null);
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(targetSpy).toHaveBeenCalled();
        });

        xit('should have called reEnterNewPassword field\'s setValidator method', () => {
          let fb = new FormBuilder();
          UpdatePasswordComponent.prototype.updatePasswordForm = fb.group({
            currentPassword: ['', [Validators.required]],
            newPassword: ['', []],
            reEnterNewPassword: ['', []]
          });
          let target = UpdatePasswordComponent.prototype.updatePasswordForm.controls['newPassword'];
          let targetSpy = spyOn(target, 'setValidators').and.returnValue(null);
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(targetSpy).toHaveBeenCalled();
        });

        it('should have called validationService.invalidPasswordValidatorWrapper', () => {
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(mockValidationService.invalidPasswordValidatorWrapper).toHaveBeenCalled();
        });

        it('should have called validationService.samePasswordValidator', () => {
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(mockValidationService.samePasswordValidator).toHaveBeenCalled();
        });

        it('should have called validationService.checkConfirmPasswordValidator', () => {
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(mockValidationService.checkConfirmPasswordValidator).toHaveBeenCalled();
        });

        it('should have called Validators.minLength to have been called once', () => {
          //arrange
          spyOn(Validators, 'minLength').and.returnValue({ confirmPassword: true })
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(Validators.minLength).toHaveBeenCalledTimes(1);
        });

        it('should have called this.alertService.clearError', () => {
          //arrange
          fixture = TestBed.createComponent(UpdatePasswordComponent);

          //act
          component = fixture.componentInstance;

          //assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        });

      });

    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      //arrange
      fixture = TestBed.createComponent(UpdatePasswordComponent);
      component = fixture.componentInstance;

      //act
      component.ngOnInit();
      //fixture.detectChanges();
    });

    it('should have initialized this.typeCurrent to "password"', () => {
      expect(component.typeCurrent).toBe('password');
    });
    it('should have initialized this.typePlaceholderCurrent to "Show"', () => {
      expect(component.typePlaceholderCurrent).toBe('Show');
    });
    it('should have initialized this.typeNew to "password"', () => {
      expect(component.typeNew).toBe('password');
    });
    it('should have initialized this.typeReEnterNew to "password"', () => {
      expect(component.typeReEnterNew).toBe('password');
    });
    it('should have initialized this.typePlaceholderNew to "Show"', () => {
      expect(component.typePlaceholderNew).toBe('Show');
    });
    it('should have initialized this.typePlaceholderReEnterNew to "Show"', () => {
      expect(component.typePlaceholderReEnterNew).toBe('Show');
    });

  });

  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.ngOnDestroy();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('currentPasswordKeyUp', () => {
      it('should do something', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        let newPassword = 'my=new-pass-word';
        component.updatePasswordForm.controls['newPassword'].setValue(newPassword);
        let spyObj = spyOn(component.updatePasswordForm.controls['newPassword'], 'setValue').and.returnValue(null);
        component.currentPasswordKeyUp();
        //assert
        expect(spyObj).toHaveBeenCalledWith(newPassword)
      });
    });

    describe('togglecurrentPasswordVisibility', () => {
      beforeEach(() => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;
      })
      it('should set this.typeCurrent to "password" if its value is "text" prior to the function call', () => {
        //act
        component.typeCurrent = 'text';
        component.togglecurrentPasswordVisibility();

        //assert
        expect(component.typeCurrent).toBe('password');
      });
      it('should set this.typePlaceholderCurrent to "show" if this.typeCurrent value is "text" prior to the function call', () => {
        //act
        component.typeCurrent = 'text';
        component.togglecurrentPasswordVisibility();

        //assert
        expect(component.typePlaceholderCurrent).toBe('Show');
      });

      it('should set this.typeCurrent to "text" if its value is "password" prior to the function call', () => {
        //act
        component.typeCurrent = 'password';
        component.togglecurrentPasswordVisibility();

        //assert
        expect(component.typeCurrent).toBe('text');
      });

      it('should set this.typePlaceholderCurrent to "Hide" if this.typeCurrent value is "password" prior to the function call', () => {
        //act
        component.typeCurrent = 'password';
        component.togglecurrentPasswordVisibility();

        //assert
        expect(component.typePlaceholderCurrent).toBe('Hide');
      });
    });

    describe('togglenewPasswordVisibility', () => {
      beforeEach(() => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;
      });
      describe('when called with param confirmPassword=true', () => {
        describe('when this.typeReEnterNew = "text"', () => {
          it('should change the value of component.typeReEnterNew to "password"', () => {
            //arrange
            component.typeReEnterNew = 'text';

            //act
            component.togglenewPasswordVisibility(true);

            //assert
            expect(component.typeReEnterNew).toBe('password');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Show"', () => {
            //arrange
            component.typeReEnterNew = 'text';

            //act
            component.togglenewPasswordVisibility(true);

            //assert
            expect(component.typePlaceholderReEnterNew).toBe('Show');
          });
        });
        describe('when this.typeReEnterNew = "password"', () => {
          it('should change the value of component.typeReEnterNew to "text"', () => {
            //arrange
            component.typeReEnterNew = 'password';

            //act
            component.togglenewPasswordVisibility(true);

            //assert
            expect(component.typeReEnterNew).toBe('text');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Hide"', () => {
            //arrange
            component.typeReEnterNew = 'password';

            //act
            component.togglenewPasswordVisibility(true);

            //assert
            expect(component.typePlaceholderReEnterNew).toBe('Hide');
          });
        });
      });
      describe('when called with param confirmPassword=false', () => {
        describe('when this.typeNew = "text"', () => {
          it('should change the value of component.typeNew to "password"', () => {
            //arrange
            component.typeNew = 'text';

            //act
            component.togglenewPasswordVisibility(false);

            //assert
            expect(component.typeNew).toBe('password');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Show"', () => {
            //arrange
            component.typeNew = 'text';

            //act
            component.togglenewPasswordVisibility(false);

            //assert
            expect(component.typePlaceholderNew).toBe('Show');
          });
        });
        describe('when this.typeNew = "password"', () => {
          it('should change the value of component.typeNew to "text"', () => {
            //arrange
            component.typeNew = 'password';

            //act
            component.togglenewPasswordVisibility(false);

            //assert
            expect(component.typeNew).toBe('text');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Hide"', () => {
            //arrange
            component.typeNew = 'password';

            //act
            component.togglenewPasswordVisibility(false);

            //assert
            expect(component.typePlaceholderNew).toBe('Hide');
          });
        });
      });
    });

    describe('onSubmit', () => {
      it('should have updated this.isFormSubmitted to true', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.onSubmit();

        //assert
        expect(component.isFormSubmitted).toBeTruthy();

      });
      it('should have called this.alertService.clearError', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.onSubmit();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();

      });
      it('should have called this.profileService.updatePassword', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.onSubmit();

        //assert
        expect(mockProfileService.updatePassword).toHaveBeenCalled();

      });
      it('should have called this.profileService.updatePassword', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.onSubmit();

        //assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/myprofile']);

      });

      xit('should have called this.alertService.setAlert', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.onSubmit();

        //assert
        expect(mockAlertService.setAlert).toHaveBeenCalledWith('Success! Your password has been changed!',
          '',
          AlertType.Success);

      });


    });

    describe('showErrorOnBlur', () => {
      it('should update this.showReEnterPasswordErrors to true, when called with param : confirmPassword=true', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.showErrorOnBlur(true);

        //assert
        expect(component.showReEnterPasswordErrors).toBeTruthy();
      });

      it('should update this.showPasswordErrors to true, when called with param : confirmPassword=false', () => {
        //arrange
        fixture = TestBed.createComponent(UpdatePasswordComponent);
        component = fixture.componentInstance;

        //act
        component.showErrorOnBlur(false);

        //assert
        expect(component.showPasswordErrors).toBeTruthy();
      });
    });
  });
});
