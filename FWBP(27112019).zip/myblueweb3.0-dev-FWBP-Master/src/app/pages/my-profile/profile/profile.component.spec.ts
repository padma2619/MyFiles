import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProfileComponent } from './profile.component';

import {
  MatSelectModule, MatRadioModule, MatCardModule, MatIconModule,
  MatSidenavModule, MatDialogModule, MatDialog, MatTooltipModule,
  MatGridListModule, MatFormFieldModule
} from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AlertService } from '../../../shared/services/alert.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { NotificationPreferencesService } from '../../notification-preferences/notification-preferences.service';
import { FormBuilder, FormsModule } from '@angular/forms';
import { AuthService } from '../../../shared/services/auth.service';
import { CommonModule } from '@angular/common';
import { CamelcasePipe } from '../../../shared/pipes/camelcase/camelcase.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { ReactiveFormsModule } from '@angular/forms'
import { TextMaskModule } from 'angular2-text-mask';
import { StorageServiceModule } from 'angular-webstorage-service';
import { Location } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { of } from 'rxjs/observable/of';
import { GeneralError } from '../../../shared/models/generic-app.model';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { FakeParentFormFieldDirectiveStub, FakeRouterLinkDirectiveStub } from '../../../../jasmine/fake-directives';
import {
  FakeControlMessagesComponent, FakeFadBreadCrumbsComponent, FakeAlegeusLineChartComponent,
  FakeCostBreakdownFilterComponent, FakeBreadcrumbsComponent, FakeFpoLayoutComponent
} from '../../../../jasmine/fake-components';
import { jasAVUserData } from '../../../../jasmine/data/my-profile/avUser.data';
import { mocks } from '../../../../jasmine/constants/mocks.service';

describe('ProfileComponent', () => {
  let component: ProfileComponent;
  let fixture: ComponentFixture<ProfileComponent>;

  let mockRouter;
  let mockLocation;
  let mockActivatedRoute;
  let mockAuthHttp;
  let mockAlertService;
  let mockValidationService;
  let mockConstantsService;
  let mockGlobalService;
  let mockNotificationPreferencesService;
  let mockMatDialog;
  let mockAuthService;
  let mockProfileService;

  let mockAuthHttp_dummyResponse = { someDecryptedResponse: '' }; //to be configured

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    mockRouter = mocks.service.router;
    mockRouter.navigate.and.returnValue(new Promise((resolve, reject) => {
      // do something asynchronous
      resolve();
    }));

    mockLocation = {
      assign: (url: string) => url,
      reload: (forcedReload?: boolean) => true,
      replace: (url: string) => url,
      path: () => 'url-path'
    };
    mockActivatedRoute = {
      snapshot: {
        data: {
          profile: jasAVUserData.getMemProfileApiResponse
        }
      }
    };
    mockAuthHttp = jasmine.createSpyObj(['uuid', 'handleDecryptedResponse']);
    mockAuthHttp.handleDecryptedResponse.and.returnValue(mockAuthHttp_dummyResponse);

    mockAlertService = jasmine.createSpyObj(['clearError', 'setAlert']);
    mockAlertService.clearError.and.returnValue(null);
    mockAlertService.setAlert.and.returnValue(null);

    mockValidationService = jasAVUserData.validationService;
    mockConstantsService = jasAVUserData.constantsService;
    // mockGlobalService = [];

    mockNotificationPreferencesService = jasAVUserData.commPreferenceService;

    // mockMatDialog = [];
    mockAuthService = {
      authToken: jasAVUserData.authToken,
      isSubscriber: true
    };
    mockAuthHttp.uuid.and.returnValue(jasAVUserData.authHttp.uuid);

    mockProfileService = jasmine.createSpyObj(['getUserRole', 'setProfile', 'getProfile',
      'fetchProfileInfo', 'updateProfile', 'sendcommchlaccesscode', 'sendaccesscode']);
    mockProfileService.authService = mockAuthService;

    mockProfileService.getUserRole.and.returnValue(jasAVUserData.getMemProfileApiResponse.userState);
    mockProfileService.setProfile.and.returnValue(null);
    mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
    mockProfileService.fetchProfileInfo.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
    mockProfileService.updateProfile.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
    mockProfileService.sendcommchlaccesscode.and.returnValue(of(new GeneralError()));

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeRouterLinkDirectiveStub,
        FakeParentFormFieldDirectiveStub,
        FakeControlMessagesComponent,
        FakeFadBreadCrumbsComponent,
        FakeCostBreakdownFilterComponent,
        FakeAlegeusLineChartComponent,
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,

        ProfileComponent,
        CamelcasePipe,
        YyyymmddTommddyyyyPipe,
        PhonePipe

      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: Location, useValue: mockLocation },
        // Location,
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: NotificationPreferencesService, useValue: mockNotificationPreferencesService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: MatDialog, useValue: mockMatDialog },
        { provide: AuthService, useValue: mockAuthService }
      ]

    })
      .compileComponents();
  }));



  describe('Constructor', () => {
    describe('While Component Creation', () => {  // assert constructor contents
      it('should have called resetAllEdits', () => {
        //arrange
        spyOn(ProfileComponent.prototype, 'resetAllEdits');
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act        
        fixture.detectChanges();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });

      it('should have obtained the user id', () => {
        pending();
        //arrange
        ProfileComponent.prototype.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        ProfileComponent.prototype.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        spyOn(Storage.prototype, 'getItem').and.returnValue(jasAVUserData.getMemProfileApiResponse.useridin);

        //act 
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        //component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;


        //fixture.detectChanges();

        //assert
        expect(component.useridin).not.toBeNull();
      });
      it('should have been categorized into a email type or a mobile number type usedid', () => {
        pending();
        //arrange
        ProfileComponent.prototype.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        ProfileComponent.prototype.useridin = jasAVUserData.getMemProfileApiResponse.useridin;
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        // component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        // component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act       
        fixture.detectChanges();
        const isUseridAPhone: boolean = component.isUseridAPhone
        const isUseridAEmail: boolean = component.isUseridAEmail

        const isTruthyId = isUseridAPhone || isUseridAEmail;

        //assert
        expect(isTruthyId).toBeTruthy();
      });
      it('should obtain the user id', () => {
        pending();
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act       
        fixture.detectChanges();

        //assert
        expect(component.diplayUserID).not.toBeNull();
      });
      it('should create a valid diplayUserID', () => {
        pending();
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act       
        fixture.detectChanges();

        //assert
        expect(component.diplayUserID).not.toBeNull();
      });
      it('should define default values for the attributes type=password and typePlaceholder=Show', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act       
        fixture.detectChanges();

        //assert
        expect(component.type).toBe('password')
        expect(component.typePlaceholder).toBe('Show');
      });
      it('should create', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act       
        fixture.detectChanges();

        //assert
        expect(component).toBeTruthy();
      });
    });

  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(ProfileComponent);
      component = fixture.componentInstance;

      component.memProfile = jasAVUserData.getMemProfileApiResponse;
      component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

    });

    it('should have called ngOnInit', () => {
      //arrange
      spyOn(component, 'ngOnInit');

      //act
      fixture.detectChanges();

      //assert
      expect(component.ngOnInit).toHaveBeenCalled();
    });

    describe('should have internally did the following while executing ngOnInit', () => {
      it('should have called "formatPhone" method', () => {
        //arrange
        spyOn(component, 'formatPhone');

        //act
        fixture.detectChanges();

        //assert
        expect(component.formatPhone).toHaveBeenCalled();
      });
      it('should have called ProfileService.getUserRole method', () => {

        //act
        fixture.detectChanges();

        //assert
        expect(mockProfileService.getUserRole).toHaveBeenCalled();
      });

      it('should have called component.profileEditForm.patchValue method with modified memProfile response', () => {

        //arrange
        spyOn(component.profileEditForm, 'patchValue');

        //act
        fixture.detectChanges();

        //assert
        expect(component.profileEditForm.patchValue).toHaveBeenCalledWith(jasAVUserData.getMemProfile_After_NgOnint);
      });

      it('should have called ProfileService.setProfile method with modified memProfile response', () => {

        //act
        fixture.detectChanges();

        //assert
        expect(mockProfileService.setProfile).toHaveBeenCalledWith(jasAVUserData.getMemProfile_After_NgOnint);
      });

      it('should have assigned phoneType if its empty in api resposne', () => {
        //act
        fixture.detectChanges();
        let phoneType = jasAVUserData.getMemProfileApiResponse.phoneType;
        if (!phoneType) {
          expect(component.profile.phoneType).toBe('MOBILE');

        }

        expect(true).toBeTruthy();
      });

      it('should have assigned value to diplayEmailAdress from api resposne', () => {
        //act
        fixture.detectChanges();

        //assert
        expect(component.diplayEmailAdress).toBe(jasAVUserData.getMemProfile_After_NgOnint.emailAddress);
      });
    });

  });

  describe('Methods', () => {

    describe('maskPhoneNumberId', () => {

      it('should modify the phone number in user id to xxx-xxx-xxxx format', () => {

        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //act        
        let result = component.maskPhoneNumberId('1234567890');

        //assert
        expect(result).toBe('123-456-7890');
      });
    });

    describe('addressEdit', () => {
      it('should have called this.resetAllEdits', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.addressEdit();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });

      it('should have called this.getFormDefinition', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.addressEdit();

        //assert
        expect(component.getFormDefinition).toHaveBeenCalled();
      });

      it('should have called this.alertService.clearError', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.addressEdit();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('emailEdit', () => {
      it('should have called this.resetAllEdits', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.emailEdit();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });

      it('should have called this.getFormDefinition', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.emailEdit();

        //assert
        expect(component.getFormDefinition).toHaveBeenCalled();
      });

      it('should have called this.alertService.clearError', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.emailEdit();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('phoneEdit', () => {
      it('should have called this.resetAllEdits', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.phoneEdit();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });

      it('should have called this.getFormDefinition', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.phoneEdit();

        //assert
        expect(component.getFormDefinition).toHaveBeenCalled();
      });

      it('should have called this.alertService.clearError', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.phoneEdit();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('hintEdit', () => {
      it('should have called this.resetAllEdits', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.hintEdit();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });

      it('should have called this.getFormDefinition', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.hintEdit();

        //assert
        expect(component.getFormDefinition).toHaveBeenCalled();
      });

      it('should have called this.alertService.clearError', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);
        spyOn(component, 'getFormDefinition').and.returnValue(null);
        //act        
        component.hintEdit();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('togglePasswordVisibility', () => {
      it('hide text', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        fixture.detectChanges();

        //act  
        component.type = "text";
        component.togglePasswordVisibility();

        //assert        
        expect(component.type).toBe('password');
      });
      it('show text', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.memProfile = jasAVUserData.getMemProfileApiResponse.useridin;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        fixture.detectChanges();

        //act  
        component.type = "password";
        component.togglePasswordVisibility();

        //assert        
        expect(component.type).toBe('text');
      });
    });

    describe('cancel', () => {
      it('should have called this.resetAllEdits', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);

        //act        
        component.cancel();

        //assert
        expect(component.resetAllEdits).toHaveBeenCalled();
      });
      it('should have called this.profileService.fetchProfileInfo', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'resetAllEdits').and.returnValue(null);

        //act        
        component.cancel();

        //assert
        expect(mockProfileService.fetchProfileInfo).toHaveBeenCalled();
      });

    });

    describe('showEdit', () => {
      it('should return a proper boolean value ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        const assertValue = component.profile.userState !== 'REGISTERED-NOT-VERIFIED'
          && !mockProfileService.authService.isSubscriber
          && component.profileEditForm.value.isEditableAddress

        //act        
        const runtimeValue = component.showEdit();

        //assert
        expect(runtimeValue).toEqual(assertValue);
      });
    });

    describe('fetchProfileInfo', () => {
      it('should have called profileService.fetchProfileInfo ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.fetchProfileInfo()

        //assert
        expect(mockProfileService.fetchProfileInfo).toHaveBeenCalled();
      });
    });

    describe('onSubmit', () => {
      it('should have called this.profileEditForm.patchValue to have been called with updateProfileResponse', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        spyOn(component.profileEditForm, 'patchValue')

        fixture.detectChanges();

        //act        
        component.onSubmit();

        //assert
        expect(component.profileEditForm.patchValue).toHaveBeenCalledWith(jasAVUserData.getMemProfileApiResponse);
      });

      it('should have called profileService.setProfile to have been called with updateProfileResponse', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.onSubmit();

        //assert
        expect(mockProfileService.setProfile).toHaveBeenCalledWith(jasAVUserData.getMemProfileApiResponse);
      });

      it('should have called profileService.updateProfile', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.onSubmit();

        //assert
        expect(mockProfileService.updateProfile).toHaveBeenCalled();
      });

      it('should compile with out errors when result code is -90129', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        jasAVUserData.getMemProfileApiResponse['result'] = -90129;
        spyOn(component, 'onSubmit');
        //act        
        component.onSubmit();

        //assert
        expect(component.onSubmit).not.toThrowError();
      });

      it('should compile with out errors when result code is -90124', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        jasAVUserData.getMemProfileApiResponse['result'] = -90124;
        spyOn(component, 'onSubmit');
        //act        
        component.onSubmit();

        //assert
        expect(component.onSubmit).not.toThrowError();
      });

      it('should compile with out errors when result code is -90126', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        jasAVUserData.getMemProfileApiResponse['result'] = -90126;
        spyOn(component, 'onSubmit');
        //act        
        component.onSubmit();

        //assert
        expect(component.onSubmit).not.toThrowError();
      });

      it('should compile with out errors when result code is 0', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        jasAVUserData.getMemProfileApiResponse['result'] = 0;
        jasAVUserData.getMemProfileApiResponse['displaymessage'] = 'SUCCESS';
        spyOn(component, 'onSubmit');
        //act        
        component.onSubmit();

        //assert
        expect(component.onSubmit).not.toThrowError();
      });



    });

    describe('resetAllEdits', () => {
      it('should have updated this.editAddress as false ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.resetAllEdits();

        //assert
        expect(component.editAddress).not.toBeTruthy();
      });
      it('should have updated this.editHint as false ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.resetAllEdits();

        //assert
        expect(component.editHint).not.toBeTruthy();
      });
    });

    describe('getFormDefinition', () => {
      it('should have called profileService.getProfile', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.getFormDefinition();

        //assert
        expect(mockProfileService.getProfile).toHaveBeenCalled();
      });

      it('should have called this.formatPhone', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        spyOn(component, 'formatPhone');

        fixture.detectChanges();

        //act        
        component.getFormDefinition();

        //assert
        expect(component.formatPhone).toHaveBeenCalled();
      });

      it('should have called this.profileEditForm.patchValue', () => {
        pending();
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        spyOn(component.profileEditForm, 'patchValue').and.returnValue(null);

        fixture.detectChanges();

        //act        
        component.getFormDefinition();

        //assert
        expect(component.profileEditForm.patchValue).toHaveBeenCalled();
      });
    });

    describe('getDefaultOptionForPhoneNumberType', () => {
      it('should enforce phoneType as MOBILE for valid profile object', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.profile.phoneType = null;
        component.getDefaultOptionForPhoneNumberType();

        //assert
        expect(component.profile.phoneType).toBe('MOBILE');
      });
    });

    describe('getDefaultOptionForPhoneNumber', () => {
      it('should enforce phoneNumber as empty string( i.e. "") for invalid profile.phoneNumber', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.profile.phoneNumber = '';
        component.getDefaultOptionForPhoneNumber();

        //assert
        expect(component.profile.phoneNumber).toBe('');
      });

      it('should not change phoneNumber for valid profile.phoneNumber', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        component.profile.phoneNumber = '8659568745';
        component.getDefaultOptionForPhoneNumber();

        //assert
        expect(component.profile.phoneNumber).toBe('8659568745');
      });


    });

    describe('getDefaultOptionForSecurityQuestions', () => {
      it('should return HintQuestion if the user profile is valid ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        component.memProfile = jasAVUserData.getMemProfileApiResponse;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        fixture.detectChanges();

        //act        
        let result = component.getDefaultOptionForSecurityQuestions()

        //assert
        expect(result).toBe(jasAVUserData.getMemProfileApiResponse.hintQuestion);
      });

      it('should not return anything if the user profile is invalid ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act    
        component.profile = null;
        let result = component.getDefaultOptionForSecurityQuestions()

        //assert
        expect(result).toBeUndefined();
      });
    });

    describe('verifyEmail', () => {
      beforeEach(() => {
        spyOn(sessionStorage.__proto__, 'setItem');
      })
      it('should have called alertService.clearError ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        component.memProfile = jasAVUserData.getMemProfileApiResponse;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act        
        fixture.detectChanges();
        component.verifyEmail();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
      describe('should have called this.sendcommchlaccesscode for AV and RV users ', () => {
        describe('Parameters', () => {
          it('should have been called with display email address in getMemProfileResponse if called with no parameters ', () => {
            //arrange        
            fixture = TestBed.createComponent(ProfileComponent);
            component = fixture.componentInstance;

            //act    
            fixture.detectChanges();
            spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({}));

            component.verifyEmail();

            //assert
            expect(component['sendcommchlaccesscode']).toHaveBeenCalledWith(component.diplayEmailAdress, '');
          });

          it('should have been called with the provided email address ', () => {
            //arrange        
            fixture = TestBed.createComponent(ProfileComponent);
            component = fixture.componentInstance;

            //act    
            fixture.detectChanges();
            spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({}));

            let emailAddress = "testMailAddress@testDomain.com"
            component.verifyEmail(emailAddress);

            //assert
            expect(component['sendcommchlaccesscode']).toHaveBeenCalledWith(emailAddress, '');
          });
        });

        describe('sendcommchlaccesscode api "response.result" Code', () => {
          describe('when result code is 0', () => {
            beforeEach(() => {
              //arrange        
              fixture = TestBed.createComponent(ProfileComponent);
              component = fixture.componentInstance;

              //act  
              spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '0' }));
              spyOn(component, 'navigateToVerifyScreen');
              spyOn(component, 'maskEmailId').and.returnValue('testEmail@testDomain.com');
              fixture.detectChanges();

              component.verifyEmail();
            });

            it('should have called alertService.clearError', () => {
              //assert
              expect(mockAlertService.clearError).toHaveBeenCalled();
            });
            it('should have called this.maskEmailId with diplayEmailAdress in component', () => {
              //assert
              expect(component.maskEmailId).toHaveBeenCalledWith(component.diplayEmailAdress);
            });

            it('should have called this.maskEmailId with parameter emailAdress if its valid', () => {
              //act
              let testEmail = 'testEmail@testDomain.com'
              component.verifyEmail(testEmail);

              //assert
              expect(component.maskEmailId).toHaveBeenCalledWith(testEmail);
            });

            it('should have called this.navigateToVerifyScreen', () => {
              //assert
              expect(component.navigateToVerifyScreen).toHaveBeenCalled();
            });
          });
          describe('when result code is not 0', () => {
            it('should call alertService.setAlert with displaymessage, when display message present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '-90000', 'displaymessage': sampleDisplayMessage }));
                fixture.detectChanges();
                component.verifyEmail();

                //assert
                expect(mockAlertService.setAlert).toHaveBeenCalledWith(sampleDisplayMessage, '', AlertType.Failure);
              } catch (error) { }
            });
            it('should call alertService.setAlert if no displaymessage is present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '-90000' }));
                fixture.detectChanges();
                component.verifyEmail();

                //assert
                expect(mockAlertService.setAlert).not.toHaveBeenCalled();
              } catch (error) {
                //do nothing
              }
            })
          });
        });
      });

      describe('should have called this.sendaccesscode for users OTHER than AV or RV users ', () => {

        beforeEach(() => {
          //arrange     
          let _authToken = Object.assign({}, jasAVUserData.authToken);
          _authToken.scopename = 'RNV';
          mockAuthService = {
            authToken: _authToken,
            isSubscriber: true
          };

          TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ProfileComponent);
          component = fixture.componentInstance;

          fixture.detectChanges();

        })
        it('should have been called with display email address in getMemProfileResponse if called with no parameters ', () => {
          //arrange
          spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

          //act
          component.verifyEmail();

          //assert
          expect(component['sendaccesscode']).toHaveBeenCalled();
        });

        describe('Parameters', () => {
          it('should have been called with display email address in getMemProfileResponse if called with no parameters ', () => {
            //arrange
            spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

            //act
            component.verifyEmail();

            //assert
            expect(component['sendaccesscode']).toHaveBeenCalledWith('EMAIL', component.diplayEmailAdress);
          });

          it('should have been called with the provided email address ', () => {
            //arrange
            spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

            let emailAddress = "testMailAddress@testDomain.com"
            component.verifyEmail(emailAddress);

            //assert
            expect(component['sendaccesscode']).toHaveBeenCalledWith('EMAIL', emailAddress);
          });
        });

        describe('sendaccesscode api "response.result" Code', () => {
          describe('when result code is 0', () => {
            beforeEach(() => {
              //act              
              spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '0' }));
              spyOn(component, 'navigateToVerifyScreen');
              spyOn(component, 'maskEmailId').and.returnValue('testEmail@testDomain.com');
              spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
              component.verifyEmail();
            });

            it('should have called authHttp.handleDecryptedResponse(sendaccesscode_response)', () => {
              //assert
              expect(mockAuthHttp.handleDecryptedResponse).toHaveBeenCalledWith({ "result": '0' });
            });
            it('should have called alertService.clearError', () => {
              //assert
              expect(mockAlertService.clearError).toHaveBeenCalled();
            });
            it('should have called this.maskEmailId ', () => {
              //assert
              expect(component.maskEmailId).toHaveBeenCalled();
            });

            it('should have called this.maskEmailId with parameter emailAdress if its valid', () => {
              //act
              let testEmail = 'testEmail@testDomain.com'
              component.verifyEmail(testEmail);

              //assert
              expect(component.maskEmailId).toHaveBeenCalledWith(testEmail);
            });

            it('should have called this.navigateToVerifyScreen', () => {
              //assert
              expect(component.navigateToVerifyScreen).toHaveBeenCalled();
            });
            it('should have called sessionStorage.setItem 3 times', () => {
              //assert
              expect(sessionStorage.__proto__.setItem).toHaveBeenCalledTimes(3);
            })
          });
          describe('when result code is not 0', () => {
            it('should call alertService.setAlert with displaymessage, when display message present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '-90000', 'displaymessage': sampleDisplayMessage }));
                fixture.detectChanges();
                component.verifyEmail();

                //assert
                expect(mockAlertService.setAlert).toHaveBeenCalledWith(sampleDisplayMessage, '', AlertType.Failure);
              } catch (error) { }
            });
            it('should call alertService.setAlert if no displaymessage is present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '-90000' }));
                fixture.detectChanges();
                component.verifyEmail();

                //assert
                expect(mockAlertService.setAlert).not.toHaveBeenCalled();
              } catch (error) {
                //do nothing
              }
            })
          });
        });

      });
    });

    describe('formatPhone', () => {
      it('should return input phoneNumber in ***-***-**** format ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        let phoneNumber = '8659568745';
        let result = component.formatPhone(phoneNumber);

        //assert
        expect(result).toBe('865-956-8745');
      });

      it('should return empty string if input phoneNumber is invalid ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        fixture.detectChanges();

        //act        
        let phoneNumber = null;
        let result = component.formatPhone(phoneNumber);

        //assert
        expect(result).toBe('');
      });
    });

    describe('verifyPhone', () => {
      beforeEach(() => {
        spyOn(sessionStorage.__proto__, 'setItem');
      })
      it('should have called alertService.clearError ', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        component.memProfile = jasAVUserData.getMemProfileApiResponse;
        component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;

        //act        
        fixture.detectChanges();
        component.verifyPhone();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
      describe('should have called this.sendcommchlaccesscode for AV and RV users ', () => {
        describe('Parameters', () => {
          it('should have been called with phoneNumber in getMemProfileResponse if called with no parameters ', () => {
            //arrange        
            fixture = TestBed.createComponent(ProfileComponent);
            component = fixture.componentInstance;

            //act    
            fixture.detectChanges();
            spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({}));

            component.verifyPhone();

            //assert
            expect(component['sendcommchlaccesscode']).toHaveBeenCalledWith('', component.profile.phoneNumber.replace(/\D/g, ''));
          });

          it('should have been called with the provided phoneNumber ', () => {
            //arrange        
            fixture = TestBed.createComponent(ProfileComponent);
            component = fixture.componentInstance;

            //act    
            fixture.detectChanges();
            spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({}));

            let phoneNumber = "1234567890"
            component.verifyPhone(phoneNumber);

            //assert
            expect(component['sendcommchlaccesscode']).toHaveBeenCalledWith('', phoneNumber);
          });
        });

        describe('sendcommchlaccesscode api "response.result" Code', () => {
          describe('when result code is 0', () => {
            beforeEach(() => {
              //arrange        
              fixture = TestBed.createComponent(ProfileComponent);
              component = fixture.componentInstance;

              //act  
              spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '0' }));
              spyOn(component, 'navigateToVerifyScreen');
              spyOn(component, 'maskPhoneNumber').and.returnValue('***-***-7890');
              fixture.detectChanges();

              component.verifyPhone();
            });

            it('should have called alertService.clearError', () => {
              //assert
              expect(mockAlertService.clearError).toHaveBeenCalled();
            });
            it('should have called this.maskPhoneNumber with profile.phoneNumber.replace(/\D/g, "") in component', () => {
              //assert
              expect(component.maskPhoneNumber).toHaveBeenCalledWith(component.profile.phoneNumber.replace(/\D/g, ""));
            });

            it('should have called this.maskPhoneNumber with parameter emailAdress if its valid', () => {
              //act
              let testPhoneNumber = '1234567890'
              component.verifyPhone(testPhoneNumber);

              //assert
              expect(component.maskPhoneNumber).toHaveBeenCalledWith(testPhoneNumber);
            });

            it('should have called this.navigateToVerifyScreen', () => {
              //assert
              expect(component.navigateToVerifyScreen).toHaveBeenCalled();
            });
          });
          describe('when result code is not 0', () => {
            it('should call alertService.setAlert with displaymessage, when display message present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '-90000', 'displaymessage': sampleDisplayMessage }));
                fixture.detectChanges();
                component.verifyPhone();

                //assert
                expect(mockAlertService.setAlert).toHaveBeenCalledWith(sampleDisplayMessage, '', AlertType.Failure);
              } catch (error) { }
            });
            it('should call alertService.setAlert if no displaymessage is present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendcommchlaccesscode').and.returnValue(of({ "result": '-90000' }));
                fixture.detectChanges();
                component.verifyPhone();

                //assert
                expect(mockAlertService.setAlert).not.toHaveBeenCalled();
              } catch (error) {
                //do nothing
              }
            })
          });
        });
      });

      describe('should have called this.sendaccesscode for users OTHER than AV or RV users ', () => {

        beforeEach(() => {
          //arrange     
          let _authToken = Object.assign({}, jasAVUserData.authToken);
          _authToken.scopename = 'RNV';
          mockAuthService = {
            authToken: _authToken,
            isSubscriber: true
          };

          TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ProfileComponent);
          component = fixture.componentInstance;

          fixture.detectChanges();

        })
        it('should have been called with display email address in getMemProfileResponse if called with no parameters ', () => {
          //arrange
          spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

          //act
          component.verifyPhone();

          //assert
          expect(component['sendaccesscode']).toHaveBeenCalled();
        });

        describe('Parameters', () => {
          it('should have been called with display email address in getMemProfileResponse if called with no parameters ', () => {
            //arrange
            spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

            //act
            component.verifyPhone();

            //assert
            expect(component['sendaccesscode']).toHaveBeenCalledWith('MOBILE', component.profile.phoneNumber.replace(/\D/g, ''));
          });

          it('should have been called with the provided email address ', () => {
            //arrange
            spyOn<any>(component, 'sendaccesscode').and.returnValue(of({}));

            let phoneNumber = "1234567890"
            component.verifyPhone(phoneNumber);

            //assert
            expect(component['sendaccesscode']).toHaveBeenCalledWith('MOBILE', phoneNumber);
          });
        });

        describe('sendaccesscode api "response.result" Code', () => {
          describe('when result code is 0', () => {
            beforeEach(() => {
              //act              
              spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '0' }));
              spyOn(component, 'navigateToVerifyScreen');
              spyOn(component, 'maskPhoneNumber').and.returnValue('testEmail@testDomain.com');
              spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
              component.verifyPhone();
            });

            it('should have called authHttp.handleDecryptedResponse(sendaccesscode_response)', () => {
              //assert
              expect(mockAuthHttp.handleDecryptedResponse).toHaveBeenCalledWith({ "result": '0' });
            });
            it('should have called alertService.clearError', () => {
              //assert
              expect(mockAlertService.clearError).toHaveBeenCalled();
            });
            it('should have called this.maskPhoneNumber ', () => {
              //assert
              expect(component.maskPhoneNumber).toHaveBeenCalled();
            });

            it('should have called this.maskPhoneNumber with parameter emailAdress if its valid', () => {
              //act
              let testPhoneNumber = '1234567890'
              component.verifyPhone(testPhoneNumber);

              //assert
              expect(component.maskPhoneNumber).toHaveBeenCalledWith(testPhoneNumber);
            });

            it('should have called this.navigateToVerifyScreen', () => {
              //assert
              expect(component.navigateToVerifyScreen).toHaveBeenCalled();
            });
            it('should have called sessionStorage.setItem 3 times', () => {
              //assert
              expect(sessionStorage.__proto__.setItem).toHaveBeenCalledTimes(3);
            })
          });
          describe('when result code is not 0', () => {
            it('should call alertService.setAlert with displaymessage, when display message present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '-90000', 'displaymessage': sampleDisplayMessage }));
                fixture.detectChanges();
                component.verifyPhone();

                //assert
                expect(mockAlertService.setAlert).toHaveBeenCalledWith(sampleDisplayMessage, '', AlertType.Failure);
              } catch (error) { }
            });
            it('should call alertService.setAlert if no displaymessage is present in response', () => {
              try {
                //arrange        
                fixture = TestBed.createComponent(ProfileComponent);
                component = fixture.componentInstance;

                //act  
                let sampleDisplayMessage = "Test Display Message";
                spyOn<any>(component, 'sendaccesscode').and.returnValue(of({ "result": '-90000' }));
                fixture.detectChanges();
                component.verifyPhone();

                //assert
                expect(mockAlertService.setAlert).not.toHaveBeenCalled();
              } catch (error) {
                //do nothing
              }
            })
          });
        });

      });
    });

    describe('maskEmailId', () => {
      it('should partially mask input email address (xyzabcefghijk@domain.com should become xyz**********@domain.com )', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //act
        let param = "testbigemailaddress@testdomain.com";
        let result = component.maskEmailId(param);

        //assert
        expect(result).toBe("tes****************@testdomain.com");
      });
    });

    describe('maskPhoneNumber', () => {
      it('should partially mask input phoneNumber (01234567890 should become ***-***-7890 )', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //act
        let param = "1234567890";
        let result = component.maskPhoneNumber(param);

        //assert
        expect(result).toBe("***-***-7890");
      });
    });

    describe('showToolTip', () => {
      it('should toggle the value of this.toolTipVisible ', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //action
        component.toolTipVisible = true;
        let initialValue = component.toolTipVisible;
        component.showToolTip();

        //assertion
        expect(component.toolTipVisible).not.toBe(initialValue);

      });
    });

    describe('navigateToVerifyScreen', () => {
      it('should navigate to /myprofile/verify', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        let component = fixture.componentInstance;
        //act
        component.navigateToVerifyScreen();
        //assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/myprofile/verify']);
      });

      it('should have called alertService.setAlert', () => {
        pending();
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        let component = fixture.componentInstance;
        //act
        component.navigateToVerifyScreen();
        //assert
        expect(mockAlertService.setAlert).toHaveBeenCalledWith('Verification code sent!.', '', AlertType.Success);
      });

    });

    describe('addPhone', () => {
      it('should call this.phoneEdit', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
        spyOn(component, 'phoneEdit')

        //action
        component.addPhone(event);

        //assertion
        //expect(component.addPhone).toHaveBeenCalledWith(event);
        expect(component.phoneEdit).toHaveBeenCalled();

      });
    });

    describe('isWebMigrated', () => {
      it('should return TRUTHY if all of the following are FALSE: this.isUseridAPhone, this.isUseridAPhone, this.profileEditForm.value.phoneNumber', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.isUseridAEmail = false;
        component.isUseridAPhone = false;
        component.profileEditForm.value.phoneNumber = false;

        //action
        let returnValue = component.isWebMigrated();

        //assert
        expect(returnValue).toBeTruthy();
      });
      xit('should return FALSY if either of the following is true: this.isUseridAPhone, this.isUseridAPhone, this.profileEditForm.value.phoneNumber', () => {
        //arrange
        ProfileComponent.prototype.isUseridAEmail = true;
        ProfileComponent.prototype.isUseridAPhone = false;
        ProfileComponent.prototype.profileEditForm['phoneNumber'] = false;

        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        component.isUseridAEmail = true;
        component.isUseridAPhone = false;
        component.profileEditForm['phoneNumber'] = false;

        //action
        let _isWebMigrated = component.isWebMigrated.bind(ProfileComponent)
        let returnValue = _isWebMigrated();

        //assert
        expect(returnValue).not.toBeTruthy();
      });
    });

    describe('navigateToNotificationPrefence', () => {
      it('should navigate to /notification-preferences', () => {
        //arrange
        fixture = TestBed.createComponent(ProfileComponent);
        let component = fixture.componentInstance;

        //act
        component.navigateToNotificationPrefence();

        //assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/notification-preferences']);
      });
    });

    describe('sendaccesscode', () => {
      it('should call profileService.sendaccesscode with the same set of parameters it has been called with', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //act   
        let commChannelType = {};
        let commChannel = {}
        let sendAccessCodeFunc = component['sendaccesscode'];
        sendAccessCodeFunc.call(component, commChannelType, commChannel);

        //assert
        expect(mockProfileService.sendaccesscode).toHaveBeenCalledWith(commChannelType, commChannelType);
      });
    });

    describe('sendcommchlaccesscode', () => {
      it('should call profileService.sendcommchlaccesscode with the same email and mobile.replace(/\D/g,"") of parameters it has been called with', () => {
        //arrange        
        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;

        //act   
        let email = 'testEmail@testDomain.com';
        let mobile = '1234567890'
        let sendcommchlaccesscodeFunc = component['sendcommchlaccesscode'];
        sendcommchlaccesscodeFunc.call(component, email, mobile);

        //assert
        expect(mockProfileService.sendcommchlaccesscode).toHaveBeenCalledWith(email, mobile.replace(/\D/g, ''));
      });
    });
  });
});
