import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
  MatSelectModule, MatRadioModule, MatCardModule, MatIconModule, MatSidenavModule, MatDialogModule,
  MatTooltipModule, MatGridListModule, MatFormFieldModule
} from '@angular/material';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { FormBuilder, FormsModule, Validators } from '@angular/forms';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'
import { TextMaskModule } from 'angular2-text-mask';
import { StorageServiceModule } from 'angular-webstorage-service';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';
import { BrowserModule } from '@angular/platform-browser';
import { of } from 'rxjs/observable/of';
import { FakeRouterLinkDirectiveStub, FakeParentFormFieldDirectiveStub } from '../../../../jasmine/fake-directives';
import {
  FakeControlMessagesComponent, FakeFadBreadCrumbsComponent, FakeCostBreakdownFilterComponent,
  FakeAlegeusLineChartComponent, FakeBreadcrumbsComponent,
  FakeFpoLayoutComponent, FakePasswordControlMessages
} from '../../../../jasmine/fake-components';
import { ValidationService, AuthService, ConstantsService } from '../../../shared/shared.module';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { GlobalService } from '../../../shared/services/global.service';
import { VerifyEmailMobileComponent } from './verify-email-mobile.component';
import { jasAVUserData } from '../../../../jasmine/data/my-profile/avUser.data';

describe('VerifyEmailMobileComponent', () => {
  let component: VerifyEmailMobileComponent;
  let fixture: ComponentFixture<VerifyEmailMobileComponent>;

  let mockRouter;
  let mockAlertService;
  let mockProfileService;
  let mockValidationService;
  let mockAuthService;
  let mockConstants;
  let mockGlobalService;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {

    mockAuthService = mocks.service.authService;

    mockConstants = mocks.service.constantsService;

    mockGlobalService = mocks.service.globalService;

    mockRouter = mocks.service.router;
    mockRouter.url = "/myprofile/verify";

    mockAlertService = mocks.service.alertService;

    mockProfileService = mocks.service.profileService;

    mockValidationService = mocks.service.validationService;

    mockRouter = mocks.service.router;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeRouterLinkDirectiveStub,
        FakeParentFormFieldDirectiveStub,
        FakeControlMessagesComponent,
        FakeFadBreadCrumbsComponent,
        FakeCostBreakdownFilterComponent,
        FakeAlegeusLineChartComponent,
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakePasswordControlMessages,

        VerifyEmailMobileComponent
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: ConstantsService, useValue: mockConstants },
        { provide: GlobalService, useValue: mockGlobalService },
        TitleCasePipe
      ]

    })
      .compileComponents();

    VerifyEmailMobileComponent.prototype.verifyaccesscodeForm = formBuilder.group({
      accesscode1: ['', [Validators.required]],
      accesscode2: ['', [Validators.required]],
      accesscode3: ['', [Validators.required]],
      accesscode4: ['', [Validators.required]],
      accesscode5: ['', [Validators.required]],
      accesscode6: ['', [Validators.required]],
    }, {
      validator: mockValidationService.accessCodeValidator()
    });
    spyOn(VerifyEmailMobileComponent.prototype.verifyaccesscodeForm, 'valueChanges').and.returnValue(of('123456'));

  }));

  describe('Constructor', () => {

    beforeEach(() => {
      //arrange
      fixture = TestBed.createComponent(VerifyEmailMobileComponent);

      //act
      component = fixture.componentInstance;
    });

    it('should create', () => {
      //assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      describe('should have initialized', () => {
        it('should have initialized this.location to "myprofile"', () => {
          expect(component.location).toBe("myprofile");
        });

        it(' should have created this.verifyaccesscodeForm', () => {
          expect(component.verifyaccesscodeForm).toBeTruthy();
        });

        it(' should have initialized this.accesscodeMask to this.validationService.accesscodeMask', () => {
          //assert
          let assertion: boolean = mockValidationService.accesscodeMask.length === component.accesscodeMask.length && (() => {
            for (let maskItr = 0; maskItr < component.accesscodeMask.length; maskItr++) {
              if (String(mockValidationService.accesscodeMask[maskItr]) == String(component.accesscodeMask[maskItr]))
                continue;
              else
                return false;
            }
            return true;
          })();
          expect(assertion).toBeTruthy();
        });
      });

      describe('should have called', () => {
        it('should have called  this.alertService.clearError()', () => {
          expect(mockAlertService.clearError).toHaveBeenCalled();
        });

        xit('should have called  this.verifyaccesscodeForm.valueChanges', () => {
          //this is not a method but an event emitter
          // need to find a way to test this
          expect(component.verifyaccesscodeForm.valueChanges).toHaveBeenCalled();
        });

      });
    });
  });

  describe('ngOnInit', () => {

    beforeEach(() => {
      //arrange      
      fixture = TestBed.createComponent(VerifyEmailMobileComponent);
      component = fixture.componentInstance;

    });

    describe('should have initialized', () => {
      describe('should have set the value of this.maskedVerifiable to masked userid ', () => {
        it('should mask when userid is email', () => {
          //arrange
          let useridin = "sampleMailId@sampledomain.com";
          spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(useridin);
          let maskedUserId = useridin;
          maskedUserId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {

            return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
          });

          //act
          fixture.detectChanges();

          //assert            
          expect(component.maskedVerifiable).toBe(maskedUserId);
        });
        it('should mask when userid is mobile number', () => {
          //arrange
          let useridin = "1234567890";
          spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(useridin);
          let maskedUserId = useridin;
          maskedUserId.replace(/^(.*)(.{4})$/,
            (_, digitsToMasked, lastFourDigits) => {
              return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
            })

          //act
          fixture.detectChanges();

          //assert
          expect(component.maskedVerifiable).toBe(maskedUserId);
        });

      });
    });

    describe('should have called', () => {

      it('should have called sessionStorage.getItem twice', () => {
        //arrange
        let sessGet = spyOn(sessionStorage.__proto__, 'getItem')

        //act
        fixture.detectChanges();

        //assert
        expect(sessGet).toHaveBeenCalledTimes(2);
      });

      it('should have called profileService.getProfile', () => {
        //act
        fixture.detectChanges();

        //assert
        expect(mockProfileService.getProfile).toHaveBeenCalled();
      });

      describe('when profileService.getProfile() returns null', () => {
        it('should have called profileService.fetchProfileInfo()', () => {
          //act
          mockProfileService.getProfile.and.returnValue(null);
          fixture.detectChanges();

          //assert
          expect(mockProfileService.fetchProfileInfo).toHaveBeenCalled();
        });
        it('should have called profileService.setProfile()', () => {
          //act
          mockProfileService.getProfile.and.returnValue(null);
          fixture.detectChanges();

          //assert
          expect(mockProfileService.setProfile).toHaveBeenCalled();
        });
      });

      xdescribe('when profileService.getProfile() returns valid value', () => {
        it('should not call profile.fetchProfileInfo()', () => {
          //act       
          mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
          fixture.detectChanges();

          //assert
          expect(mockProfileService.fetchProfileInfo).not.toHaveBeenCalled();
        });
        it('should not call profile.fetchProfileInfo()', () => {
          //act
          mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
          fixture.detectChanges();

          //assert
          expect(mockProfileService.setProfile).not.toHaveBeenCalled();
        });
      });

    });

  });

  describe('methods', () => {
    describe('maskEmailId', () => {
      it('should return masked value of sentMailId["commChannel"] from sessionStorage if present', () => {
        //arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{"commChannel":"abcdefgh@ijklmnop.com"}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        //act
        let result = component.maskEmailId('');

        //assert
        expect(result).toBe('abc*****@ijklmnop.com');
      });
      it('should return masked value of passed in parameter if sentMailId["commChannel"] is absent in sessionStorage', () => {
        //arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        //act
        let result = component.maskEmailId('abcdefgh@ijklmnop.com');

        //assert
        expect(result).toBe('abc*****@ijklmnop.com');
      });

      it('should return masked value of passed in parameter if sentMailId["commChannel"] is absent in sessionStorage', () => {
        //arrange
        let sessStorageSpy = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        //act
        let result = component.maskEmailId('abcdefgh@ijklmnop.com');

        //assert
        expect(sessStorageSpy).toHaveBeenCalledTimes(1);
      });
    });

    describe('maskPhoneNumber', () => {
      it('should return masked value of input mobile number in ***-****-XXXX format', () => {
        //arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{commChannel:abcdefgh@ijklmnop.com}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        //act
        let result = component.maskPhoneNumber('1234567890');

        //assert
        expect(result).toBe("***-***-7890");
      });
    });

    describe('ngOnDestroy', () => {
      it('should have called alertService.clearError', () => {
        //arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{commChannel:abcdefgh@ijklmnop.com}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        //act
        component.ngOnDestroy();

        //assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      })
    });

    describe('onSubmit', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendAccessCode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendaccesscode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendcommchlaccesscode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('onKeyDown', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('onKeyUp', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('isValidKeyPressed', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendNotification', () => {
      it('should do something', () => {
        pending();
      });
    });

  });
});
