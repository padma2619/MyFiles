
export interface RadioListInterface {
    value: string;
    checked: boolean;
}
