import { Component, ElementRef, EventEmitter, HostListener, OnDestroy, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ClaimMemberRecord } from '../../myclaims/models/claims-summary-data.model';
import { animate, state, style, transition, trigger } from '@angular/animations';
import {
  EOBListResponseModelInterface,
  EOBListRequestModelInterface,
  EOBRecord,
  EOBLinkRequestModelInterface 
} from './models/eob-data-model.interface';
import { MatCalendar, MatRadioGroup, MatSelectionList, MatSelectionListChange, MatSidenav } from '@angular/material';

  import { ConstantsService, AlertService } from '../../../shared/shared.module';
  import { AlertType } from '../../../shared/alerts/alertType.model';
  import { ActivatedRoute, Router } from '@angular/router';
  import { AuthService } from '../../../shared/shared.module';
  import { AuthHttp } from '../../../shared/services/authHttp.service';
  import { FilterService } from '../../../shared/services/filter.service';
  import { ISubscription } from 'rxjs/Subscription';
  import { MemberInfo } from '../../../shared/models/memberInfo.model';
  import {
     DateMetaInterface, DateSearchListInterface, CustomDateRangeMetaInterface
  } from '../../myclaims/models/interfaces/claims-generic-models.interface';
  import * as moment from 'moment';
  import { DatePipe } from '@angular/common';
  import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
  import { RadioList } from './eob.model';

  import { EOBService } from './eob.service';
  import { EobSortOrderType } from './models/types/claims.types';
  import { HomePageInfoModel } from '../../landing/landing.model';
  import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
@Component({
    selector: 'app-eob',
    templateUrl: 'eob.component.html',
    styleUrls: ['./eob.component.scss'],
    animations: [
        trigger('slideInOut', [
          state('in', style({
            transform: 'translate3d(0,0,0)'
          })),
          state('out', style({
            transform: 'translate3d(-100%,0,0)',
            display: 'none'
          })),
          transition('in => out', animate('100ms ease-in-out')),
          transition('out => in', animate('100ms ease-in-out'))
        ])
      ]

})

export class EobComponent implements OnInit {
  public memberInfo: HomePageInfoModel;
    bHasDependents: boolean = false;
    ismobile: boolean;
    mobileViewPort = 992;
    sideNavHeight: string;
    sideNavStatus: string;
    isSidenavOpened: boolean = false;
    memberData: MemberInfo;
    filteredEOBs: EOBRecord[] = [];
    allEOBs: EOBRecord[] = [];
    allEOBsFilterOptions: any;
    initialEOBsCount;
    title: string = 'Explanation of Benefits';
    subscription: ISubscription;
    recordsPerPage: number = 50;
    checkFromDate: boolean;
    checkToDate: boolean;
    isDisplaySpinner: boolean = false;
    isClearFilter: boolean = false;
    noEOBsAvailable: boolean = false;
    fpoTargetUrl = '';
    sideNavMode: string = 'side';
    showClearLink: boolean = false;
    dateFilterSelected: boolean = false;
    dateFilters = [];
    step = [];
    EOBsDocument = '';
    showClose: boolean;
    showCalender: boolean;
    public breadCrumbsE: BreadCrumb[];
    sortList: RadioList[] = [
    {
      'value': 'Most Recent',
      'checked': true
    },
    {
      'value': 'Oldest First',
      'checked': false
    }
  ];
    showResultsCount = false;
    isexpanded: boolean;
    isSortExpanded: boolean;
    isFormDateSelected = true;
    dateFormat = 'MM/DD/YYYY';
    currentSortValue: string = 'Most Recent';
    isDisplayMessage: boolean = false;
    isDisplayResults: boolean = false;
    dateSelectedFilter: any;
    showDate: boolean;
    fromMinDate: Date;
    calendarMaxDate = new Date();
    currentSelectedDate: Date = null;
    isCustomDateRangeInValid = false;
    isDisplayCustomDateRange = false;
    isSelectedDateInvalid = false;
    lastDate: Date;
    fromDate: string;
    toDate: string = moment().format('L');
    sortSelectedFilter: string = 'Most Recent';
    claimsFormUrl : string = this.constants.claimsFormCommercialUrl;
    @ViewChild('searchDrpContainer') searchDrpContainer;
    @ViewChild('sideNavContainer') elementView: ElementRef;
    @ViewChild('filterWidth') filterElementView: ElementRef;
    @ViewChild('searchInput') searchInput;
    @ViewChild('sidenav') sideNav: MatSidenav;
    @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;
    @ViewChild('matcalender') picker: MatCalendar<Date>;
    @ViewChild('fromDateInput') fromInputDate: ElementRef;
    @ViewChild('toDateInput') toInputDate: ElementRef;
    @ViewChild('searchInput') inputSearch: ElementRef;
    @ViewChild('memberFilter') memberFilter;
    @ViewChild('providerFilter') providerFilter;
    @ViewChild('visitTypeFilter') visitTypeFilter;
    @ViewChild('claimStatusFilter') claimStatusFilter;
    @ViewChild(InfiniteScrollDirective) infiniteScroll: InfiniteScrollDirective;

// right nav code
  showFinancialLink: boolean = false;
  showHEQALGFinancialLink: boolean = false;
  ssoFinancialLink: string = '';
  ssoALGFinancialLink: String = '';
  ssoHEQFinancialLink: String = '';
  contactus = this.constants.contactus + this.authService.authToken.scopename;
    @HostListener('window:resize', ['$event'])
    onResize(event) {
        if (event.target.innerWidth <= this.mobileViewPort) {
            this.ismobile = true;
        } else {
            this.ismobile = false;
            this.sideNavStatus = 'in';
        }
    }

    constructor(private eobService: EOBService,
        public authService: AuthService,
        private http: AuthHttp,
        private router: Router,
        public filterService: FilterService,
        public constants: ConstantsService,
        private activatedRoute: ActivatedRoute,
        private alertService: AlertService,
        private cdr: ChangeDetectorRef,
        private datePipe: DatePipe,
        private route: ActivatedRoute) {
        this.updateEobData(this.activatedRoute.snapshot.data.eobInfo);

        if (window.innerWidth <= this.mobileViewPort) {
            this.ismobile = true;
        }
        this.isSortExpanded = false;
        this.sideNavStatus = this.ismobile ? 'out' : 'in';

        if(this.authService.authToken && this.authService.authToken.userType.toLowerCase()==="medicare"){
          this.claimsFormUrl=this.constants.claimsFormMedicareUrl;
        }else if(this.authService.authToken && this.authService.authToken.userType.toLowerCase()==="medex"){
          this.claimsFormUrl=this.constants.claimsFormMedexUrl;
        }
    }
      updateEobData(eobInfo, isAppliedFilter?: boolean) {
        
      if (eobInfo ) {
        if (eobInfo.errormessage) {
          
          this.filteredEOBs = [];

        } else {
          
         this.initialEOBsCount = eobInfo[0].length;
         console.log(eobInfo[0].length);
         console.log(eobInfo);
         this.allEOBs = eobInfo[0];
              
         console.log(this.allEOBs);
         if(this.allEOBs["result"])
         {
           this.noEOBsAvailable = true;
         }
         else{
          if(!isAppliedFilter){  
            this.filteredEOBs = this.allEOBs.slice(0, this.recordsPerPage);
            this.filteredEOBs =  this.filteredEOBs.sort((a, b) => {
              return <any>new Date(b.serviceStartDate) - <any>new Date(a.serviceStartDate);
            });
           }else{
            this.filteredEOBs =  eobInfo.sort((a, b) => {
              return <any>new Date(b.serviceStartDate) - <any>new Date(a.serviceStartDate);
            });
           }
         }
        
         

         console.log('filteredeobs',this.filteredEOBs);

         this.isDisplayResults = true;
        }
        this.isDisplaySpinner = false;
     }
    //  this.noEOBsAvailable = !this.filteredEOBs.length;
    //  if(this.filteredEOBs.length == 0)
    //  {
    //    this.noEOBsAvailable = true;
    //  }
    }
    getPrevDate(days: number) {
      const d = new Date();
      d.setDate(d.getDate() - days);
      return this.datePipe.transform(d, 'yyyy-MM-dd');
    }
    getYearStartDate() {
      return (new Date()).getFullYear() + '-01-01';
    }
    getTodayDate() {
      return this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    }

    isSortOpened() {
      this.isSortExpanded = true;
    }
  
    isSortClosed() {
      this.isSortExpanded = false;
    }

    ngOnInit() {

     

      console.log("auth service",this.authService);
      this.dateFilters = [{dateRange: 'Last 30 days', startDate: this.getPrevDate(30) },
       {dateRange: 'Last 60 days', startDate: this.getPrevDate(60) },
      {dateRange: 'Last 90 days', startDate: this.getPrevDate(90) },
       {dateRange: 'Year to date', startDate: this.getYearStartDate() },
       {dateRange: 'Custom Date Range', startDate: null }];
      const t = sessionStorage.getItem('authToken');
       if (t) {
         const authToken = JSON.parse(t);
         if (authToken.userType === 'MEMBER' && (authToken.planTypes['medical'] ==='true'&&authToken.planTypes['dental'] ==='true')) {
           this.title = 'Summary of Health Plan Payments';
         }
         if((authToken.userType === 'MEDEX' ||  authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] ==='true'&&authToken.planTypes['dental'] ==='true')){

          this.title = 'Explanation of Benefits';
         }
         if ((authToken.userType === 'MEMBER' && authToken.planTypes['medical'] ==='false') && (authToken.planTypes['dental'] ==='false')) {
          this.title = 'Summary of Health Plan Payments';
        }
        if((authToken.userType === 'MEDEX' ||  authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] ==='false'&&authToken.planTypes['dental'] ==='false')){

         this.title = 'Explanation of Benefits';
        }
        if ((authToken.userType === 'MEMBER' && authToken.planTypes['medical'] ==='true') && (authToken.planTypes['dental'] ==='false')) {
          this.title = 'Summary of Health Plan Payments';
        }
        if((authToken.userType === 'MEDEX' ||  authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] ==='true'&&authToken.planTypes['dental'] ==='false')){

         this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && (authToken.planTypes['medical'] ==='false' && authToken.planTypes['dental'] ==='true')) {
          this.title = 'Explanation of Your Dental Benefits';
        }
        if((authToken.userType === 'MEDEX' ||  authToken.userType === 'MEDICARE') && (authToken.planTypes['medical'] ==='false'&&authToken.planTypes['dental'] ==='true')){

         this.title = 'Explanation of Your Dental Benefits';
        }
       }

       this.breadCrumbsE = [];
       this.breadCrumbsE = [{
         label: 'Home',
         url: ['/home']
       },
       {
         label: 'My Inbox',
         url: ['/message-center']
       },
       {
         label: 'My Documents',
         // url: ['/message-center', 'documents', folderId]
         url: ['/message-center/documents/home']
       },
       {
         label: this.title,
         url: ['/message-center/documents/eob']
         // url: ['/message-center', 'documents', folderId]
       }];
     
      
       console.log(this.breadCrumbsE);
      
       this.handleFinanceLinksInSideBar();
    }

   // filter Logic below
   toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    this.sideNavMode = window.innerWidth <= 992 ? 'over' : 'side';

  }
  public applyFilter() { // , clearSearch: boolean = true
    this.isDisplaySpinner = true;
    this.filterService.scrollToTop();
    this.closeFilter();
    this.closeSideNavigation();
    
    this.showCalender = false;
    this.isDisplayMessage = false;
    this.alertService.clearError();

    const reqParams: EOBListRequestModelInterface = {useridin: this.authService.useridin};
    var sortOrder = this.sortSelectedFilter as EobSortOrderType;
         console.log(sortOrder);

    if(this.dateFilterSelected && this.dateFilters[0].startDate){
    
    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      // reqParams.statementDateRange = {startDate: this.dateSelectedFilter.startDate || this.fromDate,
      //   endDate: this.dateSelectedFilter.startDate ? this.getTodayDate() : this.toDate};
        var getStartDate = (this.dateSelectedFilter.startDate) || (this.fromDate) || (this.dateFilters[0].startDate);
        let startDate = this.formattedData(getStartDate);
        var getEndDate = (this.dateSelectedFilter.startDate) ? (this.getTodayDate()) : (this.toDate);
        let endDate = this.formattedData(getEndDate);
        reqParams.serviceDateRange = {startDate: startDate,
        endDate: endDate};
        


        console.log(reqParams)
        this.isDisplaySpinner = true;
      this.eobService.getEobList(reqParams).subscribe(apiData => {
        console.log(apiData);
        //this.updateEobData(apiData, true);
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            //this.manageClaimsListing(apiData);
            this.updateEobData(apiData, true);
            this.isDisplayResults = true;
            this.showClearLink = true;
            this.isDisplaySpinner = false;
          } 
            else {
              //this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
              this.filteredEOBs = [];
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.showClearLink = true;
              
              this.isDisplaySpinner = false;
            
          }
        }
        
        
      });
    }
      
    } else{
      if(sortOrder =="Oldest First"){
        
        this.filteredEOBs = this.filteredEOBs.reverse();
        this.isDisplaySpinner = false;
      }else{
        this.filteredEOBs =  this.filteredEOBs.sort((a, b) => {
          return <any>new Date(b.serviceStartDate) - <any>new Date(a.serviceStartDate);
        });
        this.isDisplaySpinner = false;

      }

    }

  }
  public paginationOnScrollDown() {
    if (!this.dateSelectedFilter) {
    this.infiniteScroll.ngOnDestroy();
    this.infiniteScroll.setup();
    this.alertService.clearError();
    const startIndex = this.filteredEOBs.length;
    const nextPageRecs = this.allEOBs.slice(startIndex, startIndex + this.recordsPerPage);
    this.filteredEOBs = this.filteredEOBs.concat(nextPageRecs);
    }

  }
  dateFilterChanged() {
    if (this.dateSelectedFilter) {
      this.dateFilterSelected = true;

      if (this.dateSelectedFilter.startDate) {
        this.clearCustomDateRangeSelections();
        this.showCalender = false;
      } else {
        this.isDisplayCustomDateRange = true;
        // this.showCalender = true;
      }
      this.fromDate = '';
      this.isSelectedDateInvalid = false;
      this.isCustomDateRangeInValid = false;
    }
  }
  isOpened(value) {
    switch (value) {
      case 1:
        this.step[1] = 1;
        break;
      case 2:
        this.step[2] = 2;
        break;
      case 3:
        this.step[3] = 3;
        break;
      case 4:
        this.step[4] = 4;
        break;
      case 5:
        this.step[5] = 5;
        break;
      case 6:
        this.step[6] = 6;
        break;
      default:
        break;
    }
  }

  public clearFilter() {
    this.step = [];
    this.closeFilter();

    this.showClose = false;
    this.showCalender = false;
    this.showResultsCount = false;
    this.isSortExpanded = false;
    this.isClearFilter = true;
    this.isDisplayMessage = false;
    this.isDisplayResults = false;
    this.showClearLink = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      this.dateSelectedFilter = {} as DateSearchListInterface;
      this.clearCustomDateRangeSelections();
    }
    this.filterService.scrollToTop();
    this.closeSideNavigation();
    this.alertService.clearError();
    this.dateSelectedFilter = undefined;
    
    this.updateEobData(this.activatedRoute.snapshot.data.eobInfo);
  }
  closeSideNavigation() {
    this.isSidenavOpened = false;
  }
  clearCustomDateRangeSelections() {
    this.toDate = moment().format('L');
    this.fromDate = null;
    this.fromMinDate = null;
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    this.isDisplayCustomDateRange = false;
  }

  fromDateChange(fromdate) {
    this.validateFromDate();
    this.validateCustomRange();
    if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
      this.showCalender = false;
    }
  }

  validateFromDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.fromDate).isValid()) {
      this.isSelectedDateInvalid = !this.fromDate || this.fromDate.length !== 10
        || moment(this.fromDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0
        || moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }

    return this.isSelectedDateInvalid;
  }

  validateToDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.toDate).isValid()) {
      this.isSelectedDateInvalid = !this.toDate
        || moment(this.toDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0
        || moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
    return this.isSelectedDateInvalid;
  }

  validateCustomRange() {
    if (this.toDate && this.fromDate) {
      this.isCustomDateRangeInValid = moment(this.toDate).diff(moment(this.fromDate)) < 0;
    }
  }

 

  clearSearchVal() {
    //this.searchval = '';
    this.showClose = false;
    //this.isautosearch = false;
    //this.inputSearch.nativeElement.focus();
  }

  toggleCalender(selectedDateType: string) {
    const isControlChanged = (selectedDateType === 'to' && this.isFormDateSelected) ||
      (selectedDateType === 'from' && !this.isFormDateSelected);
    this.isFormDateSelected = selectedDateType === 'from';
    this.currentSelectedDate = this.isFormDateSelected ? new Date(this.fromDate) : new Date(this.toDate);
     this.setCalendarMinimumDate();
    if (isControlChanged) {
      this.toggleCalendarDisplay();
    } else {
      this.showCalender = true;
    }
  }

  toggleCalendarDisplay() {
    this.showCalender = false;
    setTimeout(() => {
      this.showCalender = true;
      setTimeout(() => {
        if (this.isFormDateSelected) {
          this.fromInputDate.nativeElement.focus();
        } else {
          this.toInputDate.nativeElement.focus();
        }
      }, 1);
    }, 1);
  }

  getSelectedValue(date) {
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    if (this.isFormDateSelected) {
      this.fromDate = this.filterService.getFormatDateString(date);
    } else {
      this.toDate = this.filterService.getFormatDateString(date);
    }
    this.setCalendarMinimumDate();
    this.showCalender = false;
  }

  setCalendarMinimumDate() {
    if (!this.isFormDateSelected && this.fromDate) {
      this.fromMinDate = new Date(this.fromDate);
    } else {
      const minFormDate = this.filterService.getMinimumFromDate();
      this.fromMinDate = minFormDate;
    }
  }

  formatInputFromDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.fromDate = dateString;
    }
    if (this.fromDate.length >= 10) {
      this.validateFromDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.fromDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  formatInputToDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.toDate = dateString;
    }
    if (this.toDate.length >= 10) {
      this.validateToDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.toDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  


  toDateChange(toDate) {
    this.validateCustomRange();
    this.validateToDate();
    if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
      this.showCalender = false;
    }
  }
  onScrollUp() {
    console.log('fdfdsf');
  }
  showEOBDetails(eob: EOBRecord) {

    const reqParams: EOBLinkRequestModelInterface = {useridin: this.authService.useridin};
        
        reqParams.nascoSubscriberNumber = eob.nascoSubscriberNumber;
        reqParams.claimID = eob.claimID;
        reqParams.serviceDate = eob.eobStatementDate;
        console.log(reqParams);
        //this.isDisplaySpinner = true;
        this.eobService.getEOBDocumentLink(reqParams)
          .subscribe(apiData => {
            console.log(apiData);

            if (apiData && Object.keys(apiData).length) {
              
              this.openPdfUrl(apiData["eobLink"]); 
                
                this.http.hideSpinnerLoading();
              this.isDisplaySpinner = false;
            }else{
              
                this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
                this.isDisplaySpinner = false;
                this.http.hideSpinnerLoading();
              

            }
                
          });
  }
  formattedData(value: string) {
    // console.log('value = ' + value);
    value = value.substring(0, 11);
    return this.datePipe.transform(value, 'yyyy-MM-dd');
  }

    closeFilter() {
        if (this.ismobile) {
            this.sideNavStatus = 'out';
            this.isSidenavOpened = false;
        }
    }

    

    // right Nav code
    public openClaimSubmissionPDF(fileItem: string) {

        window.location.href = this.claimsFormUrl;
        return;
    }
    private handleFinanceLinksInSideBar() {
        const hasALG = this.authService.authToken ? this.authService.authToken.isALG === 'true' : false;
        const hasHEQ = this.authService.authToken ? this.authService.authToken.isHEQ === 'true' : false;

        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = false;
        if (hasALG) {
          if (hasHEQ) {
            // both are true - show 2 links
            this.showHEQALGFinancialLink = true;
            this.showFinancialLink = false;
          } else {
            this.showHEQALGFinancialLink = false;
            this.showFinancialLink = true;
          }
        } else {
          if (hasHEQ) {
            this.showHEQALGFinancialLink = false;
            this.showFinancialLink = true;
          } else {
            // both are false - show no links
            this.showHEQALGFinancialLink = false;
            this.showFinancialLink = false;
          }
        }

        // this.showFinancialLink = (hasALG || hasHEQ) ? true : false;
        this.ssoFinancialLink = hasHEQ ? '/sso/heathequity' : '/sso/alegeus';
      }

      openSSO(module?) {
        if (module === 'algOrHeq') {
          window.open(this.ssoFinancialLink, '_blank');
        } else if (module === 'alg') {
          window.open( '/sso/alegeus', '_blank');
        } else if (module === 'heq') {
          window.open( '/sso/heathequity' , '_blank');
        } else if (module === 'connecture') {
          window.open( '/sso/connecture' , '_blank');
        }
      }
      openPdfUrl(url) {
        if (url) {
          window.open(url, '_self');
        }
      }
      formattedDate(date: string): string {
        if (date) {
          return this.datePipe.transform(date, 'MM/dd/yyyy');
        }
      }
      openUrl() {
        window.open(this.contactus, '_self');
      }

      openUrlinNewWindow(url) {
        window.open(url, '_blank');
      }
}
