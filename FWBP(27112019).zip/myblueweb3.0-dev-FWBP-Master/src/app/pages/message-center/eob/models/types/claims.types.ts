
export type EobSortOrderType = 'Most Recent' | 'Oldest First';

