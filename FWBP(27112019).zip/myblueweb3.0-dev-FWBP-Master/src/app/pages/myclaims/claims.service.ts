import { AuthHttp } from '../../shared/services/authHttp.service';
import { AuthService } from '../../shared/shared.module';
import { ConstantsService } from '../../shared/shared.module';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import {
  ClaimsSummaryResponseModelInterface,
  ClaimsSummaryRequestModelInterface
} from './models/interfaces/claims-summary-data-model.interface';
import {
  ClaimsSummaryResponseModel,
  ClaimsSummaryRequestModel,
  ClaimSummaryMetadata
} from './models/claims-summary-data.model';
import { ClaimsDetails, MockClaim } from './claims.model';


@Injectable()
export class ClaimsService {

  private claimDetails = new BehaviorSubject<ClaimsDetails>(null);
  public claimDetails$ = this.claimDetails.asObservable();

  private claimRecord = new BehaviorSubject<MockClaim>(null);
  public claimRecord$ = this.claimRecord.asObservable();


  constructor(private http: AuthHttp,
    private constants: ConstantsService,
    private authService: AuthService) {

  }

  getClaims(filterPaginationReqParams?: ClaimsSummaryRequestModelInterface, pagination?: boolean):
    Observable<ClaimsSummaryResponseModelInterface> {
    let request: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel(), globalSpinner = true;
    if (!filterPaginationReqParams) {
      request.useridin = this.authService.useridin;
      const sortorder = 'Most Recent';
      request.summaryMetaData = new ClaimSummaryMetadata();
      request.summaryMetaData.sortOrder = sortorder;
    } else {
      request = filterPaginationReqParams;
      if (pagination) {
        globalSpinner = false;
      }
    }

    return this.http.encryptPost(this.constants.claimsUrl, request, null, null, globalSpinner).map(response => {
      return <ClaimsSummaryResponseModel>response;
    });

  }

  getClaimDetails(body): Observable<any> {
    const url = body.depid ? this.constants.claimsdepdetailsUrl : this.constants.claimdetailsUrl;
    return this.http.encryptPost(url, body);
  }


  getClaimProcessingStatus(requestParams) {
    const url = this.constants.claimProcessingStatusUrl;
    return this.http.encryptPost(url, requestParams);
  }

  getClaimsBenefitsLink(body): Observable<any> {
    const url = this.constants.benefitsLinkUrl;
    return this.http.encryptPost(url, body);
  }

}
