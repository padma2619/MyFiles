import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
    MatSelectModule, MatRadioModule, MatCardModule, MatIconModule,
    MatSidenavModule, MatDialogModule, MatTooltipModule,
    MatGridListModule, MatFormFieldModule, MatDatepickerModule,
    MatButtonModule, MatNativeDateModule, MatListModule, MatExpansionModule
} from '@angular/material';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../shared/services/auth.service';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { StorageServiceModule } from 'angular-webstorage-service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';
import {
    FakeBreadcrumbsComponent, FakeFpoLayoutComponent
} from '../../../../jasmine/fake-components';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { FilterPipeModule, FilterPipe } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { MedicationsService } from '../../../shared/services/medications/medications.service';
import { ConstantsService } from '../../../shared/shared.module';
import { MyMedicationDetailsService } from '../myMedicationDetails/my-medication-details.service';
import { FakeCellAspectRatioDirectiveStub } from '../../../../jasmine/fake-directives';
import { CasingForFilterPipe } from '../../../shared/pipes/casingForFilter/casingForFilter.pipe';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyMedicationDetailsComponent } from './myMedicationDetails.component';

xdescribe('MyMedicationDetailsComponent', () => {
    let component: MyMedicationDetailsComponent;
    let fixture: ComponentFixture<MyMedicationDetailsComponent>;

    let mockMyMedicationDetailsService;
    let mockRouter;
    let mockAlertService;
    let mockMedicationsService;
    let mockConstantsService;
    let mockAuthService;

    beforeEach(async(() => {

        mockMedicationsService = mocks.service.medicationService;
        mockAuthService = mocks.service.authService;
        mockRouter = mocks.service.router;
        mockConstantsService = mocks.service.constantsService;
        mockMyMedicationDetailsService = mocks.service.medicationDetailsService;
        mockAlertService = mocks.service.alertService;

        TestBed.configureTestingModule({
            imports: [
                BrowserAnimationsModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                StorageServiceModule,
                HttpClientTestingModule,

                MatDatepickerModule,
                MatNativeDateModule,
                MatFormFieldModule,
                MatRadioModule,
                MatSelectModule,
                MatCardModule,
                MatIconModule,
                MatSidenavModule,
                MatTooltipModule,
                MatGridListModule,
                MatDialogModule,
                MatExpansionModule,
                MatListModule,
                MatButtonModule,
                MaterialModule,
                FilterPipeModule,
                OrderModule,
            ],
            declarations: [
                FakeBreadcrumbsComponent,
                FakeFpoLayoutComponent,
                FakeCellAspectRatioDirectiveStub,

                CasingForFilterPipe,
                PhonePipe,
                YyyymmddTommddyyyyPipe,

                MyMedicationDetailsComponent
            ],
            providers: [
                { provide: MedicationsService, useValue: mockMedicationsService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: ConstantsService, useValue: mockConstantsService },
                { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
                { provide: AlertService, useValue: mockAlertService },
                FilterPipe,
                TitleCasePipe,
                CasingForFilterPipe,
                PhonePipe,
                YyyymmddTommddyyyyPipe
            ]
        })
            .compileComponents();
    }));


    describe('Constructor', () => {

        beforeEach(() => {
            //arrange
            fixture = TestBed.createComponent(MyMedicationDetailsComponent);
            component = fixture.componentInstance;
        });

        it('should create', () => {
            //assert
            expect(component).toBeTruthy();
        });

        describe('While Component Creation', () => {

        });
    });

    describe('ngOnInit', () => {
        beforeEach(() => {
            //arrange
            fixture = TestBed.createComponent(MyMedicationDetailsComponent);
            component = fixture.componentInstance;

            //act
            fixture.detectChanges();
        });
        describe('should have initialized', () => {

        });

        describe('should have called', () => {

        });
    });



});
