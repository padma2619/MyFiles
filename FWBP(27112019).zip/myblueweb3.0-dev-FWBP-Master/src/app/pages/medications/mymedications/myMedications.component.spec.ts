import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
    MatSelectModule, MatRadioModule, MatCardModule, MatIconModule,
    MatSidenavModule, MatDialogModule, MatTooltipModule,
    MatGridListModule, MatFormFieldModule, MatDatepickerModule,
    MatButtonModule, MatNativeDateModule, MatListModule, MatExpansionModule
} from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../shared/services/auth.service';
import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'

import { StorageServiceModule } from 'angular-webstorage-service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MaterialModule } from '../../../material.module';

import {
    FakeBreadcrumbsComponent, FakeFpoLayoutComponent
} from '../../../../jasmine/fake-components';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { ClaimidPipe } from '../../../shared/pipes/claimid/claimid.pipe';
import { FilterPipeModule, FilterPipe } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { MyMedicationsComponent } from './mymedications.component';
import { MedicationsService } from '../../../shared/services/medications/medications.service';
import { DependantsService } from '../../../shared/services/dependant.service';
import { FilterService } from '../../../shared/services/filter.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { ConstantsService } from '../../../shared/shared.module';
import { GlobalService } from '../../../shared/services/global.service';
import { MyMedicationDetailsService } from '../myMedicationDetails/my-medication-details.service';
import { mockMyMedsResolverServiceData } from '../../../../jasmine/data/myMedications/mock.myMedsResolverService.data';
import { FakeCellAspectRatioDirectiveStub } from '../../../../jasmine/fake-directives';
import { CasingForFilterPipe } from '../../../shared/pipes/casingForFilter/casingForFilter.pipe';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


xdescribe('MyMedicationsComponent', () => {
    let component: MyMedicationsComponent;
    let fixture: ComponentFixture<MyMedicationsComponent>;

    let mockMedicationsService;
    let mockAuthService;
    let mockRouter;
    let mockDependantsService;
    let mockFilterService;
    let mockGlobalService;
    let mockAuthHttpService;
    let mockConstantsService;
    let mockActivatedRoute;
    let mockMyMedicationDetailsService;
    let mockAlertService;


    //cachedMyAccountInfo
    //"[{"accountinforesponse":[{"hasActivePlan":"true","planName":"BLUE CARE ELECT $4500 DEDUCTIBLE","subscriberId":"050881571000000","groupName":"PPO GROUP1","planType":"","groupNumber":"521316619","hasRx":"true","planEffectiveDate":"01/01/2018","esi":{"hasESI":"true","hasESIMedex":"false"}},{"hasActivePlan":"true","planName":"NO PLAN NAME","subscriberId":"050881571000000","groupName":"DENTALBLUE","planType":"","groupNumber":"521316850","hasRx":"true","planEffectiveDate":"01/01/2016","esi":{"hasESI":"true","hasESIMedex":"false"}},{"hasActivePlan":"true","planName":"BLUE CARE ELECT $4500 DEDUCTIBLE","subscriberId":"050881571000000","groupName":"PPO GROUP1","planType":"","groupNumber":"521316607","hasRx":"true","planEffectiveDate":"01/01/2016","esi":{"hasESI":"true","hasESIMedex":"false"}}]}]"

    beforeEach(async(() => {


        mockActivatedRoute = {
            snapshot: {
                data: mockMyMedsResolverServiceData
            }
        };

        mockMedicationsService = mocks.service.medicationService;
        mockAuthService = mocks.service.authService;
        mockRouter = mocks.service.router;
        mockDependantsService = mocks.service.dependantsService;
        mockFilterService = mocks.service.filterService;
        mockGlobalService = mocks.service.globalService;
        mockAuthHttpService = mocks.service.authHttp;
        mockConstantsService = mocks.service.constantsService;
        mockMyMedicationDetailsService = mocks.service.medicationDetailsService;
        mockAlertService = mocks.service.alertService;


        TestBed.configureTestingModule({
            imports: [
                BrowserAnimationsModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                StorageServiceModule,
                HttpClientTestingModule,

                MatDatepickerModule,
                MatNativeDateModule,
                MatFormFieldModule,
                MatRadioModule,
                MatSelectModule,
                MatCardModule,
                MatIconModule,
                MatSidenavModule,
                MatTooltipModule,
                MatGridListModule,
                MatDialogModule,
                MatExpansionModule,
                MatListModule,
                MatButtonModule,
                MaterialModule,
                FilterPipeModule,
                OrderModule,
            ],
            declarations: [
                FakeBreadcrumbsComponent,
                FakeFpoLayoutComponent,
                FakeCellAspectRatioDirectiveStub,

                CasingForFilterPipe,
                PhonePipe,
                YyyymmddTommddyyyyPipe,

                MyMedicationsComponent
            ],
            providers: [
                { provide: MedicationsService, useValue: mockMedicationsService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: DependantsService, useValue: mockDependantsService },
                { provide: FilterService, useValue: mockFilterService },
                { provide: GlobalService, useValue: mockGlobalService },
                { provide: AuthHttp, useValue: mockAuthHttpService },
                { provide: ConstantsService, useValue: mockConstantsService },
                { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
                { provide: AlertService, useValue: mockAlertService },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                FilterPipe,
                TitleCasePipe,
                CasingForFilterPipe,
                PhonePipe,
                YyyymmddTommddyyyyPipe
            ]
        })
            .compileComponents();
    }));


    describe('Constructor', () => {

        beforeEach(() => {
            //arrange
            fixture = TestBed.createComponent(MyMedicationsComponent);
            component = fixture.componentInstance;
        });

        it('should create', () => {
            //assert
            expect(component).toBeTruthy();
        });

        describe('While Component Creation', () => {

        });
    });

    describe('ngOnInit', () => {
        beforeEach(() => {
            //arrange
            fixture = TestBed.createComponent(MyMedicationsComponent);
            component = fixture.componentInstance;

            //act
            fixture.detectChanges();
        });
        describe('should have initialized', () => {

        });

        describe('should have called', () => {

        });
    });



});
