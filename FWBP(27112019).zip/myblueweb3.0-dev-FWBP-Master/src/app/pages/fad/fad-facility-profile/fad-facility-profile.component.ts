import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { FadFacilityProfileService } from './fad-facility-profile.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { CustomizedAddressInfoForDisplayInterface, LinkInterface } from '../modals/interfaces/fad-facility-profile.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { Router, ActivatedRoute } from '@angular/router';
import { FadProfessionalInterface, GetSearchByProfessionalRequestModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import {AlertService, AuthService} from '../../../shared/shared.module';
import { FadFacilityResponseModel, FadFacilityProfileRequestModel } from '../modals/fad-facility-profile-details.model';
import { AlertType } from '../../../shared/alerts/alertType.model';
import {
  FadFacilityResponseModelInterface,
  LocationListInterface,
  FadFacilityCostInterface,
  FadFacilityProfileRequestModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { BreadCrumb } from '../utils/fad.utils';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadFacilityCostModel } from '../modals/fad-facility-profile-details.model';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadService } from '../fad.service';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import { AuthHttp } from '../../../shared/services/authHttp.service';


@Component({
  selector: 'app-fad-facility-profile',
  templateUrl: './fad-facility-profile.component.html',
  styleUrls: ['./fad-facility-profile.component.scss']
})
export class FadFacilityProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {

  public facilityProfile: FadProfessionalInterface; // FVProSRProfessionalInSearchEntity;
  public facilityName: string;
  public awards = new Array();

  // public specialityNames: string = '';
  // public identifiers = new Array();
  // public languages = new Array();
  // public certificates = new Array();
  // public education = {};
  // public awards = new Array();
  // public facilityLocationsCustomizedAddressList: CustomizedAddressInfoForDisplayInterface[] = [];
  // public hospitalAffiliationsList: any[] = []; // FVProSRAffilitatedHospital[] = [];
  // public facilityStarRating: StarRatingComponentInputModelInterface;
  // public facilitysStarRating = new Array();
  // public facilityReviews = new Array();
  // public acceptedNetworks = new Array();
  // public locationDetails = new Array();
  // public accreditationsAwards = new Array();
  // public blueDistinctionPlusAwards = new Array();
  // public blueDistinctionAwards = new Array();
  // public hospitalQualityMethodology = new Array();
  // public overallRatingOnSurvey = new Array();

  // public inNetworkFlag: boolean;
  // public outOfNetworkFlag: boolean;
  // public noNetworkSelectedFlag: boolean;
  // public registeredUserFlag: boolean;
  // public anonymousUserFlag: boolean;

  private specialityNamesList: string[] = [];
  public isShowFacilityDetialsSection: boolean = false;
  public fadFacilityResposeData: FadFacilityResponseModelInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public selectedLocationDetails: LocationListInterface;
  private selectedLocationIndex: number = 0;
  private hospitalQualityDefaultListLimit: number = 3;
  private hospitalQualityListLimit: number = this.hospitalQualityDefaultListLimit;
  public accordianToggleStatus: any = {};
  public isProcedure: boolean = false;
  public procedureTitle: string;
  public procedureID: string;
  public icon: boolean = false;
  public chapter224: boolean = false;

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  public mleEligibility:string;
  showAffiliatedDoctors: boolean;
  private toolTipTxt:string;
  public tierTooltipDescription : string;
  public fasFlag:boolean = false;
  public tierTooltip = new Array();
  public fasFlagAward:boolean = false;
  public awardIndex:number = 0;  
  public profileTooltip = new Array();
  public identifierToolTipDescription:string = '';
  public identifierFlag:boolean = false;
  public qmToolTipDescription:string = '';
  public qcFlag:boolean = false;
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  public disclaimerBcbsBottomCostModule: any;
  public disclaimerBcbsTopProfile: any;
  public fadFacilityProfileData: FadFacilityResponseModelInterface = null;

  constructor(private facilityProfileService: FadFacilityProfileService,
    private router: Router,
    private alertService: AlertService,
    private route: ActivatedRoute,
    public authService: AuthService,
    private fadService: FadService,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private authHttp: AuthHttp) { }

  ngOnInit() {
    try {
      this.chapter224 = this.authService.getMLEIndicator() === 'lite';
      if(JSON.parse(sessionStorage.getItem("tiersLabel"))){
        this.tierTooltip = JSON.parse(sessionStorage.getItem("tiersLabel"));
      }
      if(JSON.parse(sessionStorage.getItem("profileLabel"))){
        this.profileTooltip = JSON.parse(sessionStorage.getItem("profileLabel"));
      }
      this.fadSearchResultsService.setContextText('');
     /* this.fadFacilityProfileService.getToolTipInfo().subscribe(data=>{
        if(data.toolTipInfo.awards){
        if(this.selectedLocationDetails.awards.length){
          this.awards.map((award)=>{
            let toolTipValue = this.getToolTipText(data.toolTipInfo.awards,award.name);
            award.toolTipInfo = toolTipValue;   
          });
        }
      }
    });*/
      this.getNPToolTipDescription();

      this.fadBreadCrumbsService.addBreadCrumb((new BreadCrumb())
        .setLabel('Facility Details')
        .setUrl('/fad/facility-profile'));

      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
       
       this.mleEligibility = this.authService.getMleEligibility();
      
      if (searchCriteria) {   
        this.isProcedure = searchCriteria.getSearchText().isProcedure();
        
        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        this.procedureID = searchCriteria.getSearchText().getProcedureId();
        //this.chapter224 = searchCriteria.getSearchText.
      }

      const resolvedData = this.fadFacilityProfileData==null?this.route.snapshot.data.fadFacilityResposeData:this.fadFacilityProfileData;
      if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
        this.isShowFacilityDetialsSection = false;
        this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
      } else {
        this.fadFacilityResposeData = new FadFacilityResponseModel();
        this.fadFacilityResposeData = resolvedData.facility;
        if (this.fadFacilityResposeData.disclaimers) {
          this.disclaimers = this.fadFacilityResposeData.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function (disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileBottomList;
          });
          this.disclaimerBcbsBottomCostModule = this.disclaimers.filter(function (disclaimers){
            return disclaimers.category === FadConstants.text.disclaimerBcbsBottomCostModule;
          });
          this.disclaimerBcbsTopProfile = this.disclaimers.filter(function (disclaimers){
            return disclaimers.category === FadConstants.text.disclaimerBcbsTopProfile;
          });
          console.log(this.disclaimerBcbsBottomCostModule);
          console.log(this.disclaimerBcbsTopProfile);
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        if(this.fadFacilityResposeData.onRecordDiclaimers){
          this.onRecordDiclaimers = this.fadFacilityResposeData.onRecordDiclaimers;
          if(this.onRecordDiclaimers && this.onRecordDiclaimers.category && this.onRecordDiclaimers.category=="on_record" && this.onRecordDiclaimers.text){
            this.disclaimersFlag = true;
            this.disclaimersText = this.onRecordDiclaimers.text;
          }
        } 
        this.networkChanged = sessionStorage.getItem('networkChange');
        console.log(this.networkChanged)
        const locationId = sessionStorage.getItem('locationId');
        this.loadDetailsBasedOnLocation(locationId,false);

        //this.loadDetailsBasedOnLocation(this.selectedLocationIndex);
        this.isShowFacilityDetialsSection = true;
        if(this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId)
        {
          sessionStorage.setItem('facilityname',this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
          sessionStorage.setItem('linkedAffiliationId',this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId);
        }
        const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
        vitalsSearchRequestbyProfessional.setLimit(FadConstants.defaults.limit)
        .setPage(FadConstants.defaults.page)
        .setNetworkId(searchCriteria.getPlanName().getNetworkId());
        this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional, false).subscribe((data) => {
       
        setTimeout(()=>{
        if(data){
          if(data.totalCount>0)
          {
            this.showAffiliatedDoctors = true;
          }
          else {
            this.showAffiliatedDoctors = false;
          }
        }},500);
        })
        console.log();
        console.log(locationId,this.authService.useridin,sessionStorage.getItem('fadVendorMemberNumber'),searchCriteria.getPlanName(),sessionStorage.getItem('hccsFlag'),this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityProfileComponent,
        FadConstants.methods.ngOnInit);
    }
  }
  getNPToolTipDescription(){
    if(this.profileTooltip){
      this.profileTooltip.forEach((tooltip)=>{
        if(tooltip.toolTip.code==="PPIN"){
          this.identifierToolTipDescription = tooltip.toolTip.description;
        }else if(tooltip.toolTip.code==="PCQM"){
          this.qmToolTipDescription = tooltip.toolTip.description;
        }
      });
    }
    console.log("profile ToolTip",this.profileTooltip);  
  }
  getToolTipText(toolTip, awardname){
    this.toolTipTxt="";
    /*toolTip.forEach(toolTipValue=>{
      if(toolTipValue.toolTip.name.toLowerCase()===awardname.toLowerCase()){
        this.toolTipTxt=toolTipValue.toolTip.description;   
      }
    }); */
    return this.toolTipTxt;
  }
  ngOnDestroy() {
    this.alertService.clearError();
  }

  loadDetailsBasedOnLocation(locationsId, change:boolean) {
    this.awards = [];
    this.selectedLocationIndex = locationsId;
    sessionStorage.setItem('locationId',locationsId);
    if(change){
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));
      // this.fadFacilityProfileService.facilityProfile;
      const networkId = (searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
        searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId;
      const geoLocation = (searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo) ?
        searchCriteria.getZipCode().geo : FadConstants.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();
      const facilityLocationFlag = sessionStorage.getItem("facilityLocationFlag");

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      if(facilityLocationFlag=="true"){
        fadDoctorProfileRequestParams.setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId);
      }else{
      fadDoctorProfileRequestParams.setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
      } 
        

      if (procedureID && facilityLocationFlag!="true") {     
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius')!='null'?Number(sessionStorage.getItem('radius')):25);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }
      
      this.authHttp.showSpinnerLoading(); 
      this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data=>{
        console.log(data);
        this.fadFacilityProfileData = data;
        this.ngOnInit();
        this.authHttp.hideSpinnerLoading();
      })
    }
    //this.selectedLocationDetails = this.fadFacilityResposeData.location[locationId];

    //this.selectedLocationDetails = this.fadProfessionalResposeData.locations[locationId];
    
    const facilityLocationFlag = sessionStorage.getItem("facilityLocationFlag");
    if(facilityLocationFlag=="true" && this.fadFacilityResposeData && this.fadFacilityResposeData.location.length){
      this.selectedLocationDetails = this.fadFacilityResposeData.location[0];
      console.log(this.selectedLocationDetails);
      sessionStorage.setItem("facilityLocationFlag","false");
    }else{
    this.selectedLocationDetails = this.fadFacilityResposeData.location.find(p => p.locationId.toString() == locationsId);
    }
    console.log(this.selectedLocationDetails);
    // this.selectedLocationDetails.tiers = { description: 'TierValue' };


    if (this.selectedLocationDetails.quality.length) {
      const quality = this.selectedLocationDetails.quality;
      quality.sort((a, b) => b.score - a.score);

      this.selectedLocationDetails.quality = quality;
    }
    if(this.selectedLocationDetails.awards){
      this.selectedLocationDetails.awards.forEach(award=>{
        this.awards.push(award);
      });
    }
    if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
      this.getToolTipDescription(this.tierTooltip,this.selectedLocationDetails.tiers.description);
    }
    this.accordianToggleStatus = {};
    //  this.selectedLocationDetails.facilityCost = {
    //   copay: 0,
    //   coinsuranceAmount: 3750,
    //   deductibleAmount: 450,
    //   memberCost: 28071,
    //   employerCost: 0,
    //   procedureCost: 28071
    // };
    // this.selectedLocationDetails.costBenefits = {
    //   individualDeductibleLimit: 1200,
    //   individualDeductibleAccumulated: 700,
    //   individualOutofPocketLimit: 4500,
    //   individualOutofPocketAccumulated: 2500,
    //   overallDeductibleLimit: 1500,
    //   overallDeductibleAccumulated: 1000,
    //   familyOutofPocketLimit: 2000,
    //   familyOutofPocketAccumulated: 1000
    // } 
  }

  getToolTipDescription(toolTip,tier){
    this.tierTooltipDescription = "";
    if(toolTip){
      toolTip.forEach(toolTips=>{ 
        if(toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase()===tier.toLowerCase()){
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    } 
    return this.tierTooltipDescription;
  }
  fasIcon(){
    this.fasFlag = !this.fasFlag;
  }
  qcIcon(){
    this.qcFlag = !this.qcFlag;
  }
  identifierIcon(){
    this.identifierFlag = !this.identifierFlag;
  }
  
  fasIconAward(index){
    this.fasFlagAward = !this.fasFlagAward;
    this.awardIndex = index;
  }
  
  getRating(reviews) {
    this.startRating = new StarRatingComponentInputModel();
    if (Object.keys(reviews).length === 0) {
      this.startRating.totalRatings = 0;
      this.startRating.overAllRating = 0;
    } else {
      this.startRating.totalRatings = reviews.totalRatings;
      this.startRating.overAllRating = parseFloat(reviews.overallRating);
    }
    return this.startRating;
  }

  getQualityRating(quality) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.totalRatings = quality.score;
    this.startRating.numberOfStars = 3;
    this.startRating.overAllRating = parseFloat(quality.score);
    return this.startRating;
  }

  public copyIdentifierValue(event, inputId: string): void {
    const element: any = document.querySelector('#' + inputId);
    element.select();
    document.execCommand('copy');
    element.setSelectionRange(0, 0);
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  hospitalQualityListLimitToggle() {
    this.hospitalQualityListLimit = this.hospitalQualityListLimit === this.hospitalQualityDefaultListLimit ?
      this.selectedLocationDetails.quality.length : this.hospitalQualityDefaultListLimit;
  }

  public getDirections(location, event): void {
    const locationURL = 'http://maps.google.com/?q=' + encodeURI(location);
    window.open(
      locationURL,
      '_self'
    );
  }

  public openFacility(event): void {
    try {
      // this.facilityProfileService.facilityProfile = this.componentInput.professional;
      setTimeout(() => {
        this.router.navigate(['/fad/facility-profile']);
      }, 1);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityProfileComponent,
        FadConstants.methods.openProfile);
    }
  }

  public reviewBenefits(): void {
    //throw new Error('reviewBenefits Method not implemented.');
    this.fadService.reviewMyBenfits();
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  public showCostBreakdown(facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.parentPage = FadConstants.text.facilityPage;
    this.router.navigate(['/fad/cost-breakdown']);
  }

  public learnMoreAboutQuality() {
    // throw new Error('yet to be coded');
  }

  public searchAffiliatedDoctors() {
    // throw new Error('yet to be coded');
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    sessionStorage.setItem('facilityname',this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
    sessionStorage.setItem('linkedAffiliationId',this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId);

    if (searchCriteria) {
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
      this.fadSearchResultsService.setContextText('affiliated');
      this.router.navigate([FadConstants.urls.fadAffiliatedDoctorsSearch]);
    }
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public convertAmountToDecimalValue(value) {
    const int_part = Math.trunc(value);
    const float_part = Number((value - int_part).toFixed(2));
    const decimal: string[] = float_part.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }
  additionalCostExpantion() {
    this.icon = !this.icon;
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }
}
