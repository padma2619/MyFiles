import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadTooltipComponent } from './fad-tooltip.component';

xdescribe('FadTooltipComponent', () => {
  let component: FadTooltipComponent;
  let fixture: ComponentFixture<FadTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FadTooltipComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
