import { Component, OnInit, Input, HostListener } from '@angular/core';
import { TooltipService } from './fad-tooltip.service';

@Component({
  selector: 'app-fad-tooltip',
  templateUrl: './fad-tooltip.component.html',
  styleUrls: ['./fad-tooltip.component.scss']
})
export class FadTooltipComponent implements OnInit {

  @Input() tooltipText: string = '';
  isActive = false;

  constructor(private tooltipService: TooltipService) {     
  }

  @HostListener('click', ['$event'])
  onclick($event) {
    $event.stopPropagation();
    console.log($event);
    console.log(this.isActive);
    if(!this.isActive){
      this.tooltipService.dismissTooltip();
      this.isActive = true;
    }
    else
    this.tooltipService.dismissTooltip();
    
    // setTimeout(() => {
    //   this.isActive = !this.isActive;
    //   console.log(this.isActive);
    // }, 0);
    console.log(this.isActive);
  }

  dismiss() {
    if(this.isActive)
    this.isActive = false;
    console.log(this.isActive);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick() {
    if(this.isActive)
    this.isActive = false;
    console.log(this.isActive);
  }

  ngOnInit() {
    
    this.tooltipService.getDismiss().subscribe((data) => {
      this.dismiss();
    });
  }

}
