import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {AuthService} from '../../../shared/shared.module';
import {FadFacilityCompareService} from './fad-facility-compare.service';

@Injectable()
export class FadFacilityCompareResolver implements Resolve<Observable<any[]>> {

  constructor(public authService: AuthService,
              public fadFacilityCompareService: FadFacilityCompareService
  ) {
  }

  resolve() {
    return null;//this.fadFacilityCompareService.getCompareTableDetail();
  }
}
