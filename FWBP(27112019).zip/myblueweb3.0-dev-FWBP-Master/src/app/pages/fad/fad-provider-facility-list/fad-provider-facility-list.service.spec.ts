import { TestBed, inject } from '@angular/core/testing';

import { FadProviderFacilityListService } from './fad-provider-facility-list.service';

xdescribe('FadSearchListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FadProviderFacilityListService]
    });
  });

  it('should be created', inject([FadProviderFacilityListService], (service: FadProviderFacilityListService) => {
    expect(service).toBeTruthy();
  }));
});
