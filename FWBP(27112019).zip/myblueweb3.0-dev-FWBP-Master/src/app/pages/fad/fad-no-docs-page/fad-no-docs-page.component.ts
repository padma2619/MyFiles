
import { Component, OnInit, Input } from '@angular/core';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import { ClearSearchResultFlagInterface } from '../modals/interfaces/fad-search-list.interface';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import { ClearSearchResultFlagModel } from './../modals/fad-search-list.modal';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

@Component({
  selector: 'app-fad-no-docs-page',
  templateUrl: './fad-no-docs-page.component.html',
  styleUrls: ['./fad-no-docs-page.component.scss']
})
export class FadNoDocsPageComponent implements OnInit {

  @Input('componentInput') componentInput: FadNoDocsPageInputDataModelInterface;

  public searchText: string = '';
  public withFilterFlag: boolean = false;
  public filterCategories: string[]=[];
  constructor(private fadSearchResultsService: FadSearchResultsService, private bcbsmaErrorHandler: BcbsmaerrorHandlerService) { }

  ngOnInit() {
    try {
      if (this.fadSearchResultsService.getSearchCriteria()) {
        this.searchText = this.fadSearchResultsService.getSearchCriteria().getSearchText().getSimpleText();
          this.searchText = this.searchText.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
          this.searchText = this.searchText.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
        if (this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.professional) {
          this.filterCategories = this.fadSearchResultsService.getFilterCategories();
        } else if(this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.facility) {
          this.filterCategories = this.fadSearchResultsService.getFacilityFilterCategories();
        }
        else{
          this.filterCategories = this.fadSearchResultsService.getSpecialtyFilterCategories();
        }
      }

      this.withFilterFlag = (this.componentInput && this.componentInput.type && this.componentInput.type != "") ? true : false;

    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadNoDocsPageComponent,
        FadConstants.methods.ngOnInit);
    }
  }

  public clearFilter() {
    const searchResultFlagObj: ClearSearchResultFlagInterface = new ClearSearchResultFlagModel();
    searchResultFlagObj.clearFlag = true;
    searchResultFlagObj.type = (this.componentInput && this.componentInput.type != "") ? this.componentInput.type : null;
    this.fadSearchResultsService.clearFilterFlagSubject.next(searchResultFlagObj);
  }
}
