import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { StarRatingComponentConsumer } from '../../modals/interfaces/fad.interface';
import { FormGroup } from '@angular/forms';
import { FadReviewQuestion } from '../../modals/fad-review-questions.modal';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';

@Component({
  selector: 'app-fad-review-question',
  templateUrl: './fad-review-question.component.html',
  styleUrls: ['./fad-review-question.component.scss']
})
export class FadReviewQuestionComponent implements OnInit, StarRatingComponentConsumer {

    @Input() form: FormGroup;
    @Input() question: FadReviewQuestion;

    constructor() {

    }

    ngOnInit() {
        // TODO
    }

    ratingChanged(event) {
        this.form.controls[event.id].setValue(event.currentRating);
    }
}