
import { Injectable } from '@angular/core';
import {
  FadLandingPageSearchControlValuesInterface,
  FadAutoCompleteComplexOptionInterface
} from '../modals/interfaces/fad-landing-page.interface';
import { Observable } from 'rxjs/Observable';
import { FadConstants } from '../constants/fad.constants';
import {
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { FadLandingPageSearchControlValues, FadAutoCompleteComplexOption } from '../modals/fad-landing-page.modal';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import * as cloneDeep from 'lodash/cloneDeep';
import { Subject } from 'rxjs/Subject';
import { ClearSearchResultFlagInterface } from '../modals/interfaces/fad-search-list.interface';
import { AuthService } from '../../../shared/shared.module';
import { GetSearchBySpecialityResponseModelInterface, GetSearchBySpecialityRequestModelInterface, GetSearchBySpecialtyResponseModelInterface } from '../modals/interfaces/getSearchBySpeciality-models.interface';


@Injectable()
export class FadSearchResultsService {

  private searchCriteria: FadLandingPageSearchControlValuesInterface;
  public searchResultCache: GetSearchByProfessionalResponseModelInterface = null;
  public facilityResultCache: GetSearchByFacilityResponseModelInterface = null;
  public specialtyResultCache: GetSearchBySpecialtyResponseModelInterface = null;
  private lastSelectedSearchTextOption: FadAutoCompleteComplexOption = null;
  private lastSelectedZipCodeOption: FZCSRCity = null;
  private lastSelectedPlanOption: FadAutoCompleteComplexOption = null;
  private lastSelectedDependentOptions: FadAutoCompleteComplexOption = null;
  private contextText: string = '';

  public clearFilterFlagSubject = new Subject<ClearSearchResultFlagInterface>();
  public clearFilterFlagSubject$ = this.clearFilterFlagSubject.asObservable();

  constructor(private http: AuthHttp, private authService: AuthService) { }

  public getLastSelectedPlanOption(): FadAutoCompleteComplexOption {
    return this.lastSelectedPlanOption;
  }

  public setLastSelectedPlanOption(lastSelectedPlanOption: FadAutoCompleteComplexOption): FadSearchResultsService {
    const modelEnforcedPlanOption = lastSelectedPlanOption ?
      Object.assign(Object.create(new FadAutoCompleteComplexOption()), lastSelectedPlanOption) : lastSelectedPlanOption;
    this.lastSelectedPlanOption = modelEnforcedPlanOption;
    return this;
  }

  public getLastSelectedDependentOptions(): FadAutoCompleteComplexOption {
    return this.lastSelectedDependentOptions;
  }

  public setLastSelectedDependentOptions(lastSelectedDependentOptions: FadAutoCompleteComplexOption): FadSearchResultsService {
    this.lastSelectedDependentOptions = lastSelectedDependentOptions;
    return this;
  }

  public getLastSelectedSearchTextOption(): FadAutoCompleteComplexOption {
    return this.lastSelectedSearchTextOption ?
      Object.assign(Object.create(new FadAutoCompleteComplexOption()), this.lastSelectedSearchTextOption)
      : this.lastSelectedSearchTextOption;
  }

  public setLastSelectedSearchTextOption(lastSelectedSearchTextOption: FadAutoCompleteComplexOption): FadSearchResultsService {
    const modelEnforcedSearchTextOption = lastSelectedSearchTextOption ?
      Object.assign(Object.create(new FadAutoCompleteComplexOption()), lastSelectedSearchTextOption) : lastSelectedSearchTextOption;
    this.lastSelectedSearchTextOption = modelEnforcedSearchTextOption;
    return this;
  }

  public getLastSelectedZipCodeOption(): FZCSRCity {
    let lastSelectedZipCodeOption: FZCSRCity = null;
    if (this.lastSelectedZipCodeOption) {
      lastSelectedZipCodeOption = Object.assign(Object.create(new FZCSRCity()), this.lastSelectedZipCodeOption);
    }

    if (!lastSelectedZipCodeOption) {
      if (sessionStorage.getItem('fad-Last-selected-zip-code')) {
        lastSelectedZipCodeOption = Object.assign(Object.create(new FZCSRCity()),
          JSON.parse(sessionStorage.getItem('fad-Last-selected-zip-code')));
      }
    }

    return lastSelectedZipCodeOption;
  }

  public setLastSelectedZipCodeOption(lastSelectedZipCodeOption: FZCSRCity): FadSearchResultsService {
    const modelEnforcedZipCodeOption = lastSelectedZipCodeOption ?
      Object.assign(Object.create(new FZCSRCity()), lastSelectedZipCodeOption) : lastSelectedZipCodeOption;
    this.lastSelectedZipCodeOption = modelEnforcedZipCodeOption;
    sessionStorage.setItem('fad-Last-selected-zip-code', JSON.stringify(lastSelectedZipCodeOption));
    return this;
  }

  public getSearchCriteria(): FadLandingPageSearchControlValuesInterface {
    // localStorage.getItem('FadLandingPageSearchCriteria_zipCode');
    if (!this.searchCriteria) {
      const cachedSearchCriteria = <FadLandingPageSearchControlValues>JSON.parse(sessionStorage
        .getItem('FadLandingPageSearchCriteria'));

      if (cachedSearchCriteria) {
        this.searchCriteria = Object.assign(new FadLandingPageSearchControlValues(), cloneDeep(cachedSearchCriteria));
      } else {
        this.searchCriteria = null;
      }
    }
    return <FadLandingPageSearchControlValuesInterface>this.searchCriteria;
  }
  public getContextText(): string {
    return this.contextText;
  }

  public setContextText(contextText: string): string {
    this.contextText = contextText;
    return this.contextText;

  }

  public setSearchCriteria(searchCriteria: FadLandingPageSearchControlValuesInterface): FadSearchResultsService {

    // check if the last selected option and the text value in the search text field are the same.
    // if yes use the object reference for last selected option in memory
    if (this.lastSelectedSearchTextOption && searchCriteria.getSearchText()
      && searchCriteria.getSearchText().getSimpleText().toUpperCase().trim()
      === this.lastSelectedSearchTextOption.getSimpleText().toUpperCase().trim()) {
      searchCriteria.setSearchText(this.lastSelectedSearchTextOption);
    }

    this.searchCriteria = searchCriteria;
    sessionStorage.setItem('FadLandingPageSearchCriteria', JSON.stringify(searchCriteria));
    localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(searchCriteria.getZipCode()));
    return this;
  }

  public getFadProfileSearchResults(vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface,
    scroll: boolean = false)
    : Observable<GetSearchByProfessionalResponseModelInterface> {

    let useGlobalSpinner = true;
    if (scroll) {
      useGlobalSpinner = false;
    }

    if (this.authService.useridin) {
      
      vitalsSearchRequestbyProfessional.setUserIdIn(this.authService.useridin);
      vitalsSearchRequestbyProfessional['useridin']=this.authService.useridin;
      vitalsSearchRequestbyProfessional['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const mleIndicator = this.authService.getMleEligibility();
    console.log(mleIndicator);
    if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
      //vitalsSearchRequestbyProfessional['fadVendorMemberNumber'] = '71770096';
     
    }
    if (this.authService.getFadHccsFlag() !== null) {
      vitalsSearchRequestbyProfessional['hccsFlag'] = this.authService.getFadHccsFlag();
    }if(sessionStorage.getItem('linkedAffiliationId'))
    {
      vitalsSearchRequestbyProfessional['linkedAffiliationId']= sessionStorage.getItem('linkedAffiliationId');
      //vitalsSearchRequestbyProfessional['linkedAffiliationId']= 'f72318bdf4';
      if(!vitalsSearchRequestbyProfessional['sort']){
      vitalsSearchRequestbyProfessional['sort']= 'distance+asc';
       }
      vitalsSearchRequestbyProfessional['facilityName'] = sessionStorage.getItem('facilityname');
      if(sessionStorage.getItem('locationId'))
      {
        vitalsSearchRequestbyProfessional['locationId']= sessionStorage.getItem('locationId');
      }
    }
    
    // ,  this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(
      FadConstants.urls.fadLandingPageProfessionalsSearchListUrl, vitalsSearchRequestbyProfessional,
      '', '', useGlobalSpinner).map(response => {
        return <GetSearchByProfessionalResponseModelInterface>response;
      });
  }

  public getFadFacilitySearchResults(vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface, scroll: boolean = false)
    : Observable<GetSearchByFacilityResponseModelInterface> {

    let useGlobalSpinner = true;
    if (scroll) {
      useGlobalSpinner = false;
    }

    if (this.authService.useridin) {
      vitalsSearchRequestbyFacility.setUserIdIn(this.authService.useridin);
      vitalsSearchRequestbyFacility['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const mleIndicator = this.authService.getMleEligibility();
    if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
      
    }
    if (this.authService.getFadHccsFlag() !== null) {
      vitalsSearchRequestbyFacility['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    // , this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(
      FadConstants.urls.fadLandingPageFacilitiesSearchListUrl, vitalsSearchRequestbyFacility,
      '', '', useGlobalSpinner).map(response => {
        return <GetSearchByFacilityResponseModelInterface>response;
      });
  }

  public getFadSpecialitySearchResults(vitalsSearchRequestbyspeciality:GetSearchBySpecialityRequestModelInterface, scroll: boolean = false)
    : Observable<GetSearchBySpecialtyResponseModelInterface> {

    let useGlobalSpinner = true;
    if (scroll) {
      useGlobalSpinner = false;
    }
    if (this.authService.useridin) {
      vitalsSearchRequestbyspeciality['useridin'] = this.authService.useridin;
      vitalsSearchRequestbyspeciality['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const mleIndicator = this.authService.getMleEligibility();;
    if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
      
    }
    if (this.authService.getFadHccsFlag() !== null) {
      vitalsSearchRequestbyspeciality['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    
    //, this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(
      FadConstants.urls.fadVitalsSpecailtyUrl, vitalsSearchRequestbyspeciality,
      '', '', useGlobalSpinner).map(response => {
        return <GetSearchBySpecialtyResponseModelInterface>response;
      });
  }

  public getFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.searchResultCache && this.searchResultCache.facets) {
      if (this.searchResultCache.facets.isChoicePcp) {
        filterCategories.push('Primary Care Provider Only');
      }
      if (this.searchResultCache.facets.acceptingNewPatients) {
        filterCategories.push(FadConstants.text.acceptingNewPatients);
      }
      if (this.searchResultCache.facets.techSavvy) {
        filterCategories.push('Tech Savvy');
      }
      if (this.searchResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.searchResultCache.facets.professionalGender) {
        filterCategories.push('Gender');
      }
      if (this.searchResultCache.facets.professionalLanguages) {
        filterCategories.push('Languages');
      }
      if (this.searchResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.searchResultCache.facets.treatedTypeCodes) {
        filterCategories.push('Ages Treated');
      }

      if (this.searchResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }
      if (this.searchResultCache.facets.disordersTreatedTypeCodes) {
        filterCategories.push('Disorders Treated');
      }

      if (this.searchResultCache.facets.treatmentMethodsTypeCodes) {
        filterCategories.push('Treatment Method');
      }

      if (this.searchResultCache.facets.groupAffiliationIds) {
        filterCategories.push('Medical Groups');
      }
      if(this.searchResultCache.facets.hospitalAffiliationIds){
        filterCategories.push('Hospitals');
      }
      if(this.searchResultCache.facets.awardTypeCodes){
        filterCategories.push('Awards');
      }
      if(this.searchResultCache.facets.bdcTypeCodes){
        filterCategories.push('Blue Distinction Recognition');
      }
      if(this.searchResultCache.facets.cqms){
        filterCategories.push('Clinical Quality');
      }
      if(this.searchResultCache.facets.tiers){
        filterCategories.push('Tiers');
      }
    }
    return filterCategories;
  }

  public getFacilityFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.facilityResultCache && this.facilityResultCache.facets) {
      if (this.facilityResultCache.facets.inNetwork) {
        filterCategories.push('In-Network Only');
      }
      if (this.facilityResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.facilityResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.facilityResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }

      if (this.facilityResultCache.facets.bdcTypeCodes) {
        filterCategories.push('Blue Distinction Recognition');
      }
      if (this.facilityResultCache.facets.awardTypeCodes) {
        filterCategories.push('Awards');
      }
      if (this.facilityResultCache.facets.cqms) {
        filterCategories.push('Clinical Quality');
      }
    }
    return filterCategories;
  }

  public getSpecialtyFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.specialtyResultCache && this.specialtyResultCache.facets) {
      if (this.specialtyResultCache.facets.isChoicePcp) {
        filterCategories.push('Primary Care Provider Only');
      }
      if (this.specialtyResultCache.facets.acceptingNewPatients) {
        filterCategories.push(FadConstants.text.acceptingNewPatients);
      }
      if (this.specialtyResultCache.facets.techSavvy) {
        filterCategories.push('Tech Savvy');
      }
      if (this.specialtyResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.specialtyResultCache.facets.professionalGender) {
        filterCategories.push('Gender');
      }
      if (this.specialtyResultCache.facets.professionalLanguages) {
        filterCategories.push('Languages');
      }
      if (this.specialtyResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.specialtyResultCache.facets.treatedTypeCodes) {
        filterCategories.push('Ages Treated');
      }

      if (this.specialtyResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }
      if (this.specialtyResultCache.facets.disordersTreatedTypeCodes) {
        filterCategories.push('Disorders Treated');
      }

      if (this.specialtyResultCache.facets.treatmentMethodsTypeCodes) {
        filterCategories.push('Treatment Method');
      }

      if (this.specialtyResultCache.facets.groupAffiliationIds) {
        filterCategories.push('Medical Groups');
      }
      
      if(this.specialtyResultCache.facets.providerType){
        filterCategories.push('Providers');
      }
      if(this.specialtyResultCache.facets.hospitalAffiliationIds){
        filterCategories.push('Hospitals');
      }
      if(this.specialtyResultCache.facets.awardTypeCodes){
        filterCategories.push('Awards');
      }
      if(this.specialtyResultCache.facets.bdcTypeCodes){
        filterCategories.push('Blue Distinction Recognition');
      }
      if(this.specialtyResultCache.facets.cqms){
        filterCategories.push('Clinical Quality');
      }
      if(this.specialtyResultCache.facets.tiers){
        filterCategories.push('Tiers');
      }
    }
    return filterCategories;
  }

  public getFilteredSearchName(searchCriteria: FadLandingPageSearchControlValuesInterface): string {

    const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
    let searchName = searchTextOption.getSimpleText() || searchTextOption.getContextText();
    if (searchName && searchName.trim && searchName.trim().indexOf(FadConstants.text.allDoctorOptionText) >= 0) {
      searchName = this.replaceAll(searchName, FadConstants.text.allDoctorOptionText, '');
      searchName = searchName.replace(/["']/g, '');
    }

    if (searchName && searchName.trim && searchName.trim().indexOf(FadConstants.text.allHospitalsOrFacilitiesText) >= 0) {
      searchName = this.replaceAll(searchName, FadConstants.text.allHospitalsOrFacilitiesText, '');
      searchName = searchName.replace(/["']/g, '');
    }

    return searchName;
  }

  public sendEmailRequest(request,email,optionalmessage){
    console.log(request);
    console.log(email);
    var requestSendEmail = request;
    requestSendEmail['useridin'] = this.authService.useridin;
    requestSendEmail['email'] = email;
    requestSendEmail['optnlMsg']  = optionalmessage;

    console.log(requestSendEmail);
    console.log(FadConstants.urls.fadSendEmail);
    return this.http.encryptPost(
      FadConstants.urls.fadSendEmail, requestSendEmail,
      '', '', true).map(response => {
       return response;
      });
  }

  /**
 * Replace all the occerencess of $find by $replace in $originalString
 * @param  {originalString} input - Raw string.
 * @param  {find} input - Target key word or regex that need to be replaced.
 * @param  {replace} input - Replacement key word
 * @return {String}       Output string
 */
  public replaceAll(originalString, find, replace): string {
    return originalString.replace(new RegExp(find, 'g'), replace);
  }
}
