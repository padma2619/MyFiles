import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { FadConstants } from '../constants/fad.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadDoctorProfileService } from './fad-doctor-profile.service';
import {
  FadProfessionalResponseModelInterface,
  FadDoctorProfileRequestModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { AuthService } from '../../../shared/shared.module';

@Injectable()
export class FadDoctorProfileResolver<T> implements
  Resolve<Promise<FadProfessionalResponseModelInterface>> {
  constructor(private fadSearchResultsService: FadSearchResultsService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private errorHandler: BcbsmaerrorHandlerService,
    private router: Router,
    private doctorProfileService: FadDoctorProfileService,
    private authService: AuthService) { }

  async resolve(): Promise<FadProfessionalResponseModelInterface> {

    try {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      // tslint:disable-next-line:radix
      const professionalId = parseInt(sessionStorage.getItem('professionalId'));
      // this.doctorProfileService.doctorProfile;
      const networkId = (searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()) ?
        searchCriteria.getPlanName().getNetworkId() : FadConstants.defaults.networkId;
      const geoLocation = (searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo) ?
        searchCriteria.getZipCode().geo : FadConstants.defaults.geo;
      //const locationId = searchCriteria.getSearchText().getLocationId();
      const locationId = sessionStorage.getItem('locationId');

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams.setGeoLocation(geoLocation)
        .setProfessional(professionalId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
      if(sessionStorage.getItem('linkedAffiliationId'))
      {
        fadDoctorProfileRequestParams['linkedAffiliationId']=sessionStorage.getItem('linkedAffiliationId');
      }
      
      else if(searchCriteria && searchCriteria.getSearchText().isProcedure()) {
        const procedureID = searchCriteria.getSearchText().getProcedureId();
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius')!='null'?Number(sessionStorage.getItem('radius')):25);
      }

      const authUserId = this.authService.useridin;
      //console.log(this.authService.getUseridin());
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
       // fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }
      return await this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).toPromise();
    } catch (exception) {
      this.errorHandler.logError(exception, BcbsmaConstants.modules.fadModule, FadConstants.services.fadDoctorProfileResolver
        , FadConstants.methods.resolve);
    }
    return null;
  }
}
