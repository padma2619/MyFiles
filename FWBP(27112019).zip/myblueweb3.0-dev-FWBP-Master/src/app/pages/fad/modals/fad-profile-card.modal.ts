import {
    FadProfileCardComponentOutputModelInterface,
    FadProfileCardComponentInputModelInterface,
    FadFacilityCardComponentInputModelInterface,
    FadFacilityCardComponentOutputModelInterface,
    FadProviderCardComponentOutputModelInterface,
    FadProviderCardComponentInputModelInterface
} from './interfaces/fad-profile-card.interface';

import { FadProfileCardComponentMode } from './types/fad.types';
import { FadProfessionalInterface } from './interfaces/getSearchByProfessional-models.interface';
import { FadFacilityInterface } from './interfaces/getSearchByFacility-models.interface';
import { FadSpecialtyInterface } from './interfaces/getSearchBySpeciality-models.interface';
// import { FVProSRProfessionalInSearchEntity } from './fad-vitals-professionals-search-response.model';

export class FadProfileCardComponentOutputModel implements FadProfileCardComponentOutputModelInterface {
    public professional: FadProfessionalInterface;
    public isSelected: boolean;
}

export class FadProfileCardComponentInputModel implements FadProfileCardComponentInputModelInterface {
    public mode: FadProfileCardComponentMode = 'ListItem';

    constructor(public professional: FadProfessionalInterface) {

    }
}


export class FadFacilityCardComponentOutputModel implements FadFacilityCardComponentOutputModelInterface {
    public facility: FadFacilityInterface;
    public isSelected: boolean;


}

export class FadFacilityCardComponentInputModel implements FadFacilityCardComponentInputModelInterface {
    public mode: FadProfileCardComponentMode = 'ListItem';

    constructor(public facility: FadFacilityInterface) {

    }
}

//provider 

export class FadProviderProfileCardComponentOutputModel implements FadProviderCardComponentOutputModelInterface {
    public provider: FadSpecialtyInterface;
    public isSelected: boolean;
}

export class FadProviderProfileCardComponentInputModel implements FadProviderCardComponentInputModelInterface {
    public mode: FadProfileCardComponentMode = 'ListItem';

    constructor(public provider: FadSpecialtyInterface) {

    }
}


export class FadProviderFacilityCardComponentOutputModel implements FadFacilityCardComponentOutputModelInterface {
    public facility: FadFacilityInterface;
    public isSelected: boolean;


}

export class FadProviderFacilityCardComponentInputModel implements FadFacilityCardComponentInputModelInterface {
    public mode: FadProfileCardComponentMode = 'ListItem';

    constructor(public facility: FadFacilityInterface) {

    }
}
