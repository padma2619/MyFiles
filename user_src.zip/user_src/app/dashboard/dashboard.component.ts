import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FilterPipe } from 'ngx-filter-pipe';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  users : any;
  res: any[];
  nameFilter: any = { name: '' };
  addedUser: any;

  constructor(private usersList: UserServiceService, 
    private myRoute: ActivatedRoute, 
    private router: Router,
    private filterPipe: FilterPipe) { }

  

  ngOnInit() {

    this.addedUser = JSON.parse(localStorage.getItem('userDetails'));  

    this.usersList.getUsers().subscribe( (res) => {
    this.users = res.concat(this.addedUser);
    console.log(this.users);
    },
    this.filterPipe.transform(this.users, { name: ''})
  )}

    
}
