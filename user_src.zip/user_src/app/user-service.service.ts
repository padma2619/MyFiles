import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserServiceService {

  constructor(private httpService: HttpClient) { }
  
  getUsers(){
     return this.httpService.get('https://jsonplaceholder.typicode.com/users');
    // return this.httpService.get('../../assets/users.json');
  }
  

}
