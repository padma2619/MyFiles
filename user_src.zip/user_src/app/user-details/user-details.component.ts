import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  user = {
      id: "",
      name: ""
  };

  constructor(private activated: ActivatedRoute) { }

  ngOnInit() {
    this.activated.paramMap.subscribe((params : ParamMap)=> {  
      this.user.id=params.get('id');  
      this.user.name=params.get('name');  
    });  
    
  }

}
