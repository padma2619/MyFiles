import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {
  loginForm: FormGroup;

  validationMessage = {
    first_name:[
      {'type' : 'required', 'message' : 'Please enter the name.' },
      {'type' : 'minlength', 'message' : 'Please enter minimum 5 characters.' }
    ],
    email_id : [
        {'type' : 'required', 'message' : 'Please enter Email Id.' },
        {'type' : 'email', 'message' : 'Please enter valid Email id.' }
    ],
    phone_no : [
      {'type' : 'required', 'message' : 'Please enter Phone number.' },
  ]
  };

  constructor(private myRoute: Router) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
      'first_name': new FormControl('', [Validators.required, Validators.minLength(5)]),
      'user_name': new FormControl(''),
      'email_id': new FormControl('', [Validators.required, Validators.email]),
      'address': new FormControl(''),
      'phone_no': new FormControl('', [Validators.required, Validators.pattern('[0-9\s]*')]),
      'website': new FormControl(''),
      'company': new FormControl('')
    });
  }

  onSubmit(){
      if (this.loginForm.valid) {
          localStorage.setItem('userDetails', JSON.stringify({ name: this.loginForm.value.first_name, email: this.loginForm.value.email_id }));
          this.myRoute.navigate['/dashboard'];
        }
  } 

}
